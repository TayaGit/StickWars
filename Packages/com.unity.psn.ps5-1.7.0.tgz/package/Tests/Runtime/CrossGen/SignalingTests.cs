using System.Threading.Tasks;
using NUnit.Framework;
using Unity.PSN.PS5;
using Unity.PSN.PS5.Aysnc;
using Unity.PSN.PS5.Sessions;
using UnityEngine;
using UnityEngine.TestTools;

namespace PSNTests
{
    public class SignalingTests : BaseTests
    {

        [Test, Timeout(1000)]
        public async Task CanGetNatType()
        {
            SessionSignalling.GetNatRouterInfoRequest request = new SessionSignalling.GetNatRouterInfoRequest();

            var requestOp = new AsyncRequest<SessionSignalling.GetNatRouterInfoRequest>(request);
            SessionsManager.Schedule(requestOp);

            while (!requestOp.IsCompleted)
            {
                await Task.Delay(33);
            }

            Assert.That(requestOp.Request.Result.apiResult, Is.EqualTo(APIResultTypes.Success));

            var result = requestOp.Request;
            Assert.NotNull(result.NatRouterInfo);
            Assert.That(result.NatRouterInfo.NatType, Is.InRange(1,3));
        }
    }
}
