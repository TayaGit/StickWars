#if UNITY_PS5
using NUnit.Framework;
using System.Collections;
using Unity.PSN.PS5;
using Unity.PSN.PS5.Aysnc;
using Unity.PSN.PS5.Sandbox;
using UnityEngine;
using UnityEngine.TestTools;

namespace PSNTests
{
    [TestFixture, Description("Check Sandbox tests")]
    public class SandboxTests : BaseTests
    {
        public bool IsCompleted(AsyncOp op)
        {
            Assert.IsNotNull(op, "AsyncOp is Null");

            return op.IsCompleted;
        }

        [UnityTest, Order(1), Description("Get Sandbox Info")]
        public IEnumerator GetSandboxInfo()
        {
            if (!SandboxSystem.IsAvailable)
            {
                Assert.Ignore("SandboxSystem requires SDK 13.000 or later");
            }

            var request = new SandboxSystem.GetSandboxInfoRequest();

            var requestOp = new AsyncRequest<SandboxSystem.GetSandboxInfoRequest>(request);

            SandboxSystem.Schedule(requestOp);

            yield return new WaitUntil(() => IsCompleted(requestOp) == true);

            Assert.IsTrue(TestFramework.CheckRequestOK(request), "Request is OK");

            Assert.IsNotNull(request.Type, "Sandbox Type should not be null");
            Assert.IsNotNull(request.Id, "Sandbox Id should not be null");

            Debug.Log("Sandbox Type = " + request.Type);
            Debug.Log("Sandbox Id   = " + request.Id);
        }
    }
}
#endif
