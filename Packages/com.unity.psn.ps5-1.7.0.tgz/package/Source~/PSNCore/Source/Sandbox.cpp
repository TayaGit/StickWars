#include "Sandbox.h"
#include "HandleMsg.h"

#pragma comment(lib,"libSceNpManager_stub_weak.a")

namespace psn
{
    void Sandbox::RegisterMethods()
    {
#if (SCE_PROSPERO_SDK_VERSION >= 0x13000000u)
        MsgHandler::AddMethod(Methods::GetSandboxInfo, Sandbox::GetSandboxInfoImpl);
#endif
    }

#if (SCE_PROSPERO_SDK_VERSION >= 0x13000000u)
    void Sandbox::GetSandboxInfoImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        SceNpSandboxInfo sandboxInfo;
        memset(&sandboxInfo, 0, sizeof(sandboxInfo));

        int ret = sceNpGetSandboxInfo(&sandboxInfo);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteString(sandboxInfo.type);
        writer.WriteString(sandboxInfo.id);

        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }
#endif
}
