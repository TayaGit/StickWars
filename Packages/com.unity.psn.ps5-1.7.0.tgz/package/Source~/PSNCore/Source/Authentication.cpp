#include "Authentication.h"
#include "HandleMsg.h"

#include <np/np_auth.h>

#pragma comment(lib,"libSceNpAuth_stub_weak.a")


namespace
{

    /// RAII-style wrapper around sceNpAuthCreateRequest / sceNpAuthDeleteRequest.
    /// This allows us to early-exit in functions that use Np Auth Requests,
    /// without having to worry about ensuring that sceNpAuthDeleteRequest is called.
    class ScopedNpAuthRequest
    {
    public:
        /// The integer id returned from sceNpAuthCreateRequest, called from the constructor.
        const int id;

        /// @brief Constructor; calls sceNpAuthCreateRequest and stores the result in `id`.
        ScopedNpAuthRequest() :
            id (sceNpAuthCreateRequest())
        {}

        /// Deleted: Uncopyable.
        ScopedNpAuthRequest (const ScopedNpAuthRequest&) = delete;

        ~ScopedNpAuthRequest()
        {
            if (!ok())
                return; // Don't delete a request if it was not made in the first place.
            sceNpAuthDeleteRequest(id);
        }

        /// @return `true` if the sceNpAuthCreateRequest in the constructor was successful and the member variable `id` refers to a valid request.  Otherwise `false`.
        bool ok() const {return id > 0;}
    };


}



namespace psn
{
    void Authentication::RegisterMethods()
    {
        MsgHandler::AddMethod(Methods::GetAuthorizationCode, Authentication::GetAuthorizationCodeImpl);
        MsgHandler::AddMethod(Methods::GetIdToken, Authentication::GetIdTokenImpl);
    }

    void Authentication::GetAuthorizationCodeImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        SceNpAuthGetAuthorizationCodeParameterV3 authParam;

        SceNpClientId clientId;

        SceNpAuthorizationCode authCode;
        int issuerId = 0;

        BinaryReader reader(sourceData, sourceSize);
        Int32 userId = reader.ReadInt32();

        char* clientIdStr = reader.ReadStringPtr();
        char* scopeStr = reader.ReadStringPtr();

        ScopedNpAuthRequest request;
        if (!request.ok()) {
            SCE_ERROR_RESULT(result, request.id);
            return;
        }

        memset(&clientId, 0, sizeof(clientId));
        strncpy(clientId.id, clientIdStr, SCE_NP_CLIENT_ID_MAX_LEN);

        memset(&authParam, 0, sizeof(authParam));
        authParam.size = sizeof(authParam);
        authParam.userId = userId;
        authParam.clientId = &clientId;
        authParam.scope = scopeStr;

        int ret = sceNpAuthGetAuthorizationCodeV3(request.id, &authParam, &authCode, &issuerId);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        // Write results
        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteInt32(issuerId);
        writer.WriteString(authCode.code);

        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }

    void Authentication::GetIdTokenImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        SceNpAuthGetIdTokenParameterV3 authParam;
        SceNpClientId clientId;
        SceNpClientSecret clientSecret;
        SceNpIdToken idToken;

        BinaryReader reader(sourceData, sourceSize);
        Int32 userId = reader.ReadInt32();

        char* clientIdStr = reader.ReadStringPtr();
        char* clientSecretStr = reader.ReadStringPtr();
        char* scopeStr = reader.ReadStringPtr();

        ScopedNpAuthRequest request;
        if (!request.ok()) {
            SCE_ERROR_RESULT(result, request.id);
            return;
        }

        memset(&clientId, 0, sizeof(clientId));
        strncpy(clientId.id, clientIdStr, SCE_NP_CLIENT_ID_MAX_LEN);

        memset(&clientSecret, 0, sizeof(clientSecret));
        strncpy(clientSecret.secret, clientSecretStr, SCE_NP_CLIENT_SECRET_MAX_LEN);

        memset(&authParam, 0, sizeof(authParam));
        authParam.size = sizeof(authParam);
        authParam.userId = userId;
        authParam.clientId = &clientId;
        authParam.clientSecret = &clientSecret;
        authParam.scope = scopeStr;

        int ret = sceNpAuthGetIdTokenV3(request.id, &authParam, &idToken);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        // Write results
        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteString(idToken.token);

        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }
}
