#pragma once
#include "SharedCoreIncludes.h"

namespace psn
{
    class Sandbox
    {
    public:

        enum Methods
        {
            GetSandboxInfo = 0x1800001u,
        };

        static void RegisterMethods();

#if (SCE_PROSPERO_SDK_VERSION >= 0x13000000u)
        static void GetSandboxInfoImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result);
#endif
    };
}
