using UnityEngine;

namespace Unity.PSN.PS5.Internal
{
    internal static class BuildHelper
    {
        internal static bool IsDevelopmentBuild
        {
            get
            {
#if DEBUG
                return true;
#else
                return Debug.isDebugBuild;
#endif
            }
        }
    }
}
