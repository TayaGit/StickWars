
using System;
using Unity.PSN.PS5.Aysnc;
using Unity.PSN.PS5.Internal;

namespace Unity.PSN.PS5.Sandbox
{
    /// <summary>
    /// Provides access to the sandbox information for the current application context.
    /// Requires Prospero SDK 13.000 or later.
    /// </summary>
    public class SandboxSystem
    {
        const UInt32 MinSdkVersion = 0x13000000u;

        enum NativeMethods : UInt32
        {
            GetSandboxInfo = 0x1800001u,
        }

        /// <summary>
        /// Whether the sandbox API is available. Returns false if the native plugin was built with an SDK older than 13.000.
        /// </summary>
        public static bool IsAvailable => Main.initResult.SceSDKVersionValue >= MinSdkVersion;

        static WorkerThread workerQueue = new WorkerThread();

        internal static void Start()
        {
            workerQueue.Start("Sandbox");
        }

        internal static void Stop()
        {
            workerQueue.Stop();
        }

        /// <summary>
        /// Schedule an <see cref="AsyncOp"/> by adding it to the internal Sandbox queue
        /// </summary>
        /// <param name="op">The operation to schedule</param>
        /// <exception cref="ExceededMaximumOperations">The number of operations added to the queue has exceeded its limit. Too many operations have been added to the work queue.</exception>
        /// <exception cref="InvalidOperationException">The feature is not available.</exception>
        public static void Schedule(AsyncOp op)
        {
            workerQueue.Schedule(op);
        }

        /// <summary>
        /// Get sandbox information for the current application context.
        /// Requires SDK 13.000 or later. Check <see cref="IsAvailable"/> before scheduling.
        /// </summary>
        public class GetSandboxInfoRequest : Request
        {
            /// <summary>
            /// The sandbox type (e.g. "DEVELOPMENT", "CERTIFICATION", "RETAIL")
            /// </summary>
            /// <remarks>This is an empty string when using Legacy mode</remarks>
            public string Type { get; internal set; }

            /// <summary>
            /// The sandbox identifier
            /// </summary>
            /// <remarks>This is an empty string when using Legacy mode</remarks>
            public string Id { get; internal set; }

            protected internal override void Run()
            {
                if (!IsAvailable)
                {
                    throw new InvalidOperationException($"This feature is only available on SDK {MinSdkVersion} or later");
                }

                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetSandboxInfo);

                nativeMethod.Call();

                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    Type = nativeMethod.Reader.ReadPrxString();
                    Id = nativeMethod.Reader.ReadPrxString();
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }
    }
}
