
#if UNITY_PS5 || UNITY_PS4
using Unity.PSN.PS5.Sandbox;
using Unity.PSN.PS5.Aysnc;
#endif


namespace PSNSample
{
#if UNITY_PS5 || UNITY_PS4
    public class SonySandbox : IScreen
    {
        MenuLayout m_MenuSandbox;

        public SonySandbox()
        {
            Initialize();
        }

        public MenuLayout GetMenu()
        {
            return m_MenuSandbox;
        }

        public void OnEnter()
        {
        }

        public void OnExit()
        {
        }

        public void Process(MenuStack stack)
        {
            MenuSandbox(stack);
        }

        public void Initialize()
        {
            m_MenuSandbox = new MenuLayout(this, 450, 20);
        }

        public void FetchSandboxInfo()
        {
            SandboxSystem.GetSandboxInfoRequest request = new SandboxSystem.GetSandboxInfoRequest();

            var requestOp = new AsyncRequest<SandboxSystem.GetSandboxInfoRequest>(request).ContinueWith((antecedent) =>
            {
                if (SonyNpMain.CheckAysncRequestOK(antecedent))
                {
                    string sandboxType = antecedent.Request.Type;
                    string sandboxId = antecedent.Request.Id;
                    OnScreenLog.Add("Sandbox Type = " + sandboxType);
                    OnScreenLog.Add("Sandbox Id   = " + sandboxId);
                }
            });

            SandboxSystem.Schedule(requestOp);
        }

        public void MenuSandbox(MenuStack menuStack)
        {
            m_MenuSandbox.Update();

            if (m_MenuSandbox.AddItem("Refresh Sandbox Info", "Refresh the current sandbox type and id", SandboxSystem.IsAvailable))
            {
                FetchSandboxInfo();
            }

            if (m_MenuSandbox.AddBackIndex("Back"))
            {
                menuStack.PopMenu();
            }
        }

    }
#endif
}
