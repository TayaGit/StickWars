#if UNITY_PS5
using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using Unity.ContentManagement.PS5;
using Unity.ContentManagement.PS5.Aysnc;

//
// The sample below contains test code for the various methods provided by the Unity.ContentManagement.PS5 namespace.
//
// The sample code does not demonstrate any game functionality and is intended purely as a test and to demonstrate
// how to call the ContentManagement API. To avoid blocking the main thread most of the ContentManagement methods use an asynchrounous
// request system similar to that used by the PSN package (com.unity.psn.ps5), the sample code below uses a simple
// state machine to manage transitioning from one test to another when an asyc request completes.
//
// Sony's ContentManagement feature is made of from three libraries, content export, content search, and content delete.
// The documentation for these libraries can be found at the following URLS...
// https://game.develop.playstation.net/resources/documents/SDK/latest/ContentExport-Overview/__toc.html
// https://game.develop.playstation.net/resources/documents/SDK/latest/ContentDelete-Overview/__toc.html
// https://game.develop.playstation.net/resources/documents/SDK/latest/ContentSearch-Overview/__toc.html
//
// Note that for content search to work permission must be set in in the applications param.json file; atttribute2 must be set correctly.
// See https://game.develop.playstation.net/resources/documents/SDK/latest/Param_File_Editor-Users_Guide/0004.html
// Specifically bit 2 of attribute2 needs to be set, i.e. attribute2 is OR'd with 4.
//
// A suitable param.json file is supplied and can be set in the PS5 Player Settings either manually or by selecting
// the 'Prepare Project Assets And Settings' item in the 'SCE Publishing Utils' menu.
//

namespace ContentManagementSample
{
    public class ContentManagementTest : MonoBehaviour
    {
        // Array defining the sequence of states to be tested.
        ContentManagementState[] m_Steps = new ContentManagementState[]
        {
            ContentManagementState.WaitingForButton,
            ContentManagementState.Initialize,

            ContentManagementState.ExportFromFile,
            ContentManagementState.ExportFromFileWithThumbnail,
            ContentManagementState.ExportFromData,
            ContentManagementState.ExportFromDataWithThumbnail,

            ContentManagementState.WaitingForButton,
            ContentManagementState.SearchGetLastUpdateID,
            ContentManagementState.SearchGetNumOfContent_GenTypeExport,
            ContentManagementState.SearchGetTotalContentSize_GenTypeExport,
            ContentManagementState.SearchGetNumOfContent_GenTypeShare,
            ContentManagementState.SearchGetTotalContentSize_GenTypeShare,
            ContentManagementState.SearchGetNumOfContent_GenTypeAny,
            ContentManagementState.SearchGetTotalContentSize_GenTypeAny,
            ContentManagementState.WaitingForButton,
            ContentManagementState.SearchForPhotos_GenTypeExport,
            ContentManagementState.SearchForVideos_GenTypeExport,
            ContentManagementState.SearchForPhotos_GenTypeShare,
            ContentManagementState.SearchForVideos_GenTypeShare,
            ContentManagementState.SearchForPhotos_GenTypeAny,
            ContentManagementState.SearchForVideos_GenTypeAny,

            ContentManagementState.WaitingForButton,
            ContentManagementState.SearchGetMetadata,
            ContentManagementState.SearchGetMetadataByContentID,

            ContentManagementState.WaitingForButton,
            ContentManagementState.DeleteByPath,
            ContentManagementState.DeleteByContentID,

            ContentManagementState.WaitingForButton,
            ContentManagementState.Terminate,
            ContentManagementState.AllDone,
        };

        ContentManagementState m_State = ContentManagementState.Uninitialized;
        int m_CurrentStep = 0;
        StateTransition m_DefaultStateTransition = new StateTransition(ContentManagementState.Next);
        StateTransition m_NullStateTransition = new StateTransition(ContentManagementState.NullState, ContentManagementState.NullState, ContentManagementState.NullState);
        float m_DelayTime = 0.0f;
        StateTransition m_StateTransitionAfterDelay;
        string m_LogText = "";

        int m_ActiveExportID = -1;  // ID of the active export when an export has been started.
        int m_SearchOffset = 0; // Current search starting offset for content searches.
        int m_SearchLimit = 10; // Maximum number of content items to retrieve in a single search request.

        ContentSearch.ContentSearchContentInfo[] m_FoundContent = new ContentSearch.ContentSearchContentInfo[0];
        int m_ContentDeleteIndex = 0;

        // Start is called before the first frame update.
        //
        void Start()
        {
            ContentManagementSample.OnScreenInfo.sm_LogEventHandlers += OnAddLogText;

            m_CurrentStep = 0;
            m_State = m_Steps[m_CurrentStep];
        }

        // Update is called once per frame.
        //
        void Update()
        {
            if (!UnityEngine.Rendering.SplashScreen.isFinished)
            {
                return;
            }

            ExecuteCurrentState();

            m_LogText = GetDiagnosticInfo();
        }

        // Event handler, called once per frame to add log text to the OnScreenInfo display.
        //
        public void OnAddLogText(ContentManagementSample.OnScreenInfo.LogEventArgs eventArgs)
        {
            eventArgs.logText += m_LogText;
        }

        // Format an APIResult with SCE error code into a string.
        //
        string SceErrorToString(APIResult result)
        {
            if (result.message.Length > 0)
                return $"sceErrorCode: {result.message} (0x{result.sceErrorCode:X8})";
            return $"sceErrorCode: 0x{result.sceErrorCode:X8}";
        }

        // Initialize the ContentManagement system.
        //
        void Initialize(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");

            // First try and verify that the sample has been correctly setup and built.
            string testFilePath = System.IO.Path.Combine(Application.streamingAssetsPath, "3840x2160-1.png");
            if (!System.IO.File.Exists(testFilePath))
            {
                ContentManagementSample.OnScreenLog.Add($"  Failed to find file \"{testFilePath}\"");
                ContentManagementSample.OnScreenLog.Add("  The sample may need setting up.");
                ContentManagementSample.OnScreenLog.Add("  In the Unity Editor select the menu option \"Prepare Project Assets And Settings\" which can be found in the \"SCE Publishing Utils / ContentManagement Sample\" menu.", true);
                m_State = states.SetStateFailed(m_State);
                return;
            }
            ContentManagementSample.OnScreenLog.Add($"  Found find file \"{testFilePath}\"");

            m_State = states.SetStateWaiting(m_State);

            // Initialize ContentManagement.
#if PLATFORM_PS5
            Unity.ContentManagement.PS5.Initialization.InitResult initResult = Unity.ContentManagement.PS5.Main.Initialize();
            ContentManagementSample.OnScreenLog.Add($"  Initialized ContentManagement Plugin - SDK Version {initResult.SceSDKVersion}");

            Main.InitialiseRequest request = new Main.InitialiseRequest();
            Main.Schedule(new AsyncRequest<Main.InitialiseRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                    m_State = states.SetStateSucceeded(m_State, $"  Main.InitialiseRequest succeeded in {request.ExecutionTime}ms");
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.InitialiseRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#endif
        }

        // Shutdown the ContentManagement system.
        //
        void Terminate(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            Main.TerminateRequest request = new Main.TerminateRequest();
            Main.Schedule(new AsyncRequest<Main.TerminateRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                    m_State = states.SetStateSucceeded(m_State, $"  Main.TerminateRequest succeeded in {request.ExecutionTime}ms");
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.TerminateRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void ExportFromFile(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentExport.ExportFromFileRequest();
            m_ActiveExportID = ContentExport.ExportStart();
            request.ExportID = m_ActiveExportID;
            request.Title = "Test ExportFromFile";
            request.ContentExportFormat = ContentExport.ContentExportFormatType.ContentExportFormatImagePng;
            request.SrcFilePath = "/app0/Media/StreamingAssets/3840x2160-1.png";
            request.SrcThumbnailFilePath = "";
            Main.Schedule(new AsyncRequest<ContentExport.ExportFromFileRequest>(request).ContinueWith((antecedent) =>
            {
                m_ActiveExportID = -1;

                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ExportFromFileRequest succeeded in {request.ExecutionTime}ms");
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ExportFromFileRequest failed: {SceErrorToString(antecedent.Request.Result)}");
                ContentExport.ExportFinish(request.ExportID);
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void ExportFromFileWithThumbnail(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentExport.ExportFromFileRequest();
            m_ActiveExportID = ContentExport.ExportStart();
            request.ExportID = m_ActiveExportID;
            request.Title = "Test ExportFromFileWithThumbnail";
            request.ContentExportFormat = ContentExport.ContentExportFormatType.ContentExportFormatImagePng;
            request.SrcFilePath = "/app0/Media/StreamingAssets/3840x2160-2.png";
            request.SrcThumbnailFilePath = "/app0/Media/StreamingAssets/1920x1080-2.jpg";   // The PS5 SDK currently only support JPG format for thumbnails.
            Main.Schedule(new AsyncRequest<ContentExport.ExportFromFileRequest>(request).ContinueWith((antecedent) =>
            {
                m_ActiveExportID = -1;

                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ExportFromFileRequest with thumbnail succeeded in {request.ExecutionTime}ms");
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ExportFromFileRequest with thumbnail failed: {SceErrorToString(antecedent.Request.Result)}");
                ContentExport.ExportFinish(request.ExportID);
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        byte[] ReadFile(string filePath)
        {
            byte[] data = File.ReadAllBytes(filePath);
            return data;
        }

        void ExportFromData(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentExport.ExportFromDataRequest();
            m_ActiveExportID = ContentExport.ExportStart();
            request.ExportID = m_ActiveExportID;
            request.Title = "Test ExportFromData";
            request.ContentExportFormat = ContentExport.ContentExportFormatType.ContentExportFormatImagePng;
            request.ContentData = ReadFile("/app0/Media/StreamingAssets/3840x2160-3.png");

            Main.Schedule(new AsyncRequest<ContentExport.ExportFromDataRequest>(request).ContinueWith((antecedent) =>
            {
                m_ActiveExportID = -1;

                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ExportFromDataRequest succeeded in {request.ExecutionTime}ms");
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ExportFromDataRequest failed: {SceErrorToString(antecedent.Request.Result)}");
                ContentExport.ExportFinish(request.ExportID);
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void ExportFromDataWithThumbnail(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentExport.ExportFromDataRequest();
            m_ActiveExportID = ContentExport.ExportStart();
            request.ExportID = m_ActiveExportID;
            request.Title = "Test ExportFromDataWithThumbnail";
            request.ContentExportFormat = ContentExport.ContentExportFormatType.ContentExportFormatImagePng;
            request.ContentData = ReadFile("/app0/Media/StreamingAssets/3840x2160-4.png");
            request.ThumbnailExportFormat = ContentExport.ContentExportFormatType.ContentExportFormatImageJpeg;   // The PS5 SDK currently only support JPG format for thumbnails.
            request.ThumbnailData = ReadFile("/app0/Media/StreamingAssets/1920x1080-4.jpg");

            Main.Schedule(new AsyncRequest<ContentExport.ExportFromDataRequest>(request).ContinueWith((antecedent) =>
            {
                m_ActiveExportID = -1;

                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ExportFromDataRequest succeeded in {request.ExecutionTime}ms");
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ExportFromDataRequest failed: {SceErrorToString(antecedent.Request.Result)}");
                ContentExport.ExportFinish(request.ExportID);
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        // Detecting Content Additions, Deletions, and Updates
        //
        // By calling ContentSearch.GetLastUpdateID() an application can obtain update information about a content database at any time.
        // This update information value will always change whenever content managed by the system is added, deleted, or updated; therefore, by
        // obtaining this value at an appropriate time and comparing it with a past value, you will be able to detect if some kind of change such
        // as increases/decreases in content happened during the intervening period.
        //
        void SearchGetLastUpdateID(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

            int startTime = Environment.TickCount;
            long updateID = ContentSearch.GetLastUpdateID();
            OnScreenLog.Add($"  Done in {Environment.TickCount - startTime}ms");
            OnScreenLog.Add($"  Last update ID = {updateID}");

            m_State = states.SetStateSucceeded(m_State);
        }

        void SearchGetNumOfContent(StateTransition states,  ContentSearch.ContentSearchContentType contentType, ContentSearch.ContentSearchContentGeneratorType generatorType)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentSearch.ContentSearchGetNumOfContentRequest();
            request.ContentColumnSets = InitColumnSets(contentType, generatorType, "");

            Main.Schedule(new AsyncRequest<ContentSearch.ContentSearchGetNumOfContentRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    OnScreenLog.Add($"  Content count for ContentSearchContentType.{contentType.ToString()}: {request.ContentCount}, ContentSearchContentGeneratorType.{generatorType}");
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ContentSearchGetNumOfContentRequest succeeded in {request.ExecutionTime}ms");
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentSearchGetNumOfContentRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void SearchGetTotalContentSize(StateTransition states,  ContentSearch.ContentSearchContentType contentType, ContentSearch.ContentSearchContentGeneratorType generatorType)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentSearch.ContentSearchGetTotalContentSizeRequest();
            request.ContentColumnSets = InitColumnSets(contentType, generatorType, "");

            Main.Schedule(new AsyncRequest<ContentSearch.ContentSearchGetTotalContentSizeRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    OnScreenLog.Add($"  Total content size for ContentSearchContentType.{contentType.ToString()}: {request.ContentSize}, ContentSearchContentGeneratorType.{generatorType}");
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ContentSearchGetTotalContentSizeRequest succeeded in {request.ExecutionTime}ms");
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentSearchGetTotalContentSizeRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        // Initialize a set of search column arrays.
        ContentSearch.ContentSearchContentColumnSet[] InitColumnSets(ContentSearch.ContentSearchContentType contentType, ContentSearch.ContentSearchContentGeneratorType generatorType, string contentPath)
        {
            ContentSearch.ContentSearchContentColumnSet[] columnSets = new ContentSearch.ContentSearchContentColumnSet[1];

            columnSets[0].contentColumns = InitSearchColumns(contentType, generatorType, contentPath);
            columnSets[0].logicalConnector = ContentSearch.ContentSearchLogicalConnector.None;

            return columnSets;
        }

        // Initialize a search column array.
        ContentSearch.ContentSearchContentColumn[] InitSearchColumns(ContentSearch.ContentSearchContentType contentType, ContentSearch.ContentSearchContentGeneratorType generatorType, string contentPath)
        {
            int columnCount = 0;
            if (contentType != ContentSearch.ContentSearchContentType.Unknown)
                columnCount++;

            if (generatorType != ContentSearch.ContentSearchContentGeneratorType.Unknown)
                columnCount++;

            if (!String.IsNullOrEmpty(contentPath))
                columnCount++;

            ContentSearch.ContentSearchContentColumn[] contentColumns = new ContentSearch.ContentSearchContentColumn[columnCount];

            int columnIndex = 0;
            if (contentType != ContentSearch.ContentSearchContentType.Unknown)
            {
                contentColumns[columnIndex].columnType = ContentSearch.ContentSearchContentColumnType.ContentType;
                contentColumns[columnIndex].columnOperator = ContentSearch.ContentSearchColumnValueOperator.Equal;
                contentColumns[columnIndex].value.IntVal = (int)contentType;
                contentColumns[columnIndex].logicalConnector = ContentSearch.ContentSearchLogicalConnector.None;
                columnIndex++;
            }
            if (generatorType != ContentSearch.ContentSearchContentGeneratorType.Unknown)
            {
                contentColumns[columnIndex].columnType = ContentSearch.ContentSearchContentColumnType.GeneratorType;
                contentColumns[columnIndex].columnOperator = ContentSearch.ContentSearchColumnValueOperator.Equal;
                contentColumns[columnIndex].value.IntVal = (int)generatorType;

                if (columnIndex > 0)
                    contentColumns[columnIndex].logicalConnector = ContentSearch.ContentSearchLogicalConnector.And; // Logical AND with the previous column.
                else
                    contentColumns[columnIndex].logicalConnector = ContentSearch.ContentSearchLogicalConnector.None;
                columnIndex++;
            }
            if (!String.IsNullOrEmpty(contentPath))
            {
                contentColumns[columnIndex].columnType = ContentSearch.ContentSearchContentColumnType.ContentPath;
                contentColumns[columnIndex].columnOperator = ContentSearch.ContentSearchColumnValueOperator.Equal;
                contentColumns[columnIndex].value.StringVal = contentPath;

                if (columnIndex > 0)
                    contentColumns[columnIndex].logicalConnector = ContentSearch.ContentSearchLogicalConnector.And; // Logical AND with the previous column.
                else
                    contentColumns[columnIndex].logicalConnector = ContentSearch.ContentSearchLogicalConnector.None;
                columnIndex++;
            }

            return contentColumns;
        }

        ContentSearch.ContentSearchContentOrderByCondition[] InitOrderByConditions()
        {
            ContentSearch.ContentSearchContentOrderByCondition[] orderByConditions = new ContentSearch.ContentSearchContentOrderByCondition[1];
            orderByConditions[0].columnType = ContentSearch.ContentSearchContentSortColumnType.Title;
            orderByConditions[0].sortType = ContentSearch.ContentSearchSortType.Ascendant;

            return orderByConditions;
        }

        void SearchForContent(StateTransition states,  ContentSearch.ContentSearchContentType contentType, ContentSearch.ContentSearchContentGeneratorType generatorType)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            ContentManagementState contextState = m_State;
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            var request = new ContentSearch.ContentSearchForRequest();
            request.SearchOffset = m_SearchOffset;
            request.SearchLimit = m_SearchLimit;
            request.ContentColumnSets = InitColumnSets(contentType, generatorType, "");
            request.OrderByConditions = InitOrderByConditions();

            Main.Schedule(new AsyncRequest<ContentSearch.ContentSearchForRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    if (request.ContentCount > 0)
                    {
                        if(m_FoundContent.Length == 0)
                            m_FoundContent = request.contentInfo;

                        // There could be more content to find, so increment the search offset and do another search.
                        m_SearchOffset += m_SearchLimit;
                        OnScreenLog.Add($"  Main.ContentSearchForRequest succeeded in {request.ExecutionTime}ms");
                        m_State = contextState;

                        OnScreenLog.Add($"  Found {request.ContentCount} of ContentSearchContentType.{contentType.ToString()}");
                        foreach(ContentSearch.ContentSearchContentInfo info in request.contentInfo)
                        {
                            OnScreenLog.Add($"    \"{info.contentPath}\" from {info.generatorId.ToString()}");
                        }
                    }
                    else
                    {
                        m_SearchOffset = 0; // Reset the search offset now that we've finished searching.
                        m_State = states.SetStateSucceeded(m_State, $"  Main.ContentSearchForRequest succeeded in {request.ExecutionTime}ms");
                    }
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentSearchForRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void SearchGetMetadata(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            if (m_FoundContent.Length == 0)
            {
                OnScreenLog.Add("    Can't get metadata, no content found.");
                m_State = states.SetStateSucceeded(m_State);
                return;
            }

            var request = new ContentSearch.ContentSearchGetMetadataRequest();
            request.FilePath = m_FoundContent[0].contentPath;
            request.MetadataFieldIndices = new ContentSearch.ContentSearchMetadaDataFieldNameIndex[15];
            request.MetadataFieldIndices[0] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Title;
            request.MetadataFieldIndices[1] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Mime;
            request.MetadataFieldIndices[2] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Createdtime;
            request.MetadataFieldIndices[3] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Lastupdatedtime;
            request.MetadataFieldIndices[4] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Size;
            request.MetadataFieldIndices[5] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Width;
            request.MetadataFieldIndices[6] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Height;
            request.MetadataFieldIndices[7] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.VideoBitrate;
            request.MetadataFieldIndices[8] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.AudioMimeType;
            request.MetadataFieldIndices[9] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.AudioBitrate;
            request.MetadataFieldIndices[10] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.AudioChannelType;
            request.MetadataFieldIndices[11] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Orientation;
            request.MetadataFieldIndices[12] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.ImportedTime;
            request.MetadataFieldIndices[13] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Duration;
            request.MetadataFieldIndices[14] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.MediaTimescale;

            OnScreenLog.Add($"    Getting metadata for file \"{request.FilePath}\"");

            Main.Schedule(new AsyncRequest<ContentSearch.ContentSearchGetMetadataRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ContentSearchGetMetadataRequest succeeded in {request.ExecutionTime}ms");
                    for(int i=0; i<request.MetadataFieldIndices.Length; i++)
                    {
                        if (request.MetadataValues[i].IsValueSet)
                            OnScreenLog.Add($"    {request.MetadataFieldIndices[i]} = {request.MetadataValues[i]}");
                    }
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentSearchGetMetadataRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void SearchGetMetadataByContentID(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            if (m_FoundContent.Length == 0)
            {
                OnScreenLog.Add("    Can't get metadata, no content found.");
                m_State = states.SetStateSucceeded(m_State);
                return;
            }

            var request = new ContentSearch.ContentSearchGetMetadataByContentIdRequest();
            request.ContentID = m_FoundContent[0].contentId;
            request.MetadataFieldIndices = new ContentSearch.ContentSearchMetadaDataFieldNameIndex[15];
            request.MetadataFieldIndices[0] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Title;
            request.MetadataFieldIndices[1] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Mime;
            request.MetadataFieldIndices[2] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Createdtime;
            request.MetadataFieldIndices[3] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Lastupdatedtime;
            request.MetadataFieldIndices[4] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Size;
            request.MetadataFieldIndices[5] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Width;
            request.MetadataFieldIndices[6] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Height;
            request.MetadataFieldIndices[7] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.VideoBitrate;
            request.MetadataFieldIndices[8] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.AudioMimeType;
            request.MetadataFieldIndices[9] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.AudioBitrate;
            request.MetadataFieldIndices[10] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.AudioChannelType;
            request.MetadataFieldIndices[11] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Orientation;
            request.MetadataFieldIndices[12] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.ImportedTime;
            request.MetadataFieldIndices[13] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.Duration;
            request.MetadataFieldIndices[14] = ContentSearch.ContentSearchMetadaDataFieldNameIndex.MediaTimescale;

            OnScreenLog.Add($"    Getting metadata for contentID \"{request.ContentID}\"");

            Main.Schedule(new AsyncRequest<ContentSearch.ContentSearchGetMetadataByContentIdRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ContentSearchGetMetadataByContentIdRequest succeeded in {request.ExecutionTime}ms");
                    for(int i=0; i<request.MetadataFieldIndices.Length; i++)
                    {
                        if (request.MetadataValues[i].IsValueSet)
                            OnScreenLog.Add($"    {request.MetadataFieldIndices[i]} = {request.MetadataValues[i]}");
                    }
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentSearchGetMetadataByContentIdRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void DeleteByPath(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            if (m_FoundContent.Length == 0 || m_ContentDeleteIndex >= m_FoundContent.Length)
            {
                OnScreenLog.Add("    Can't delete content, no content found.");
                m_State = states.SetStateSucceeded(m_State);
                return;
            }

            var request = new ContentDelete.ContentDeleteByPathRequest();
            request.FilePath = m_FoundContent[m_ContentDeleteIndex].contentPath;
            m_ContentDeleteIndex++;

            OnScreenLog.Add($"    Deleting file \"{request.FilePath}\"");

            Main.Schedule(new AsyncRequest<ContentDelete.ContentDeleteByPathRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ContentDeleteByPathRequest succeeded in {request.ExecutionTime}ms");
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentDeleteByPathRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        void DeleteByContentId(StateTransition states)
        {
            OnScreenLog.Add($"Executing state {m_State}");
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5
            if (m_FoundContent.Length == 0 || m_ContentDeleteIndex >= m_FoundContent.Length)
            {
                OnScreenLog.Add("    Can't delete content, no content found.");
                m_State = states.SetStateSucceeded(m_State);
                return;
            }

            var request = new ContentDelete.ContentDeleteByContentIdRequest();
            request.ContentID = m_FoundContent[m_ContentDeleteIndex].contentId;
            m_ContentDeleteIndex++;

            OnScreenLog.Add($"    Deleting contentID \"{request.ContentID}\"");

            Main.Schedule(new AsyncRequest<ContentDelete.ContentDeleteByContentIdRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    m_State = states.SetStateSucceeded(m_State, $"  Main.ContentDeleteByContentIdRequest succeeded in {request.ExecutionTime}ms");
                }
                else
                    m_State = states.SetStateFailed(m_State, $"  Main.ContentDeleteByContentIdRequest failed: {SceErrorToString(antecedent.Request.Result)}");
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        // Update the delay time when in the delay state.
        //
        void UpdateDelay()
        {
            if (m_State == ContentManagementState.WaitingForDelay)
            {
                m_DelayTime -= Time.deltaTime;
                if (m_DelayTime <= 0.0f)
                {
                    m_State = m_StateTransitionAfterDelay.SetStateSucceeded(m_State);
                }
            }
        }

        // Setup state to wait for a specified time.
        //
        void WaitSeconds(float delayTime, StateTransition states)
        {
            m_State = ContentManagementState.WaitingForDelay;
            m_DelayTime = delayTime;
            m_StateTransitionAfterDelay = states;
        }

        void WaitButton(StateTransition states)
        {
            if (UnityEngine.InputSystem.Gamepad.current?.crossButton.wasPressedThisFrame == true)
            {
                m_State = states.SetStateSucceeded(m_State);
            }
           
        }

        // Execute the current test state.
        //
        void ExecuteCurrentState()
        {
            switch (m_State)
            {
                case ContentManagementState.Next:
                    if (m_CurrentStep < m_Steps.Length - 1)
                    {
                        m_CurrentStep++;
                        m_State = m_Steps[m_CurrentStep];
                    }
                    break;

                case ContentManagementState.Initialize:
                    Initialize(m_DefaultStateTransition);
                    break;

                case ContentManagementState.Terminate:
                    Terminate(m_DefaultStateTransition);
                    break;

                case ContentManagementState.ExportFromFile:
                    ExportFromFile(m_DefaultStateTransition);
                    break;

                case ContentManagementState.ExportFromFileWithThumbnail:
                    ExportFromFileWithThumbnail(m_DefaultStateTransition);
                    break;

                case ContentManagementState.ExportFromData:
                    ExportFromData(m_DefaultStateTransition);
                    break;

                case ContentManagementState.ExportFromDataWithThumbnail:
                    ExportFromDataWithThumbnail(m_DefaultStateTransition);
                    break;

                case ContentManagementState.SearchGetLastUpdateID:
                    SearchGetLastUpdateID(m_DefaultStateTransition);
                    break;

                case ContentManagementState.SearchGetNumOfContent_GenTypeExport:
                    SearchGetNumOfContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Export);
                    break;

                case ContentManagementState.SearchGetTotalContentSize_GenTypeExport:
                    SearchGetTotalContentSize(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Export);
                    break;

                case ContentManagementState.SearchGetNumOfContent_GenTypeShare:
                    SearchGetNumOfContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Share);
                    break;

                case ContentManagementState.SearchGetTotalContentSize_GenTypeShare:
                    SearchGetTotalContentSize(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Share);
                    break;

                case ContentManagementState.SearchGetNumOfContent_GenTypeAny:
                    SearchGetNumOfContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Any);
                    break;

                case ContentManagementState.SearchGetTotalContentSize_GenTypeAny:
                    SearchGetTotalContentSize(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Any);
                    break;

                case ContentManagementState.SearchForPhotos_GenTypeExport:
                    SearchForContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Export);
                    break;

                case ContentManagementState.SearchForVideos_GenTypeExport:
                    SearchForContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Video, ContentSearch.ContentSearchContentGeneratorType.Export);
                    break;

                case ContentManagementState.SearchForPhotos_GenTypeShare:
                    SearchForContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Share);
                    break;

                case ContentManagementState.SearchForVideos_GenTypeShare:
                    SearchForContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Video, ContentSearch.ContentSearchContentGeneratorType.Share);
                    break;

                case ContentManagementState.SearchForPhotos_GenTypeAny:
                    SearchForContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Photo, ContentSearch.ContentSearchContentGeneratorType.Any);
                    break;

                case ContentManagementState.SearchForVideos_GenTypeAny:
                    SearchForContent(m_DefaultStateTransition, ContentSearch.ContentSearchContentType.Video, ContentSearch.ContentSearchContentGeneratorType.Any);
                    break;

                case ContentManagementState.SearchGetMetadata:
                    SearchGetMetadata(m_DefaultStateTransition);
                    break;

                case ContentManagementState.SearchGetMetadataByContentID:
                    SearchGetMetadataByContentID(m_DefaultStateTransition);
                    break;

                case ContentManagementState.DeleteByPath:
                    DeleteByPath(m_DefaultStateTransition);
                    break;

                case ContentManagementState.DeleteByContentID:
                    DeleteByContentId(m_DefaultStateTransition);
                    break;

                case ContentManagementState.Wait1Second:
                    WaitSeconds(1.0f, new StateTransition(ContentManagementState.Next));
                    break;

                case ContentManagementState.WaitingForDelay:
                    UpdateDelay();
                    break;

                case ContentManagementState.Waiting:
                    // Do nothing, waiting for something to complete.
                    break;

                case ContentManagementState.WaitingForButton:
                    WaitButton(new StateTransition(ContentManagementState.Next));
                    break;

                case ContentManagementState.AllDone:
                    ContentManagementSample.OnScreenLog.Add($"All Done!");
                    m_State = ContentManagementState.Waiting;
                    break;

                case ContentManagementState.Failed:
                    ContentManagementSample.OnScreenLog.Add($"Execution stopped!");
                    m_State = ContentManagementState.Waiting;
                    break;

                default:
                    ContentManagementSample.OnScreenLog.Add($"Unhandled state {m_State}");
                    m_State = ContentManagementState.Failed;
                    break;
            }
        }

        string GetDiagnosticInfo()
        {
            string text = $"\nCurrent state: {m_State}";

            if (m_State == ContentManagementState.WaitingForButton)
            {
                text += $"\n\nPress X To Continue";
            }

            if (m_ActiveExportID >= 0)
            {
                int exportProgress = ContentExport.ExportGetProgress(m_ActiveExportID);
                text += $"\nCurrent export progress: {exportProgress}";
            }

            return text;
        }
    }
}
#endif
