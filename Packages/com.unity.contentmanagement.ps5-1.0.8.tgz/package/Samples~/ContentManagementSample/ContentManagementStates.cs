#if UNITY_PS5
using System.Collections.Generic;
using UnityEngine;
using Unity.ContentManagement;
using Unity.ContentManagement.PS5.Aysnc;

namespace ContentManagementSample
{
    public enum ContentManagementState
    {
        // States used for flow control and general house-keeping.
        NullState,
        Uninitialized,
        Next,
        AllDone,
        Failed,
        Waiting,
        Wait1Second,
        WaitingForDelay,
        WaitingForButton,

        // States that test some aspect of the ContentManagement library.
        Initialize,
        Terminate,

        ExportFromFile,
        ExportFromFileWithThumbnail,
        ExportFromData,
        ExportFromDataWithThumbnail,

        SearchGetLastUpdateID,
        SearchGetNumOfContent_GenTypeExport,        SearchGetNumOfContent_GenTypeShare,         SearchGetNumOfContent_GenTypeAny,
        SearchGetTotalContentSize_GenTypeExport,    SearchGetTotalContentSize_GenTypeShare,     SearchGetTotalContentSize_GenTypeAny,
        SearchForPhotos_GenTypeExport,              SearchForPhotos_GenTypeShare,               SearchForPhotos_GenTypeAny,
        SearchForVideos_GenTypeExport,              SearchForVideos_GenTypeShare,               SearchForVideos_GenTypeAny,
        SearchGetMetadata,
        SearchGetMetadataByContentID,

        DeleteByPath,
        DeleteByContentID,
    }

    public class StateTransition
    {
        public StateTransition(ContentManagementState _onSuccess)
        {
            whileWaiting = ContentManagementState.Waiting;
            onSuccess = _onSuccess;
            onFailure = ContentManagementState.Failed;
        }

        public StateTransition(ContentManagementState _whileWaiting, ContentManagementState _onSuccess)
        {
            whileWaiting = _whileWaiting;
            onSuccess = _onSuccess;
            onFailure = ContentManagementState.Failed;
        }

        public StateTransition(ContentManagementState _whileWaiting, ContentManagementState _onSuccess, ContentManagementState _onFailure)
        {
            whileWaiting = _whileWaiting;
            onSuccess = _onSuccess;
            onFailure = _onFailure;
        }

        ContentManagementState whileWaiting;       // State to set while waiting for the request to complete.
        ContentManagementState onSuccess;          // State to set when the request completes succesfully.
        ContentManagementState onFailure;          // State to set when the request fails.

        public ContentManagementState SetStateWaiting(ContentManagementState currentState, string message="")
        {
            if (!string.IsNullOrEmpty(message))
                OnScreenLog.Add(message);

            if (whileWaiting != ContentManagementState.NullState)
                currentState = whileWaiting;

            return currentState;
        }

        public ContentManagementState SetStateSucceeded(ContentManagementState currentState, string message="")
        {
            if (!string.IsNullOrEmpty(message))
                OnScreenLog.Add(message);

            if (onSuccess != ContentManagementState.NullState)
                currentState = onSuccess;

            return currentState;
        }

        public ContentManagementState SetStateFailed(ContentManagementState currentState, string message="")
        {
            if (!string.IsNullOrEmpty(message))
                OnScreenLog.Add(message);

            if (onFailure != ContentManagementState.NullState)
                currentState = onFailure;

            return currentState;
        }

        public ContentManagementState SetCompletionState(ContentManagementState currentState, bool succeeded)
        {
            if (onSuccess != ContentManagementState.NullState && onFailure != ContentManagementState.NullState)
                currentState = succeeded ? onSuccess : onFailure;
            return currentState;
        }
    }
}
#endif
