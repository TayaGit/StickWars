using UnityEngine;
using UnityEditor;
using System.IO;
using System;

#if UNITY_PS5
namespace PS5ContentManagementSample
{
    public class SetPlatformOptionsPS5
    {
        /// <summary>
        /// Setup streaming assets and player settings for the PS5 sample project.
        /// </summary>
        [MenuItem("PS5 Utils/Content Management Sample/Prepare Project Assets And Settings")]
	    static void SetOptions()
	    {
		    PlayerSettings.productName = "Unity ContentManagement Example";

            CopyStreamingAssets();

            SetParamFile();

            AssetDatabase.Refresh();
        }

        static void CopyStreamingAssets()
        {
            string sourceDir = SearchForDirectory(Application.dataPath, "SampleStreamingAssets", "Content Management Sample");
            if (String.IsNullOrEmpty(sourceDir))
            {
                // Try alternative (currently needed if running from git repo instead of installed package).
                sourceDir = SearchForDirectory(Application.dataPath, "SampleStreamingAssets", "Samples/ContentManagementSample");
            }

            if (String.IsNullOrEmpty(sourceDir))
            {
                Debug.LogWarning($"Streaming assets not found");
                return;
            }

            sourceDir = sourceDir.Replace(Application.dataPath, "Assets");
            Debug.Log($"Found streaming assets @ \"{sourceDir}\"");

            string streamingDir = "Assets/StreamingAssets";
            if (Directory.Exists(streamingDir) == false)
                Directory.CreateDirectory(streamingDir);

            // Enumerate assets in sourceDir
            var files = Directory.EnumerateFiles(sourceDir, "*.*", SearchOption.AllDirectories);
            foreach(var file in files)
            {
                string cleanFile = file.Replace("\\", "/");
                string targetFile = $"{streamingDir}/{Path.GetFileName(cleanFile)}";
                if (!cleanFile.EndsWith(".meta"))
                {
                    if (!AssetDatabase.CopyAsset(cleanFile, targetFile))
                    {
                        Debug.LogWarning($"Failed to copy streaming asset \"{cleanFile}\" to \"{targetFile}\"");
                    }
                }
            }
        }

        static void SetParamFile()
        {
            // Setup param file for the sample.
            string sourceFile = SearchForFile(Application.dataPath, "param.json", false, "Content Management Sample/SampleSystemFiles");
            if (String.IsNullOrEmpty(sourceFile))
            {
                // Try alternative (currently needed if running from git repo instead of installed package).
                sourceFile = SearchForFile(Application.dataPath, "param.json", false, "Samples/ContentManagementSample/SampleSystemFiles");
            }
            sourceFile = sourceFile.Replace(Application.dataPath, "Assets");

#if UNITY_2020_1_OR_NEWER
            UnityEditor.PS5.PlayerSettings.paramFilePath = sourceFile;
#else
            UnityEditor.PlayerSettings.PS5.paramFilePath = sourceFile;
#endif

            Debug.Log($"Found param.json @ \"{sourceFile}\"");
        }

        static string SearchForDirectory(string path, string findDir, string matchPath)
        {
            var dirs = Directory.EnumerateDirectories(path, "*.*", SearchOption.AllDirectories);

            if (!String.IsNullOrEmpty(matchPath))
                matchPath = matchPath.Replace("\\", "/");

            foreach (var dir in dirs)
            {
                string cleanDir = dir.Replace("\\", "/");
                if (!String.IsNullOrEmpty(matchPath))
                {
                    if (!cleanDir.Contains(matchPath))
                        continue;
                }

                string dirName = new DirectoryInfo(cleanDir).Name;
                if (dirName == findDir)
                    return cleanDir;
            }

            return "";
        }

        static string SearchForFile(string path, string findFilename, bool ignoreExtension, string matchPath)
        {
            var files = Directory.EnumerateFiles(path, "*.*", SearchOption.AllDirectories);

            if (!String.IsNullOrEmpty(matchPath))
                matchPath = matchPath.Replace("\\", "/");

            foreach (var file in files)
            {
                string cleanFile = file.Replace("\\", "/");
                if (!String.IsNullOrEmpty(matchPath))
                {
                    if (!cleanFile.Contains(matchPath))
                        continue;
                }

                if (ignoreExtension && Path.GetFileNameWithoutExtension(cleanFile) == findFilename)
                    return cleanFile;

                if (Path.GetFileName(cleanFile) == findFilename)
                    return cleanFile;
            }

            return "";
        }
    }
}
#endif
