using UnityEngine;
using System.Collections;

public class Rotate : MonoBehaviour
{
	public Vector3 m_Rate;
	public bool m_RandomizedRate = false;

	// Use this for initialization
	void Start ()
	{
		if (m_RandomizedRate)
		{
			m_Rate = new Vector3(Random.Range(25.0f, 75.0f), Random.Range(25.0f, 75.0f), Random.Range(25.0f, 75.0f));
		}
	}

	// Update is called once per frame
	void Update()
	{
		Vector3 a = m_Rate * Time.deltaTime;
		transform.Rotate(a);
	}
}
