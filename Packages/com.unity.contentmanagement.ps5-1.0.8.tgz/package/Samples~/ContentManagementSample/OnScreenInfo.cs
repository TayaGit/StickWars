using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.Rendering;
#if PLATFORM_PS5 && !UNITY_EDITOR
using UnityEngine.PS5;
#endif

namespace ContentManagementSample
{
    /// <summary>
    ///  Class for displaying some useful diagnostic info, e.g. frame time, device state, etc.
    /// </summary>
    public class OnScreenInfo : MonoBehaviour
    {
        public UnityEngine.UI.Text m_UIText;
        public bool m_ShowCameraStates = true;
        public bool m_ShowQualitySettings = true;
        public bool m_ShowVideoOutSettings = true;

        public float m_UpdateInterval = 0.5f;

        float m_Time = 0.0f;
        float m_LastInterval; // Last interval end time
        float m_Frames = 0; // Frames over current interval
        float m_AverageMilliseconds = 0.0f; // Average frame millisecond duration
        bool m_HasUIText = false;

        public class LogEventArgs { public string logText; }
        public delegate void LogEventHandler(LogEventArgs eventArgs);
        public static LogEventHandler sm_LogEventHandlers;

        void Start()
        {
            m_LastInterval = Time.realtimeSinceStartup;
            m_Frames = 0;
            if (m_UIText != null)
            {
                m_HasUIText = true;
            }
        }

        void Update()
        {
            m_Time += Time.deltaTime;
            m_Frames++;

            float timeNow = Time.realtimeSinceStartup;
            if (timeNow > m_LastInterval + m_UpdateInterval)
            {
                m_AverageMilliseconds = (timeNow - m_LastInterval) / m_Frames * 1000.0f;
                m_Frames = 0;
                m_LastInterval = timeNow;
            }

            if (m_HasUIText)
            {
                const string separator = ", ";
                const string lineSeparator = "\n";
                string frameTime = m_AverageMilliseconds.ToString("f2") + "ms";
                string unityVersion = separator + "unity " + Application.unityVersion;
                string gfxDeviceVersion = $"{separator} gfx type {SystemInfo.graphicsDeviceType}, gfx version {SystemInfo.graphicsDeviceVersion}";

                string miscInfo = lineSeparator;
                miscInfo += $"Frame count: {Time.frameCount.ToString()}{lineSeparator}";
                miscInfo += $"Time: {m_Time}{lineSeparator}";

                LogEventArgs logEventArgs = new LogEventArgs();
                if (sm_LogEventHandlers != null)
                    sm_LogEventHandlers(logEventArgs);

                m_UIText.text = frameTime + unityVersion + gfxDeviceVersion + miscInfo + /*appParams +*/ lineSeparator + logEventArgs.logText;
            }
        }
    }
}
