

# Initializing the PS5 Content Management plugin

Initialize the Playstation 5 (PS5) Content Management plugin with the following code samples. You can run this code from the main script in `Update` or from your `Start` function. To view an implementation of this in a project, see the [Content Management sample project](Sample.md).

For a full list of supported features see the documentation on [C# API features](Features.md).

To initialize the library, run this code:


```
   // Contains the results of initialization including the SDK version of the native plugin.
    InitResult initResult;

    try
    {
        InitSettings settings = new InitSettings();

        // Initialize the system.
        initResult = Main.Initialize(settings);

        if (initResult.Initialized == true)
        {
            // Initialization succeeded
        }
        else
        {
            // Initialization failed
        }
    }
    catch (ContentManagementException e)
    {
        // Exception - See e.ExtendedMessage for more info
    }
```


To terminate the library, run this code:


```
    try
    {
        Main.Terminate();
    }
    catch (ContentManagementException e)
    {
        // Exception - See e.ExtendedMessage for more info
    }


