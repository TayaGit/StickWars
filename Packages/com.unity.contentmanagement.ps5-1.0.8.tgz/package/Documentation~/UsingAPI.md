
# Using the PS5 Content Management package

The Playstation 5 (PS5) Content Management package enables you to export and manage content created by your application. This document shows how to use the Content Management API.  To view the following APIs in a project setting see the [Content Management Sample](Sample.md) project.
