# Getting started with the PS5 Content Management package

The PlayStation 5 (PS5) Content Management package enables your application to export and manage content created by your application.

<!-- This package provides offline HTML documentation. Open `HTML~/index.html` from the package directory to view it locally. -->

Sony provides the native Playstation 5 (PS5) Content Export, Content Search, and Content Delete Libraries in C++. The PS5 Content Management package gives you access to the PS5 Content libraries from C#, so you can use them for development in the Unity Editor.

This document is for developers who want to use the PS5 Content libraries in their Unity for PS5 project without writing their own native plugin. For more details, see Sony’s library docs... [Content Export Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/ContentExport-Overview/__toc.html)
[Content Search Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/ContentSearch-Overview/__toc.html)
[Content Delete Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/ContentDelete-Overview/__toc.html)

**Note**: This documentation does not discuss any Technical Requirements Checklist (TRC) criteria. See the Sony documentation for the latest compliance requirements.

The PS5 Content Management package contains the following:

*   A C# API that provides the native PS5 Content Management Library functionality. For an overview of the features the PS5 Content Management package supports, see the [C# API features list](Features.md) documentation.
*   A native .PRX plugin that provides the interface between the C# API and the native PS5 Content Management Libraries.
*   The C++ source code for this native plugin. This lives in the `source~` folder.


## Prerequisites

To use the PS5 Content Management package, meet the following prerequisites:

*   You must have the PS5 for Unity add-on installed. To do this, go to the [Unity for PlayStation 5 downloads](https://discussions.unity.com/t/unity-for-playstation-5-downloads/1568719) Unity Discussions page and select your download based on your Unity version.
*   You must have a Unity Pro subscription. If you don't have a Unity Pro subscription, please contact Unity or your Unity account manager.
*   You must have a PS5 Development Kit or Testing Kit. For more information see Sony’s [Development Kit Setup Guide](https://game.develop.playstation.net/resources/documents/SDK/latest/DevKit-Setup_Guide/0001.html) and [Testing Kit Setup Guide](https://game.develop.playstation.net/resources/documents/SDK/latest/TestKit-Setup_Guide/__toc.html).


# Installation

The PS5 is an NDA platform. For this reason, you can’t search for and download packages directly from the Package Manager.

To install the com.unity.contentmanagement.ps5 package:

1. Go to the [PlayStation 5 Package Downloads](https://discussions.unity.com/t/playstation-5-package-downloads/1568720) Unity Discussions page.
2. Select and download the PS5 Content Management Library package tarball (`.tgz`).
3. Open the Package Manager window (**Window** > **Package Manager**).
4. In the top-left corner of the window, select the **Add (+)** button.
5. Select **Add Package from Tarball**.
6. In the dialog that displays, select the PS5 Content Management package .tgz file and select **OK**.

This installs the package into your Unity project.

You must initialize the installed PS5 Content Management package. To do this, see the [Initializing the Content Management library](Initialization.md) documentation.
