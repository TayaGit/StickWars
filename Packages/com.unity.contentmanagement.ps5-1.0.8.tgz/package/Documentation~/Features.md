# C# API features for Playstation 5 Content Management

Sony provides the native Playstation 5 (PS5) Content Export, Content Search, and Content Delete Libraries in C++. The PS5 Content Management package gives you access to the PS5 Content libraries from C#, so you can use them for development in the Unity Editor.

This page gives you an overview of the main C# API features provided with the PS5 Content Management package. To view these features in a project, see the [Content Management sample project](Sample.md).

The following table outlines each API class and its use. For further information, see the PS5 Content Management package’s [scripting reference](../api/Unity.ContentManagement.PS5.Main.html) documentation.

|**API class**|**Description**|
|---|---|---|
[Main.Initialize](../api/Unity.ContentManagement.PS5.Main.html#Unity_ContentManagement_PS5_Main_Initialize)|Initializes the PS5 Content Management system. You must initialize the Content Management system before you can use it. For more information see, [Initializing the PS5 Content Management Library](Initialization.md)|
[Main.Terminate](../api/Unity.ContentManagement.PS5.Main.html#Unity_ContentManagement_PS5_Main_Terminate)|Shuts down the Share system and unloads the native Share Library|
[Main.Update](../api/Unity.ContentManagement.PS5.Main.html#Unity_ContentManagement_PS5_Main_Update)|Updates the PS5 Share system’s internal state and monitors content creation. |
