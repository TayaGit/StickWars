﻿#if UNITY_PS5
using NUnit.Framework;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PS5;

namespace ContentManagementTests
{
    public class BaseTestFramework
    {
        [OneTimeSetUp]
        public void Setup()
        {

        }

        enum InitState
        {
            Started,
            Initialising,
            Ready,
            Error,
        }

        static InitState s_CurrentInitState = InitState.Started;

        static public string s_InitOutput = "";

        bool initOK = false;

        public bool IsInitialized()
        {
            if (s_CurrentInitState == InitState.Ready)
            {
                return true;
            }

            // Give the app time to start up
            if (Time.realtimeSinceStartup < 5.0f)
            {
                return false;
            }

            switch(s_CurrentInitState)
            {
                case InitState.Started:
                    initOK = InitializePlugin();
                    s_CurrentInitState = InitState.Initialising;
                    break;

                case InitState.Initialising:
                    if (initOK == true) s_CurrentInitState = InitState.Ready;
                    else s_CurrentInitState = InitState.Error;               
                    break;

                case InitState.Error:
                    break;
            }

            return false;
        }

        static public Unity.ContentManagement.PS5.Initialization.InitResult initResult;
       
        private bool InitializePlugin()
        {
            try
            {
                 initResult =Unity.ContentManagement.PS5.Main.Initialize();
                if (initResult.Initialized == true)
                {
                    Debug.Log("ContentManagement library initialized ");
                }
                else
                {
                    Debug.Log("ContentManagement library not initialized ");
                }
                return initResult.Initialized;
            }
            catch(System.Exception e)
            {
                Debug.Log($"Failed to initialize the ContentManagement library plugin\n{e}");
            }
            return false;
        }

    }
}
#endif