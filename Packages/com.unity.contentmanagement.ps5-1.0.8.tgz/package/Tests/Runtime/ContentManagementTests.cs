﻿#if UNITY_PS5
using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using UnityEngine.PS5;
using System;
using System.IO;
using System.Collections.Generic;
using Unity.ContentManagement.PS5;

namespace ContentManagementTests
{
    public partial class Tests : BaseTestFramework
    {
        [UnityTest, Order(30), Description("Create ContentManagement")]
        public IEnumerator C_CreateContentManagement()
        {
            yield return new WaitUntil(IsInitialized);

            Assert.AreEqual(IsInitialized(), true);

            Debug.Log("Create ContentManagement finished");
        }
    }
}
#endif

