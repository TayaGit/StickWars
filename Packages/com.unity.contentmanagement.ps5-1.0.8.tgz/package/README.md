# PS5 Content Management Library

Provides a C# API for accessing the PlayStation 5 Content Management libaries.
