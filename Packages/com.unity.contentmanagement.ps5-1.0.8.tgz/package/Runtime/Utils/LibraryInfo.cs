
namespace Unity.ContentManagement.PS5
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "ContentManagement";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
