
using System;
using System.Runtime.InteropServices;

using Unity.ContentManagement.PS5.Aysnc;
using Unity.ContentManagement.PS5.Internal;

namespace Unity.ContentManagement.PS5
{
    /// <summary>
    /// Class containing methods for exporting content to the PS5 content library.
    /// </summary>
    public class ContentExport
    {
        #region DLL Import
        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxContentExportStart(out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxContentExportFinish(int exportID, out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxContentExportGetProgress(int exportID, out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxContentExportCancel(int exportID, out APIResult result);
        #endregion

        /// <summary>
        /// Specifies the format of the data when exporting to the content library.
        /// </summary>
        public enum ContentExportFormatType // Values are indices into the native plugins ContentExport::sm_ExportTypeStrings array.
        {
            /// <summary>
            /// A jpg formatted image.
            /// </summary>
            ContentExportFormatImageJpeg = 0,
            /// <summary>
            /// A png formatted image.
            /// </summary>
            ContentExportFormatImagePng = 1,
            /// <summary>
            /// A gif formatted image.
            /// </summary>
            ContentExportFormatImageGif = 2,
            /// <summary>
            /// An mp4 video.
            /// </summary>
            ContentExportFormatVideoMp4 = 3,
            /// <summary>
            /// A webm video.
            /// </summary>
            ContentExportFormatVideoWebm = 4
        };

        /// <summary>
        /// Starts export processing.
        /// </summary>
        /// <returns>
        /// Returns the export ID.
        /// </returns>
        /// <exception cref="ContentManagementException"></exception>
        public static int ExportStart()
        {
            APIResult result;
            int exportID = PrxContentExportStart(out result);
            if (result.RaiseException == true)
                throw new ContentManagementException(result);
            return exportID;
        }

        /// <summary>
        /// Finishes export processing
        /// </summary>
        /// <param name="exportID">
        /// The export ID that was returned by ContentExport.ExportStart()
        /// </param>
        /// <exception cref="ContentManagementException"></exception>
        public static void ExportFinish(int exportID)
        {
            APIResult result;
            PrxContentExportFinish(exportID, out result);
            if (result.RaiseException == true)
                throw new ContentManagementException(result);
        }

        /// <summary>
        /// Obtains the current progress for the active export.
        /// </summary>
        /// <param name="exportID">
        /// The export ID that was returned by ContentExport.ExportStart()
        /// </param>
        /// <returns>Returns the export progress as a percentage.</returns>
        /// <exception cref="ContentManagementException"></exception>
        public static int ExportGetProgress(int exportID)
        {
            APIResult result;
            int progress = PrxContentExportGetProgress(exportID, out result);
            if (result.RaiseException == true)
                throw new ContentManagementException(result);
            return progress;
        }

        /// <summary>
        /// Cancels export processing
        /// </summary>
        /// <param name="exportID">
        /// The export ID that was returned by ContentExport.ExportStart()
        /// </param>
        /// <exception cref="ContentManagementException"></exception>
        public static void ExportCancel(int exportID)
        {
            APIResult result;
            PrxContentExportCancel(exportID, out result);
            if (result.RaiseException == true)
                throw new ContentManagementException(result);
        }

        /// <summary>
        /// Export a file to the PS5 content library.
        /// </summary>
        public class ExportFromFileRequest : Request
        {
            /// <summary>
            /// The export ID that was returned by ContentExport.ExportStart()
            /// </summary>
            public int ExportID { get; set; }
            /// <summary>
            /// Specifies the data format for the content being exported.
            /// </summary>
            public ContentExportFormatType ContentExportFormat { get; set; }
            /// <summary>
            /// The title to assign to the exported content in the PS5 content library.
            /// </summary>
            public string Title { get; set; }
            /// <summary>
            /// The source file path of the content to be exported.
            /// </summary>
            public String SrcFilePath{ get; set; }
            /// <summary>
            /// The source file path of the thumbnail image to assign to the content. Can be an empty string in which case the system software will generate a thumbnail.
            /// </summary>
            public String SrcThumbnailFilePath{ get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ExportFromFile);
                nativeMethod.Writer.Write(ExportID);
                nativeMethod.Writer.WritePrxString(Title);
                nativeMethod.Writer.Write((int)ContentExportFormat);
                nativeMethod.Writer.WritePrxString(SrcFilePath);
                nativeMethod.Writer.WritePrxString(SrcThumbnailFilePath);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Export data held in memory to the PS5 content library.
        /// </summary>
        public class ExportFromDataRequest : Request
        {
            /// <summary>
            /// The export ID that was returned by ContentExport.ExportStart()
            /// </summary>
            public int ExportID { get; set; }
            /// <summary>
            /// The title to assign to the exported content in the PS5 content library.
            /// </summary>
            public string Title { get; set; }
            /// <summary>
            /// Specifies the data format for the content being exported.
            /// </summary>
            public ContentExportFormatType ContentExportFormat { get; set; }
            /// <summary>
            /// A byte array containing the content data to be exported.
            /// </summary>
            public byte[] ContentData { get; set; }
            /// <summary>
            /// Specifies the data format for thumbnail being exported.
            /// </summary>
            public ContentExportFormatType ThumbnailExportFormat { get; set; }
            /// <summary>
            /// A byte array containing a thumbnail image that will be used for the content when displayed in the PS5 content library.
            /// </summary>
            public byte[] ThumbnailData { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ExportFromData);
                nativeMethod.Writer.Write(ExportID);
                nativeMethod.Writer.WritePrxString(Title);

                nativeMethod.Writer.Write((int)ContentExportFormat);
                nativeMethod.Writer.Write(ContentData.Length);
                GCHandle pinnedContentData = GCHandle.Alloc(ContentData, GCHandleType.Pinned);
                IntPtr sourcePointer = pinnedContentData.AddrOfPinnedObject();
                nativeMethod.Writer.WriteIntPtr(sourcePointer);

                int thumbnailDataLength = 0;
                if (ThumbnailData != null)
                    thumbnailDataLength = ThumbnailData.Length;

                nativeMethod.Writer.Write((int)ThumbnailExportFormat);
                nativeMethod.Writer.Write(thumbnailDataLength);
                GCHandle pinnedThumbnailData = GCHandle.Alloc(ThumbnailData, GCHandleType.Pinned);
                IntPtr sourceThumbnailPointer = pinnedThumbnailData.AddrOfPinnedObject();
                nativeMethod.Writer.WriteIntPtr(sourceThumbnailPointer);

                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);

                pinnedContentData.Free();
                pinnedThumbnailData.Free();
            }
        }
    }
}
