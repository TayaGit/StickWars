
using System;
using System.Runtime.InteropServices;

using Unity.ContentManagement.PS5.Initialization;
using Unity.ContentManagement.PS5.Aysnc;
using Unity.ContentManagement.PS5.Internal;

namespace Unity.ContentManagement.PS5
{
    /// <summary>
    /// Main entry point to the ContentManagement system and initialization
    /// </summary>
    public class Main
    {
        #region DLL Import
        [DllImport(LibraryInfo.LibraryName)]
        private static extern void ContentMan_PrxInitialize(out NativeInitResult initResult, out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void ContentMan_PrxShutDown();
        #endregion

        // must match enum in ContentManagement.h
        internal enum NativeMethods : UInt32
        {
            Initialise = 0x0200001u,
            Terminate = 0x0200002u,
            ExportFromFile = 0x0200003u,
            ExportFromData = 0x0200004u,
            ContentSearchFor = 0x0200005u,
            ContentSearchGetNumOfContent = 0x0200006u,
            ContentSearchGetTotalContentSize = 0x0200007u,
            ContentSearchGetMetadata = 0x0200008u,
            ContentSearchGetMetadataByContentId = 0x0200009u,
            ContentDeleteByPath = 0x020000au,
            ContentDeleteByContentId = 0x020000bu,
        }

        static WorkerThread workerQueue = new WorkerThread();

        // A global struct showing if ContentManagement has been initialized and the SDK version number for the native plugin.
        static internal InitResult m_InitResult;

        /// <summary>
        /// Initialise the Unity ContentManagement system
        /// </summary>
        /// <returns>Returns the results of initialization including the SDK version. <see cref="InitResult"/></returns>
        public static InitResult Initialize()
        {
            APIResult result;

            NativeInitResult nativeResult = new NativeInitResult();

            ContentMan_PrxInitialize(out nativeResult, out result);

            if (result.RaiseException == true)
                throw new ContentManagementException(result);

            MarshalMethods.Initialize();

            m_InitResult.Initialize(nativeResult);

            Start();

            return m_InitResult;
        }

        /// <summary>
        /// Shutdown the Unity ContentManagement system
        /// </summary>
        public static void ShutDown()
        {
            ContentMan_PrxShutDown();
        }

        internal static void Start()
        {
            workerQueue.Start("ContentManagement");
        }

        /// <summary>
        /// Schedule an <see cref="AsyncOp"/> by adding it to the internal UniversalDataSystem queue
        /// </summary>
        /// <param name="op">The operation to schedule</param>
        public static void Schedule(AsyncOp op)
        {
            workerQueue.Schedule(op);
        }

        /// <summary>
        /// Initialise the ContentManagement system.
        /// </summary>
        public class InitialiseRequest : Request
        {
            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Initialise);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Terminates the ContentManagement system.
        /// </summary>
        public class TerminateRequest : Request
        {
            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Terminate);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }
    }
}
