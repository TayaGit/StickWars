
using System;
using System.IO;
using System.Runtime.InteropServices;

using Unity.ContentManagement.PS5.Aysnc;
using Unity.ContentManagement.PS5.Internal;

namespace Unity.ContentManagement.PS5
{
    /// <summary>
    /// Class containing methods for searching for content in the PS5 content library.
    /// </summary>
    public class ContentSearch
    {
        /// <summary>
        /// Enum constants representing the content type.
        /// </summary>
        public enum ContentSearchContentType
        {
            /// <summary>
            /// Type is unknown.
            /// </summary>
            Unknown,
            /// <summary>
            /// Still image.
            /// </summary>
            Photo,
            /// <summary>
            /// Video.
            /// </summary>
            Video
        }

        /// <summary>
        /// Enum constants representing the feature used when generating content.
        /// </summary>
        public enum ContentSearchContentGeneratorType
        {
            /// <summary>
            /// Unknown generator (or any generator if specified as a search parameter).
            /// </summary>
            Any,
            /// <summary>
            /// Unknown generator (or any generator if specified as a search parameter).
            /// </summary>
            Unknown = Any,
            /// <summary>
            /// Indicates that content has been registered with the Share button.
            /// </summary>
            Share,
            /// <summary>
            /// Indicates that content has been registered using the ContentExport API.
            /// </summary>
            Export,
            /// <summary>
            /// Indicates that the system video-trimming or still image editing feature was used on the content in the Share feature or the Media Gallery before it was registered.
            /// </summary>
            SystemEdit,
            /// <summary>
            /// Indicates that content has been registered using the Share library API.
            /// </summary>
            ShareLibrary,
        }

        /// <summary>
        /// Enum constants representing content MIME types.
        /// </summary>
        public enum ContentSearchMimeType
        {
            /// <summary>
            /// Unknown type.
            /// </summary>
            Unknown,
            /// <summary>
            /// image/jpeg
            /// </summary>
            ImageJpeg,
            /// <summary>
            /// video/mp4
            /// </summary>
            VideoMp4,
            /// <summary>
            /// image/png
            /// </summary>
            ImagePng,
            /// <summary>
            /// image/gif
            /// </summary>
            ImageGif,
            /// <summary>
            /// video/webm
            /// </summary>
            VideoWebm,
            /// <summary>
            /// reserved
            /// </summary>
            Reserved,
            /// <summary>
            /// audio/mpeg
            /// </summary>
            AudioMpeg = 0x1000,
            /// <summary>
            /// audio/mp4
            /// </summary>
            AudioMp4,
            /// <summary>
            /// audio/mp3
            /// </summary>
            AudioMp3,
            /// <summary>
            /// audio/aac
            /// </summary>
            AudioAac,
            /// <summary>
            /// audio/wab
            /// </summary>
            AudioWav,
            /// <summary>
            /// audio/vorbis
            /// </summary>
            AudioVorbis,
            /// <summary>
            /// audio/opus
            /// </summary>
            AudioOpus,
        }

        /// <summary>
        /// Enum constants representing content status.
        /// </summary>
        public enum ContentSearchContentStatus
        {
            /// <summary>
            /// Broken
            /// </summary>
            Broken,
            /// <summary>
            /// Available
            /// </summary>
            Available
        }

        /// <summary>
        /// Enum constants representing content upload status.
        /// </summary>
        public enum ContentSearchUploadStatus
        {
            /// <summary>
            /// Not uploaded
            /// </summary>
            NotUploaded,
            /// <summary>
            /// Uploaded
            /// </summary>
            Uploaded
        }

        /// <summary>
        /// Enum constants representing content favourite status.
        /// </summary>
        public enum ContentSearchFavoriteStatus
        {
            /// <summary>
            /// Not added to favourites.
            /// </summary>
            NotAdded,
            /// <summary>
            /// Added to favourites.
            /// </summary>
            Added
        }

        internal enum ContentSearchContentColumnIndex
        {
	        ContentId = 1,
	        MimeType,
	        ContentType,
	        Title,
	        CreatedTime,
	        Size,
	        UserAccount,
	        Duration = 9,
	        ContentPath,
	        GeneratorType,
	        Status,
	        UploadStatus = 14,
        }

        /// <summary>
        /// Enum constants representing columns to specify for the search conditions for content searching.
        /// </summary>
        public enum ContentSearchContentColumnType
        {
            /// <summary>
            /// Content ID.
            /// </summary>
	        ContentId = ContentSearchContentColumnIndex.ContentId,
            /// <summary>
            /// MIME type.
            /// </summary>
	        MimeType = ContentSearchContentColumnIndex.MimeType,
            /// <summary>
            /// Content type.
            /// </summary>
	        ContentType = ContentSearchContentColumnIndex.ContentType,
            /// <summary>
            /// Content title.
            /// </summary>
	        Title = ContentSearchContentColumnIndex.Title,
            /// <summary>
            /// Content creation time/date.
            /// </summary>
	        CreatedTime = ContentSearchContentColumnIndex.CreatedTime,
            /// <summary>
            /// Content size.
            /// </summary>
	        Size = ContentSearchContentColumnIndex.Size,
            /// <summary>
            /// User account.
            /// </summary>
	        UserAccount = ContentSearchContentColumnIndex.UserAccount,
            /// <summary>
            /// Reserved.
            /// </summary>
	        Reserved = 8,
            /// <summary>
            /// Playback time (seconds).
            /// </summary>
	        Duration = ContentSearchContentColumnIndex.Duration,
            /// <summary>
            /// The file path of the content.
            /// </summary>
	        ContentPath = ContentSearchContentColumnIndex.ContentPath,
            /// <summary>
            /// Feature used for content generation.
            /// </summary>
	        GeneratorType = ContentSearchContentColumnIndex.GeneratorType,
            /// <summary>
            /// Content status.
            /// </summary>
	        Status = ContentSearchContentColumnIndex.Status,
            /// <summary>
            /// Content upload status.
            /// </summary>
	        UploadStatus = ContentSearchContentColumnIndex.UploadStatus
        }

        /// <summary>
        /// Enum constants representing the comparison operators to set for the search column conditions.
        /// </summary>
        public enum ContentSearchColumnValueOperator
        {
            /// <summary>
            /// Is equal to.
            /// </summary>
	        Equal,
            /// <summary>
            /// Is not equal to.
            /// </summary>
            NotEqual,
            /// <summary>
            /// Is greater than.
            /// </summary>
            Greater,
            /// <summary>
            /// Is greater than or equal to.
            /// </summary>
            GreaterEqual,
            /// <summary>
            /// Is less than.
            /// </summary>
            Less,
            /// <summary>
            /// Is less than or equal to.
            /// </summary>
            LessEqual
        }

        /// <summary>
        /// Enum constants representing operators that connect column conditions or column condition sets.
        /// </summary>
        public enum ContentSearchLogicalConnector
        {
            /// <summary>
            /// Connect with AND condition.
            /// </summary>
	        And,
            /// <summary>
            /// Connect with OR condition.
            /// </summary>
	        Or,
            /// <summary>
            /// Do not connect.
            /// </summary>
	        None
        }

        /// <summary>
        /// Enum constants representing columns to specify for sort conditions for content searching.
        /// </summary>
        public enum ContentSearchContentSortColumnType
        {
            /// <summary>
            /// Content ID.
            /// </summary>
	        ContentId = ContentSearchContentColumnIndex.ContentId,
            /// <summary>
            /// Content title.
            /// </summary>
	        Title = ContentSearchContentColumnIndex.Title,
            /// <summary>
            /// Content creation time/date.
            /// </summary>
	        CreatedTime = ContentSearchContentColumnIndex.CreatedTime,
            /// <summary>
            ///  Content size.
            /// </summary>
	        Size = ContentSearchContentColumnIndex.Size,
            /// <summary>
            /// Reserved.
            /// </summary>
	        Reserved = 8,
            /// <summary>
            /// Playback time (seconds).
            /// </summary>
	        Duration = ContentSearchContentColumnIndex.Duration,
            /// <summary>
            /// Actual file path of the content.
            /// </summary>
	        ContentPath = ContentSearchContentColumnIndex.ContentPath
        }

        /// <summary>
        /// Enum constants representing sort orders for search results.
        /// </summary>
        public enum ContentSearchSortType
        {
            /// <summary>
            /// Ascending order.
            /// </summary>
            Ascendant,
            /// <summary>
            /// Descending order.
            /// </summary>
            Descendant
        }

        /// <summary>
        /// Structure defining content search sort conditions.
        /// </summary>
        public struct ContentSearchContentOrderByCondition
        {
            /// <summary>
            /// Column to specify as a sort condition.
            /// </summary>
            public ContentSearchContentSortColumnType columnType;
            /// <summary>
            /// Ascending order or descending order.
            /// </summary>
            public ContentSearchSortType sortType;

            /// <summary>
            /// Write this structure to a binary buffer.
            /// </summary>
            /// <param name="writer">The binary write the data will be written to</param>
            public void Write(BinaryWriter writer)
            {
                writer.Write((int)columnType);
                writer.Write((int)sortType);
            }
        }

        /// <summary>
        /// Enum constants representing the type that is stored in a ContentSearchValue structure.
        /// </summary>
        public enum ContentSearchValueType
        {
            /// <summary>
            /// 64 bit integer.
            /// </summary>
            Int,
            /// <summary>
            /// Floating point value.
            /// </summary>
            Float,
            /// <summary>
            /// A null terminated string.
            /// </summary>
            Text,
            /// <summary>
            /// An RTC tick value.
            /// </summary>
            Tick,
        }

        /// <summary>
        /// Structure holding a content search value.
        /// </summary>
        public struct ContentSearchValue
        {
            /// <summary>
            /// equals true if the value has been set.
            /// </summary>
            public bool IsValueSet { get; private set; }
            /// <summary>
            /// The values type.
            /// </summary>
	        public ContentSearchValueType type;

            /// <summary>
            /// Set a 64bit int value.
            /// </summary>
            public long IntVal { get { return vInt; } set { vInt = value; type = ContentSearchValueType.Int; IsValueSet = true; } }
            /// <summary>
            /// Set a floating point value.
            /// </summary>
            public float FloatVal { get { return vFloat; } set { vFloat = value; type = ContentSearchValueType.Float; IsValueSet = true; } }
            /// <summary>
            /// Set a string value.
            /// </summary>
            public string StringVal { get { return vText; } set { vText = value; type = ContentSearchValueType.Text; IsValueSet = true; } }
            /// <summary>
            /// Set an RTC tick value.
            /// </summary>
            public ulong TickVal { get { return vTick; } set { vTick = value; type = ContentSearchValueType.Tick; IsValueSet = true; } }

            long vInt;
	        float vFloat;
	        string vText;
	        ulong vTick;

            /// <summary>
            /// Writes the value structure to a binary buffer.
            /// </summary>
            /// <param name="writer">
            /// The BinaryWriter to write to.
            /// </param>
            /// <exception cref="Exception"></exception>
            public void Write(BinaryWriter writer)
            {
                if (IsValueSet == false)
                    throw new Exception("Attempting to write a value that has not been set.");

                writer.Write(IsValueSet);
                writer.Write((int)type);
                switch(type)
                {
                    case ContentSearchValueType.Int:
                        writer.Write(vInt);
                        break;

                    case ContentSearchValueType.Float:
                        writer.Write(vFloat);
                        break;

                    case ContentSearchValueType.Text:
                        writer.WritePrxString(vText);
                        break;

                    case ContentSearchValueType.Tick:
                        writer.Write(vTick);
                        break;
                }
            }

            /// <summary>
            /// Reads the value structure from a binary buffer.
            /// </summary>
            /// <param name="reader">
            /// The BinaryReader to read from.
            /// </param>
            /// <exception cref="Exception">Throws an exception if the value type is not recognised.</exception>
            public void Read(BinaryReader reader)
            {
                IsValueSet = reader.ReadBoolean();
                type = (ContentSearchValueType)reader.ReadInt32();
                switch(type)
                {
                    case ContentSearchValueType.Int:
                        vInt = reader.ReadInt64();
                        break;

                    case ContentSearchValueType.Float:
                        vFloat = reader.ReadSingle();
                        break;

                    case ContentSearchValueType.Text:
                        vText = reader.ReadPrxString();
                        break;

                    case ContentSearchValueType.Tick:
                        vTick = reader.ReadUInt64();
                        break;

                    default:
                        throw new Exception("Invalid type read from BinaryReader");
                }
            }

            /// <summary>
            /// Converts the value to a string.
            /// </summary>
            /// <returns>
            /// Returns the string representation of the value.
            /// </returns>
            override public string ToString()
            {
                switch(type)
                {
                    case ContentSearchValueType.Int:
                        return vInt.ToString();

                    case ContentSearchValueType.Float:
                        return vFloat.ToString();

                    case ContentSearchValueType.Text:
                        return vText;

                    case ContentSearchValueType.Tick:
                        return vTick.ToString();

                    default:
                        return "??";
                }
            }
        }

        /// <summary>
        /// This structure represents the column conditions specified for content searching.
        /// </summary>
        public struct ContentSearchContentColumn
        {
            /// <summary>
            /// Specifies the column to search for.
            /// </summary>
            public ContentSearchContentColumnType columnType;
            /// <summary>
            /// Specifies a comparison operator for comparing the target column value to search for and the value specified with value.
            /// </summary>
            public ContentSearchColumnValueOperator columnOperator;
            /// <summary>
            /// Conjunction operator to use with the previous column condition if more than one column condition is used for a search.
            /// </summary>
            public ContentSearchLogicalConnector logicalConnector;
            /// <summary>
            /// Target value for comparison for column value.
            /// </summary>
            public ContentSearchValue value;

            /// <summary>
            /// Writes the structure to a binary buffer.
            /// </summary>
            /// <param name="writer">
            /// The BinaryWriter to write to.
            /// </param>
            public void Write(BinaryWriter writer)
            {
                writer.Write((int)columnType);
                writer.Write((int)columnOperator);
                writer.Write((int)logicalConnector);
                value.Write(writer);
            }
        }

        /// <summary>
        /// This structure represents a set of column conditions to specify for content searching.
        /// </summary>
        public struct ContentSearchContentColumnSet
        {
            /// <summary>
            /// Specifies an array of ContentSearchContentColumn structures (that represent column conditions) as elements.
            /// </summary>
            public ContentSearchContentColumn[] contentColumns;
            /// <summary>
            /// Conjunction operator to use with the previous column set if more than one column set is used for a search.
            /// </summary>
            public ContentSearchLogicalConnector logicalConnector;

            /// <summary>
            /// Writes the structure to a binary buffer.
            /// </summary>
            /// <param name="writer">
            /// The BinaryWriter to write to.
            /// </param>
            public void Write(BinaryWriter writer)
            {
                writer.Write((int)logicalConnector);
                writer.Write(contentColumns.Length);
                for(int i=0; i<contentColumns.Length; i++)
                {
                    contentColumns[i].Write(writer);
                }
            }
        }

        /// <summary>
        /// This structure represents content information returned from a content search.
        /// </summary>
        public struct ContentSearchContentInfo
        {
            /// <summary>
            /// Content ID.
            /// </summary>
            public long contentId;
            /// <summary>
            /// Playback time (seconds).
            /// </summary>
            public int duration;
            /// <summary>
            /// MIME type.
            /// </summary>
            public ContentSearchMimeType mimeType;
            /// <summary>
            /// Content type.
            /// </summary>
            public ContentSearchContentType contentType;
            /// <summary>
            /// Feature used in content generation.
            /// </summary>
            public ContentSearchContentGeneratorType generatorId;
            /// <summary>
            /// Actual file path of the content.
            /// </summary>
            public string contentPath;
            /// <summary>
            /// Content title.
            /// </summary>
            public string title;
            /// <summary>
            /// Content thumbnail path.
            /// </summary>
            public string iconPath;
            /// <summary>
            /// Content thumbnail path.
            /// </summary>
            public ContentSearchFavoriteStatus favoriteStatus;
            /// <summary>
            /// Content upload status.
            /// </summary>
            public ContentSearchUploadStatus uploadStatus;
            /// <summary>
            /// Content creation date/time.
            /// </summary>
            public ulong createdTime;
            /// <summary>
            /// Content size.
            /// </summary>
            public long size;
            /// <summary>
            /// Content status.
            /// </summary>
            public ContentSearchContentStatus status;
            /// <summary>
            /// User IDs of users who own content.
            /// </summary>
            public int[] accounts;

            /// <summary>
            /// Reads the structure from a binary buffer.
            /// </summary>
            /// <param name="reader">
            /// The BinaryReader to read from.
            /// </param>
            public void Read(BinaryReader reader)
            {
                contentId = reader.ReadInt64();
                duration = reader.ReadInt32();
                mimeType = (ContentSearchMimeType)reader.ReadInt32();
                contentType = (ContentSearchContentType)reader.ReadInt32();
                generatorId = (ContentSearchContentGeneratorType)reader.ReadInt32();
                contentPath = reader.ReadPrxString();
                title = reader.ReadPrxString();
                iconPath = reader.ReadPrxString();
                favoriteStatus = (ContentSearchFavoriteStatus)reader.ReadInt32();
                uploadStatus = (ContentSearchUploadStatus)reader.ReadInt32();
                createdTime = reader.ReadUInt64();
                size = reader.ReadInt64();
                status = (ContentSearchContentStatus)reader.ReadInt32();
                int accountCount = reader.ReadInt32();   // Size of the accounts array (always 4).
                accounts = new int[accountCount];
                for(int i=0; i<accountCount; i++)
                {
                    accounts[i] = reader.ReadInt32();
                }
            }
        }

        /// <summary>
        /// Enum constants representing metadata field names which can be used when requesting a metadata field from content.
        /// </summary>
        public enum ContentSearchMetadaDataFieldNameIndex    // Index into the s_MetadataFieldNames array in the native code.
        {
            /// <summary>
            /// title
            /// </summary>
            Title,
            /// <summary>
            /// mime_type
            /// </summary>
            Mime,
            /// <summary>
            /// created_time
            /// </summary>
            Createdtime,
            /// <summary>
            /// last_updated_time
            /// </summary>
            Lastupdatedtime,
            /// <summary>
            /// size
            /// </summary>
            Size,
            /// <summary>
            /// width
            /// </summary>
            Width,
            /// <summary>
            /// height
            /// </summary>
            Height,
            /// <summary>
            /// video_bitrate
            /// </summary>
            VideoBitrate,
            /// <summary>
            /// audio_mime_type
            /// </summary>
            AudioMimeType,
            /// <summary>
            /// audio_mime_type
            /// </summary>
            AudioBitrate,
            /// <summary>
            /// audio_mime_type
            /// </summary>
            AudioChannelType,
            /// <summary>
            /// orientation_type
            /// </summary>
            Orientation,
            /// <summary>
            /// duration
            /// </summary>
            ImportedTime,
            /// <summary>
            /// duration
            /// </summary>
            Duration,
            /// <summary>
            /// media_timescale
            /// </summary>
            MediaTimescale
        }

        #region DLL Import
        [DllImport(LibraryInfo.LibraryName)]
        private static extern long PrxContentSearchGetLastUpdateId(out APIResult result);
        #endregion

        /// <summary>
        /// Search for content in the PS5 content library.
        /// </summary>
        public class ContentSearchForRequest : Request
        {
            /// <summary>
            /// Array of column sets containing columns if search conditions.
            /// </summary>
            public ContentSearchContentColumnSet[] ContentColumnSets { get; set; }
            /// <summary>
            /// Array of columns to specify as sort conditions.
            /// </summary>
            public ContentSearchContentOrderByCondition[]  OrderByConditions { get; set; }
            /// <summary>
            /// Start position of content information to obtain.
            /// </summary>
            public int SearchOffset { get; set; }
            /// <summary>
            /// Maximum number of instances of content information to obtain.
            /// </summary>
            public int SearchLimit { get; set; }

            /// <summary>
            /// Returns the number of content items found.
            /// </summary>
            public long ContentCount { get; protected set; }
            /// <summary>
            /// Returns the array of found content info.
            /// </summary>
            public ContentSearchContentInfo[] contentInfo;

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentSearchFor);
                nativeMethod.Writer.Write(SearchOffset);
                nativeMethod.Writer.Write(SearchLimit);

                nativeMethod.Writer.Write(ContentColumnSets.Length);
                for(int i=0; i<ContentColumnSets.Length; i++)
                {
                    ContentColumnSets[i].Write(nativeMethod.Writer);
                }

                nativeMethod.Writer.Write(OrderByConditions.Length);
                for(int i=0; i<OrderByConditions.Length; i++)
                {
                    OrderByConditions[i].Write(nativeMethod.Writer);
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                ContentCount = nativeMethod.Reader.ReadInt64();
                contentInfo = new ContentSearchContentInfo[ContentCount];
                for(int i=0; i<ContentCount; i++)
                {
                    contentInfo[i].Read(nativeMethod.Reader);
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Obtain the total size of content matching a content search set.
        /// </summary>
        public class ContentSearchGetTotalContentSizeRequest : Request
        {
            /// <summary>
            /// Array of column sets containing columns if search conditions.
            /// </summary>
            public ContentSearchContentColumnSet[] ContentColumnSets { get; set; }

            /// <summary>
            /// Returns the total size of content found.
            /// </summary>
            public long ContentSize { get; protected set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentSearchGetTotalContentSize);

                nativeMethod.Writer.Write(ContentColumnSets.Length);
                for(int i=0; i<ContentColumnSets.Length; i++)
                {
                    ContentColumnSets[i].Write(nativeMethod.Writer);
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                ContentSize = nativeMethod.Reader.ReadInt64();

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Obtain the pieces of content matching a content search set.
        /// </summary>
        public class ContentSearchGetNumOfContentRequest : Request
        {
            /// <summary>
            /// Array of column sets containing columns if search conditions.
            /// </summary>
            public ContentSearchContentColumnSet[] ContentColumnSets { get; set; }

            /// <summary>
            /// Returns the number of content items found.
            /// </summary>
            public long ContentCount { get; protected set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentSearchGetNumOfContent);

                nativeMethod.Writer.Write(ContentColumnSets.Length);
                for(int i=0; i<ContentColumnSets.Length; i++)
                {
                    ContentColumnSets[i].Write(nativeMethod.Writer);
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                ContentCount = nativeMethod.Reader.ReadInt64();

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get the content database update ID.
        /// </summary>
        /// <returns>The last update ID.</returns>
        public static long GetLastUpdateID()
        {
            APIResult result;
            long updateID = PrxContentSearchGetLastUpdateId(out result);
            if (result.RaiseException == true)
                throw new ContentManagementException(result);
            return updateID;
        }

        /// <summary>
        /// Get metadata values for the specified content file path.
        /// </summary>
        public class ContentSearchGetMetadataRequest : Request
        {
            /// <summary>
            /// The file path of the content to get metadata from.
            /// </summary>
            public string FilePath { get; set; }
            /// <summary>
            /// An array of metadata field IDs to get from the content.
            /// </summary>
            public ContentSearch.ContentSearchMetadaDataFieldNameIndex[] MetadataFieldIndices { get; set; }

            /// <summary>
            /// Returns an array of metadata values corresponding to the requested metadata field IDs.
            /// </summary>
            public ContentSearch.ContentSearchValue[] MetadataValues { get; protected set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentSearchGetMetadata);

                nativeMethod.Writer.WritePrxString(FilePath);
                nativeMethod.Writer.Write(MetadataFieldIndices.Length);
                for(int i=0; i<MetadataFieldIndices.Length; i++)
                {
                    nativeMethod.Writer.Write((int)MetadataFieldIndices[i]);
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                int valueCount = nativeMethod.Reader.ReadInt32();
                MetadataValues = new ContentSearch.ContentSearchValue[valueCount];
                for(int i=0; i<valueCount; i++)
                {
                    MetadataValues[i].Read(nativeMethod.Reader);
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get metadata values for the specified content ID.
        /// </summary>
        public class ContentSearchGetMetadataByContentIdRequest : Request
        {
            /// <summary>
            /// The ID of the content to get metadata from.
            /// </summary>
            public long ContentID { get; set; }
            /// <summary>
            /// An array of metadata field IDs to get from the content.
            /// </summary>
            public ContentSearch.ContentSearchMetadaDataFieldNameIndex[] MetadataFieldIndices { get; set; }

            /// <summary>
            /// Returns an array of metadata values corresponding to the requested metadata field IDs.
            /// </summary>
            public ContentSearch.ContentSearchValue[] MetadataValues { get; protected set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentSearchGetMetadataByContentId);

                nativeMethod.Writer.Write(ContentID);
                nativeMethod.Writer.Write(MetadataFieldIndices.Length);
                for(int i=0; i<MetadataFieldIndices.Length; i++)
                {
                    nativeMethod.Writer.Write((int)MetadataFieldIndices[i]);
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                int valueCount = nativeMethod.Reader.ReadInt32();
                MetadataValues = new ContentSearch.ContentSearchValue[valueCount];
                for(int i=0; i<valueCount; i++)
                {
                    MetadataValues[i].Read(nativeMethod.Reader);
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

    }
}
