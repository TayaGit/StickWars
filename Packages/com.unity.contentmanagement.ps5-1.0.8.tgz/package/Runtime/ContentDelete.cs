
using System;
using System.Runtime.InteropServices;

using Unity.ContentManagement.PS5.Aysnc;
using Unity.ContentManagement.PS5.Internal;

namespace Unity.ContentManagement.PS5
{
    /// <summary>
    /// Class containing methods for deleteing content from the PS5 content library.
    /// </summary>
    public class ContentDelete
    {
        /// <summary>
        /// Delete content specified by a file path.
        /// </summary>
        public class ContentDeleteByPathRequest : Request
        {
            /// <summary>
            /// Specifies the full path of the content file to be deleted.
            /// </summary>
            public string FilePath { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentDeleteByPath);

                nativeMethod.Writer.WritePrxString(FilePath);

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Delete content specified by a content ID.
        /// </summary>
        public class ContentDeleteByContentIdRequest : Request
        {
            /// <summary>
            /// Specifies the content ID of the content file to be deleted.
            /// </summary>
            public long ContentID { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)Main.NativeMethods.ContentDeleteByContentId);

                nativeMethod.Writer.Write(ContentID);

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

    }
}
