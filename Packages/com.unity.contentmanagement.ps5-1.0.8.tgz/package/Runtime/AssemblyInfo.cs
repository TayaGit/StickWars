using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.ContentManagement.PS5.Editor")]
[assembly: InternalsVisibleTo("Unity.ContentManagement.PS5.Tests.Editor")]
