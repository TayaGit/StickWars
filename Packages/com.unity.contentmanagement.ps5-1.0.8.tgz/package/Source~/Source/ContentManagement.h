#pragma once

#include "Plugin.h"
#include <content_export.h>
#include <content_search.h>
#include <content_delete.h>

namespace ContentMan
{
    // Must match ContentMananager.NativeMethods in main.cs
    enum Methods
    {
        Initialise = 0x0200001u,
        Terminate = 0x0200002u,
        ExportFromFile = 0x0200003u,
        ExportFromData = 0x0200004u,
        ContentSearchFor = 0x0200005u,
        ContentSearchGetNumOfContent = 0x0200006u,
        ContentSearchGetTotalContentSize = 0x0200007u,
        ContentSearchGetMetadata = 0x0200008u,
        ContentSearchGetMetadataByContentId = 0x0200009u,
        ContentDeleteByPath = 0x020000au,
        ContentDeleteByContentId = 0x020000bu, 
    };

    class ContentManagement
    {
    public:

    private:
        static bool s_Initialised;

    public:
        static void Initialize(InitResult& initResult, APIResult* result);
        static void Shutdown();

        static void LoadModules(InitResult& initResult, APIResult* result);
        static void UnloadModules();

    private:
    };
}
