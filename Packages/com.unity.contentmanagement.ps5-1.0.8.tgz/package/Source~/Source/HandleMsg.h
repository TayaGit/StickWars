#pragma once

#define PRX_INTERFACE __declspec(dllexport)
typedef unsigned int UInt32;
typedef unsigned char UInt8;

typedef int SceUserServiceUserId;
#include <map>
#include <list>
#include <system_service.h>

namespace UnityEventQueue
{
    class IEventQueue;
}

namespace ContentMan { struct PRX_INTERFACE APIResult; }

namespace ContentMan
{
    class PRX_INTERFACE MsgHandler
    {
    public:

        typedef void(*MethodCallbackSimple)(APIResult* result);
        typedef void(*MethodCallbackWithData)(UInt8* sourceData, int sourceSize, APIResult* result);
        typedef void(*MethodCallbackFull)(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result);

        struct MsgHeader
        {
            UInt32 version;
            UInt32 methodId;
        };

        static std::map<int, MethodCallbackSimple> s_MethodSimpleList;
        static std::map<int, MethodCallbackWithData> s_MethodWithDataList;
        static std::map<int, MethodCallbackFull> s_MethodFullList;

        static void ProcessMsg(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result);

        static bool GetSimpleMethod(UInt32 methodId, MethodCallbackSimple* foundMethod);
        static bool GetWithDataMethod(UInt32 methodId, MethodCallbackWithData* foundMethod);
        static bool GetFullMethod(UInt32 methodId, MethodCallbackFull* foundMethod);

        static void AddMethod(int methodId, MethodCallbackSimple methodCallback);
        static void AddMethod(int methodId, MethodCallbackWithData methodCallback);
        static void AddMethod(int methodId, MethodCallbackFull methodCallback);
    };
}
