#pragma once

#include <assert.h>
#include <stdio.h>
#include <scetypes.h>
#include <string.h>

#define Assert assert

#define PRX_INTERFACE __declspec(dllexport)
#define PRX_EXPORT extern "C" __declspec (dllexport)
#define	DO_EXPORT( _type, _func ) PRX_EXPORT _type _func

#define SCE_KERNEL_START_SUCCESS		(0)
#define SCE_KERNEL_START_NO_RESIDENT	(1)
#define SCE_KERNEL_START_FAILED			(2)

#define Assert assert

typedef unsigned char UInt8;
typedef int Int32;

#define ARRAY_SIZE(x) (sizeof(x) / sizeof(x[0]))
#define CompileTimeAssertArraySize(array, size) static_assert(ARRAY_SIZE(array) == (size), "Wrong number of elements in array " #array)
#define CompileTimeAssert static_assert

#define PRX_EXPORT extern "C" __declspec (dllexport)
#define	DO_EXPORT( _type, _func ) PRX_EXPORT _type _func

#if NDEBUG
#define UNITY_TRACE(...)
#define UNITY_TRACEIF(condition, ...)
#define DEBUG_BREAK
#else
#define UNITY_TRACE(...)				{printf("[ContentManagement] "); printf(__VA_ARGS__);}
#define UNITY_TRACEIF(condition, ...)	if (condition) {printf("[ContentManagement] "); printf(__VA_ARGS__);}
#define DEBUG_BREAK { UNITY_TRACE("*** Called __debugbreak ***\n"); __debugbreak(); }
#endif

#define ERROR_RESULT(result, message) (APIResult::SetResult(result,  APIResultTypes::Error, message, __FILE__, __LINE__))
#define SUCCESS_RESULT(result)  (APIResult::SetResult(result, APIResultTypes::Success))
#define SCE_ERROR_RESULT(result, sceErrorCode) (APIResult::SetSceResult(result, APIResultTypes::Error, sceErrorCode, __FILE__, __LINE__))

namespace ContentMan
{
    struct ErrorItem
    {
        int32_t errorCode;
        const char* errorName;
    };

    const ErrorItem& FindSceErrorItem(int32_t errorCode);

    struct InitResult
    {
    public:
        bool initialized;
        uint32_t sceSDKVersion; // SCE_ORBIS_SDK_VERSION 

        InitResult()
        {
            initialized = false;
        }
    };

    enum APIResultTypes
    {
        Success = 0,
        Warning = 1,
        Error = 2,
    };

    struct PRX_INTERFACE APIResult
    {
    public:
        APIResultTypes apiResult;
        char const* message;
        char const* filename;
        Int32 lineNumber;
        Int32 sceErrorCode;

        static void SetResult(APIResult* result, APIResultTypes type);
        static void SetResult(APIResult* result, APIResultTypes type, char const * message, char const * filename, Int32 lineNumber);
        static void SetSceResult(APIResult* result, APIResultTypes type, Int32 sceErrorCode, char const * filename, Int32 lineNumber);
    };
}

