#include <stdio.h>
#include <sdk_version.h>
#include "ContentManagement.h"
#include "ContentExport.h"
#include "ContentSearch.h"
#include "ContentDelete.h"

#include <libsysmodule.h>
#include "HandleMsg.h"
#include "BinaryBuffers.h"

// https://game.develop.playstation.net/resources/documents/SDK/latest/ContentExport-Overview/__toc.html
// https://game.develop.playstation.net/resources/documents/SDK/latest/ContentDelete-Overview/__toc.html
// https://game.develop.playstation.net/resources/documents/SDK/latest/ContentSearch-Overview/__toc.html

#pragma comment(lib, "libSceSysmodule_stub_weak.a")
#pragma comment(lib, "libSceRtc_stub_weak.a")
#pragma comment(lib, "libSceContentExport_stub_weak.a")
#pragma comment(lib, "libSceContentSearch_stub_weak.a")
#pragma comment(lib, "libSceContentDelete_stub_weak.a")

namespace ContentMan
{
    DO_EXPORT(void, ContentMan_PrxInitialize) (InitResult* initResult, APIResult* result)
    {
        ContentManagement::Initialize(*initResult, result);
    }

    DO_EXPORT(void, ContentMan_PrxShutDown) ()
    {
        ContentManagement::Shutdown();
    }

    DO_EXPORT(void, ContentMan_PrxProcessMsg) (UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        MsgHandler::ProcessMsg(sourceData, sourceSize, resultsData, resultsMaxSize, resultsSize, result);
    }

    void InitialiseImpl(APIResult* result)
    {
        ContentExport::Initialize(result);
        if (result->sceErrorCode != SCE_OK)
            return;

        ContentSearch::Initialize(result);
        if (result->sceErrorCode != SCE_OK)
            return;

        ContentDelete::Initialize(result);
        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void TerminateImpl(APIResult* result)
    {
        ContentExport::Terminate(result);
        if (result->sceErrorCode != SCE_OK)
            return;

        ContentSearch::Terminate(result);
        if (result->sceErrorCode != SCE_OK)
            return;

        ContentDelete::Terminate(result);
        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void ExportFromFileImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        int exportID = reader.ReadInt32();

        char title[SCE_CONTENT_EXPORT_LENGTH_TITLE + 1];
        memset(title, 0, sizeof(title));
        reader.ReadString(title, SCE_CONTENT_EXPORT_LENGTH_TITLE);

        int32_t contentExportFormat = reader.ReadInt32();

        char contentPath[SCE_CONTENT_EXPORT_LENGTH_FILEPATH + 1];
        memset(contentPath, 0, sizeof(contentPath));
        reader.ReadString(contentPath, SCE_CONTENT_EXPORT_LENGTH_FILEPATH);

        char thumbnailPath[SCE_CONTENT_EXPORT_LENGTH_FILEPATH + 1];
        memset(thumbnailPath, 0, sizeof(contentPath));
        reader.ReadString(thumbnailPath, SCE_CONTENT_EXPORT_LENGTH_FILEPATH);

        UNITY_TRACE("title: %s\n", title);
        UNITY_TRACE("contentExportFormat: %d\n", contentExportFormat);
        UNITY_TRACE("contentPath: %s\n", contentPath);
        UNITY_TRACE("thumbnailPath: %s\n", thumbnailPath);

        if (thumbnailPath[0])
        {
            ContentExport::ExportFromFileWithThumbnail(exportID, title, contentExportFormat, contentPath, thumbnailPath, result);
        }
        else
            ContentExport::ExportFromFile(exportID, title, contentExportFormat, contentPath, result);

        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void ExportFromDataImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        int32_t exportID = reader.ReadInt32();

        char title[SCE_CONTENT_EXPORT_LENGTH_TITLE + 1];
        memset(title, 0, sizeof(title));
        reader.ReadString(title, SCE_CONTENT_EXPORT_LENGTH_TITLE);

        int32_t contentExportFormat = reader.ReadInt32();
        int32_t contentLength = reader.ReadInt32();
        uint8_t* contentData = (uint8_t*)reader.ReadInt64();
        int32_t thumbnailExportFormat = reader.ReadInt32();
        int32_t thumbnailLength = reader.ReadInt32();
        uint8_t* thumbnailData = (uint8_t*)reader.ReadInt64();

        UNITY_TRACE("title: %s\n", title);
        UNITY_TRACE("contentExportFormat: %d\n", contentExportFormat);
        UNITY_TRACE("contentLength: %d\n", contentLength);
        UNITY_TRACE("contentData: 0x%p\n", contentData);
        UNITY_TRACE("thumbnailExportFormat: %d\n", thumbnailExportFormat);
        UNITY_TRACE("thumbnailLength: %d\n", thumbnailLength);
        UNITY_TRACE("thumbnailData: 0x%p\n", thumbnailData);

        if (thumbnailLength > 0)
        {
            ContentExport::ExportFromDataWithThumbnail(exportID, title, contentExportFormat, contentData, contentLength, thumbnailExportFormat, thumbnailData, thumbnailLength, result);
        }
        else
        {
            ContentExport::ExportFromData(exportID, title, contentExportFormat, contentData, contentLength, result);
        }
    }

    void ContentSearchForImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        int searchOffset = reader.ReadInt32();
        int searchLimit = reader.ReadInt32();

        int columnSetCount = 0;
        SceContentSearchContentColumnSet* columnSets = ContentSearch::ReadContentSearchColumnSets(reader, &columnSetCount);

        SceContentSearchContentOrderByCondition* orderByConditions = nullptr;

        int32_t orderByConditionsCount = reader.ReadInt32();
        if (orderByConditionsCount)
        {
            orderByConditions = new SceContentSearchContentOrderByCondition[orderByConditionsCount];
            for (int i = 0; i < orderByConditionsCount; i++)
            {
                orderByConditions[i].columnType = (SceContentSearchContentSortColumnType)reader.ReadInt32();
                orderByConditions[i].sortType = (SceContentSearchSortType)reader.ReadInt32();
                UNITY_TRACE("%d - orderByConditions.columnType: %d\n", i, orderByConditions[i].columnType);
                UNITY_TRACE("%d - orderByConditions.sortType: %d\n", i, orderByConditions[i].sortType);
            }
        }

        int64_t searchInfoCount = 0;
        SceContentSearchContentInfo* searchInfo = new SceContentSearchContentInfo[searchLimit];

        UNITY_TRACE("searchOffset: %d\n", searchOffset);
        UNITY_TRACE("searchLimit: %d\n", searchLimit);

        ContentSearch::SearchFor(columnSets, columnSetCount, orderByConditions, orderByConditionsCount, searchOffset, searchLimit, searchInfo, &searchInfoCount, result);

        ContentSearch::ReleaseContentSearchColumnSets(columnSets, columnSetCount);

        if (result->sceErrorCode != SCE_OK)
            return;

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt64(searchInfoCount);
        for (int i = 0; i < searchInfoCount; i++)
        {
            ContentSearch::WriteSearchContentInfo(&searchInfo[i], writer);
        }
        *resultsSize = writer.GetWrittenLength();
        delete[] searchInfo;

        SUCCESS_RESULT(result);
    }

    void ContentSearchGetNumOfContentImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        int columnSetCount = 0;
        SceContentSearchContentColumnSet* columnSets = ContentSearch::ReadContentSearchColumnSets(reader, &columnSetCount);

        int64_t count = ContentSearch::GetNumOfContent(columnSets, columnSetCount, result);

        ContentSearch::ReleaseContentSearchColumnSets(columnSets, columnSetCount);

        if (result->sceErrorCode != SCE_OK)
            return;

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt64(count);
        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }

    void ContentSearchGetTotalContentSizeImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        int columnSetCount = 0;
        SceContentSearchContentColumnSet* columnSets = ContentSearch::ReadContentSearchColumnSets(reader, &columnSetCount);

        int64_t size = ContentSearch::GetTotalContentSize(columnSets, columnSetCount, result);

        ContentSearch::ReleaseContentSearchColumnSets(columnSets, columnSetCount);

        if (result->sceErrorCode != SCE_OK)
            return;

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt64(size);
        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }

    void ContentSearchGetMetadataImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        char filePath[SCE_CONTENT_SEARCH_LENGTH_FILEPATH];
        reader.ReadString(filePath, SCE_CONTENT_SEARCH_LENGTH_FILEPATH);

        int fieldIndexCount = reader.ReadInt32();
        ContentSearch::MetadaDataFieldNameIndex* fieldIndices = new ContentSearch::MetadaDataFieldNameIndex[fieldIndexCount];
        reader.ReadData(fieldIndices, sizeof(int)*fieldIndexCount);

        SceContentSearchMetadataValue* metadataValues = new SceContentSearchMetadataValue[fieldIndexCount];
        memset(metadataValues, 0, sizeof(SceContentSearchMetadataValue) * fieldIndexCount);

        ContentSearch::GetMetadata(filePath, fieldIndices, fieldIndexCount, metadataValues, result);

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt32(fieldIndexCount);
        for (int i = 0; i < fieldIndexCount; i++)
        {
            ContentSearch::WriteMetadataValue(writer, metadataValues[i]);
        }
        *resultsSize = writer.GetWrittenLength();

        for (int i = 0; i < fieldIndexCount; i++)
        {
            if (metadataValues[i].type == SCE_CONTENT_SEARCH_METADATA_TEXT)
            {
                free(metadataValues[i].vText);
            }
        }
        delete[] metadataValues;

        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void ContentSearchGetMetadataByContentIdImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        SceContentSearchContentId contentId = (SceContentSearchContentId)reader.ReadInt64();
        int fieldIndexCount = reader.ReadInt32();
        ContentSearch::MetadaDataFieldNameIndex* fieldIndices = new ContentSearch::MetadaDataFieldNameIndex[fieldIndexCount];
        reader.ReadData(fieldIndices, sizeof(int)*fieldIndexCount);

        SceContentSearchMetadataValue* metadataValues = new SceContentSearchMetadataValue[fieldIndexCount];
        memset(metadataValues, 0, sizeof(SceContentSearchMetadataValue) * fieldIndexCount);

        ContentSearch::GetMetadataByContentId(contentId, fieldIndices, fieldIndexCount, metadataValues, result);

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt32(fieldIndexCount);
        for (int i = 0; i < fieldIndexCount; i++)
        {
            ContentSearch::WriteMetadataValue(writer, metadataValues[i]);
        }
        *resultsSize = writer.GetWrittenLength();

        ContentSearch::ReleaseMetadataValueMemory(metadataValues, fieldIndexCount);
        delete[] metadataValues;

        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void ContentDeleteByPathImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        char filePath[SCE_CONTENT_DELETE_LENGTH_FILEPATH];
        reader.ReadString(filePath, SCE_CONTENT_DELETE_LENGTH_FILEPATH);

        ContentDelete::DeleteByPath(filePath, result);

        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void ContentDeleteByContentIdImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);

        SceContentSearchContentId contentId = (SceContentSearchContentId)reader.ReadInt64();

        ContentDelete::DeleteByContentID(contentId, result);

        if (result->sceErrorCode != SCE_OK)
            return;

        SUCCESS_RESULT(result);
    }

    void RegisterMethods()
    {
        MsgHandler::AddMethod(Methods::Initialise, ContentMan::InitialiseImpl);
        MsgHandler::AddMethod(Methods::Terminate, ContentMan::TerminateImpl);
        MsgHandler::AddMethod(Methods::ExportFromFile, ContentMan::ExportFromFileImpl);
        MsgHandler::AddMethod(Methods::ExportFromData, ContentMan::ExportFromDataImpl);
        MsgHandler::AddMethod(Methods::ContentSearchFor, ContentMan::ContentSearchForImpl);
        MsgHandler::AddMethod(Methods::ContentSearchGetNumOfContent, ContentMan::ContentSearchGetNumOfContentImpl);
        MsgHandler::AddMethod(Methods::ContentSearchGetTotalContentSize, ContentMan::ContentSearchGetTotalContentSizeImpl);
        MsgHandler::AddMethod(Methods::ContentSearchGetMetadata, ContentMan::ContentSearchGetMetadataImpl);
        MsgHandler::AddMethod(Methods::ContentSearchGetMetadataByContentId, ContentMan::ContentSearchGetMetadataByContentIdImpl);
        MsgHandler::AddMethod(Methods::ContentDeleteByPath, ContentMan::ContentDeleteByPathImpl);
        MsgHandler::AddMethod(Methods::ContentDeleteByContentId, ContentMan::ContentDeleteByContentIdImpl);
    }

    // Main Class

    // Static Initialisation

    bool ContentManagement::s_Initialised = false;

    void ContentManagement::Initialize(InitResult& initResult, APIResult* result)
    {
        if (s_Initialised)
        {
            ERROR_RESULT(result, "ContentManagement Plugin already initialised"); // Already initialised
            return;
        }

        LoadModules(initResult, result);

        s_Initialised = true;

        initResult.initialized = true;
        initResult.sceSDKVersion = SCE_PROSPERO_SDK_VERSION;

        RegisterMethods();

        SUCCESS_RESULT(result);
    }

    void ContentManagement::Shutdown()
    {
        UnloadModules();

        s_Initialised = false;
    }

    void ContentManagement::LoadModules(InitResult& initResult, APIResult* result)
    {
        ContentExport::LoadModule(initResult, result);
        ContentSearch::LoadModule(initResult, result);
        ContentDelete::LoadModule(initResult, result);
    }

    void ContentManagement::UnloadModules()
    {
        APIResult result;
        ContentExport::UnloadModule(&result);
        ContentSearch::UnloadModule(&result);
        ContentDelete::UnloadModule(&result);
    }

    extern "C" int module_start(size_t sz, const void* arg)
    {
        return SCE_KERNEL_START_SUCCESS;
    }

}
