#include "Plugin.h"

#include <content_export.h>
#include <content_search.h>
#include <content_delete.h>

namespace ContentMan
{
#define SCE_ERROR_ITEM(errCode) { errCode, #errCode }
    ErrorItem sm_Errors[] =
    {
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_CANCELED),                             // 0x809D3001 Canceled
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_NOTACCEPT),                            // 0x809D3002 Requested target processing has not started
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_BUSY),                                 // 0x809D3003 Processing
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_NOINIT),                               // 0x809D3004 Not initialized
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_MULTIPLEINIT),                         // 0x809D3005 Already initialized
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_NOMEM),                                // 0x809D3006 Insufficient memory
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_FILE_NOT_FOUND),                       // 0x809D3011 File does not exist
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_NOT_SUPPORTED_FORMAT),                 // 0x809D3012 Format is not supported
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_INVALDPARAM),                          // 0x809D3016 Parameter is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_DISKFULL),                             // 0x809D3017 Insufficient disk space
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_EXECUTION_MAX),                        // 0x809D3018 Maximum executable value exceeded
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_NOT_SUPPORT_FORMAT_THUMBNAIL),         // 0x809D3019 Thumbnail format error
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_FILES_IN_USE),                         // 0x809D301A Target file to export is open or mapped to memory
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_DATA_PROVIDE_FUNCTION),                // 0x809D301B Error returned in the data providing function
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_BADFILENAME),                          // 0x809D301C Invalid filename
            SCE_ERROR_ITEM(SCE_CONTENT_EXPORT_ERROR_NOT_IMPLEMENTED),                      // 0x809D3FFF Not implemented

            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_NOT_INITIALIZED),                      // 0x809D1001 Not initialized
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_ALREADY_INITIALIZED),                  // 0x809D1002 Already initialized
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_INVALID_PARAM),                        // 0x809D1003 Argument is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_NOMEM),                                // 0x809D1004 Memory is insufficient
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_INVALID_SEARCH_LOGICAL_CONNECTOR),     // 0x809D1005 Logical operator for connecting search conditions is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_INVALID_SEARCH_COLUMN),                // 0x809D1006 Target column for searching is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_INVALID_SEARCH_COLUMN_VALUE_OPERATOR), // 0x809D1007 Comparison operator to set for column conditions is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_INVALID_ORDERBY_CONDITION),            // 0x809D1008 Sort condition is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_LIMIT_TOO_BIG),                        // 0x809D100A Specified value for limit exceeded limit
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_SEARCH_PARAMETER_TOO_MANY),            // 0x809D100B Too many search conditions
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_DB_BUSY),                              // 0x809D100C Database is busy
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_DB_FATAL),                             // 0x809D100D Fatal error occurred in database
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_TOO_MANY_METADATA),                    // 0x809D100E The number of metadata to allocate is exceeding the upper limit
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_NOT_SUPPORT_MIME_TYPE),                // 0x809D100F Unsupported MIME type
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_NOT_EXIST_FIELD),                      // 0x809D1010 Field does not exist
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_INVALID_CONTENTS_FILE_FORMAT),         // 0x809D1011 Content file format error
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_NOT_EXIST_FILE),                       // 0x809D1012 File does not exist
            SCE_ERROR_ITEM(SCE_CONTENT_SEARCH_ERROR_PERMISSION_REQUIRED),                  // 0x809D1013 Setting item to use the ContentSearch library is not selected in the parameter file (param.json),

            SCE_ERROR_ITEM(SCE_CONTENT_DELETE_ERROR_INVALID_PARAM),                        // 0x809D5001 Specified argument is invalid
            SCE_ERROR_ITEM(SCE_CONTENT_DELETE_ERROR_NOT_INITIALIZED),                      // 0x809D5002 Not initialized
            SCE_ERROR_ITEM(SCE_CONTENT_DELETE_ERROR_ALREADY_INITIALIZED),                  // 0x809D5003 Already initialized
            SCE_ERROR_ITEM(SCE_CONTENT_DELETE_ERROR_NOMEM),                                // 0x809D5004 Memory is insufficient
            SCE_ERROR_ITEM(SCE_CONTENT_DELETE_ERROR_FILE_NOT_FOUND),                       // 0x809D5005 File does not exist
            SCE_ERROR_ITEM(SCE_CONTENT_DELETE_ERROR_NO_PERMISSION),                        // 0x809D5006 No permissions to delete content
    };

    const ErrorItem& FindSceErrorItem(int32_t errorCode)
    {
        const size_t items = sizeof(sm_Errors) / sizeof(ErrorItem);
        for (int i = 0; i < items; ++i)
        {
            if (sm_Errors[i].errorCode == errorCode)
            {
                return sm_Errors[i];
            }
        }

        static ErrorItem unknownError = {-1, "Unknown Error"};
        return unknownError;
    }

    void APIResult::SetResult(APIResult* result, APIResultTypes type)
    {
        SetResult(result, type, "", "", 0);
    }

    void APIResult::SetResult(APIResult* result, APIResultTypes type, char const* message, char const* filename, int lineNumber)
    {
        result->apiResult = type;
        result->message = message ? message : "";
        result->filename = filename ? filename : "";
        result->lineNumber = lineNumber;
        result->sceErrorCode = 0;
    }

    void APIResult::SetSceResult(APIResult* result, APIResultTypes type, int sceErrorCode, char const* filename, int lineNumber)
    {
        char const* message = FindSceErrorItem(sceErrorCode).errorName;
        printf("[ContentManagement] Called %s : 0x%08x\n", __PRETTY_FUNCTION__, sceErrorCode);

        SetResult(result, type, message, filename, lineNumber);

        result->sceErrorCode = sceErrorCode;
    }
}   // of namespace ContentMan
