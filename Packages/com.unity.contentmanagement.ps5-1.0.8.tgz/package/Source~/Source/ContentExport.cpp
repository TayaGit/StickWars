#include "ContentExport.h"

#include <sdk_version.h>
#include <libsysmodule.h>

namespace ContentMan
{
    // https://game.develop.playstation.net/resources/documents/SDK/latest/ContentExport-Overview/__toc.html

    bool ContentExport::s_Initialized = false;

    const char* ContentExport::sm_ExportTypeStrings[] =
    {
        "image/jpeg", //#define SCE_CONTENT_EXPORT_FORMAT_IMAGE_JPEG
        "image/png", //#define SCE_CONTENT_EXPORT_FORMAT_IMAGE_PNG
        "image/gif", //#define SCE_CONTENT_EXPORT_FORMAT_IMAGE_GIF
        "video/mp4", //#define SCE_CONTENT_EXPORT_FORMAT_VIDEO_MP4
        "video/webm", //#define SCE_CONTENT_EXPORT_FORMAT_VIDEO_WEBM
    };

    struct ContentDataProvider
    {
        const uint8_t* ptr;
        size_t size;

        ContentDataProvider(const uint8_t* srcData, size_t srcDataSize)
        {
            ptr = srcData;
            size = srcDataSize;
        }

        static int32_t cbProvide(void** buf, size_t* size, void *userdata)
        {
            const ContentDataProvider *args = (const ContentDataProvider*)userdata;
            *buf = (void*)args->ptr;
            *size = args->size;
            return SCE_CONTENT_EXPORT_DATA_PROVIDE_DONE;
        }
    };

    PRX_EXPORT int PrxContentExportStart(APIResult* result)
    {
        return ContentExport::Start(result);
    }

    PRX_EXPORT void PrxContentExportFinish(int exportID, APIResult* result)
    {
        ContentExport::Finish(exportID, result);
    }

    PRX_EXPORT int PrxContentExportGetProgress(int exportID, APIResult* result)
    {
        return ContentExport::GetProgress(exportID, result);
    }

    PRX_EXPORT void PrxContentExportCancel(int exportID, APIResult* result)
    {
        ContentExport::Cancel(exportID, result);
    }

    void *exp_allocate(size_t size, void* user_data)
    {
        void *p = malloc(size);
        return p;
    }

    void exp_deallocate(void* ptr, void* user_data)
    {
        free(ptr);
    }

    void ContentExport::LoadModule(InitResult& initResult, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        int32_t ret = sceSysmoduleLoadModule(SCE_SYSMODULE_CONTENT_EXPORT);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        initResult.initialized = true;
        initResult.sceSDKVersion = SCE_PROSPERO_SDK_VERSION;

        SUCCESS_RESULT(result);
    }

    void ContentExport::UnloadModule(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        int32_t ret = sceSysmoduleUnloadModule(SCE_SYSMODULE_CONTENT_EXPORT);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        SUCCESS_RESULT(result);
    }

    void ContentExport::Initialize(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        if (s_Initialized)
        {
            ERROR_RESULT(result, "Content Export Plugin already initialized");
            return;
        }

        SceContentExportInitParam2 exportInitParam;
        memset(&exportInitParam, 0, sizeof(exportInitParam));
        exportInitParam.mallocfunc = exp_allocate;
        exportInitParam.freefunc = exp_deallocate;
        exportInitParam.userdata = NULL;
        exportInitParam.bufsize = 0;
        int32_t ret = sceContentExportInit2(&exportInitParam);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialized = true;
        SUCCESS_RESULT(result);
    }

    bool ContentExport::CheckInitialized(APIResult* result)
    {
        if (!s_Initialized)
        {
            ERROR_RESULT(result, "Content Export Plugin not initialized");
            return false;
        }

        return true;
    }

    void ContentExport::Terminate(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        if (!CheckInitialized(result))
            return;

        int32_t ret = sceContentExportTerm();
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialized = false;
        SUCCESS_RESULT(result);
    }

    int ContentExport::Start(APIResult* result)
    {
        if (!CheckInitialized(result))
            return -1;

        int32_t exportID = sceContentExportStart();
        if (exportID < 0)
        {
            SCE_ERROR_RESULT(result, exportID);
            return -1;
        }

        SUCCESS_RESULT(result);
        return exportID;
    }

    void ContentExport::Finish(int exportID, APIResult* result)
    {
        if (!CheckInitialized(result))
            return;

        int32_t ret = sceContentExportFinish(exportID);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        SUCCESS_RESULT(result);
    }

    int ContentExport::GetProgress(int exportID, APIResult* result)
    {
        int32_t progress = sceContentExportGetProgress(exportID);
        if (progress < 0)
        {
            switch (progress)
            {
                case SCE_CONTENT_EXPORT_ERROR_NOTACCEPT:
                case SCE_CONTENT_EXPORT_ERROR_BUSY:
                    progress = 0;
                    break;

                default:
                    SCE_ERROR_RESULT(result, progress);
                    return 0;
            }
        }
        SUCCESS_RESULT(result);
        return progress;
    }

    void ContentExport::Cancel(int exportID, APIResult* result)
    {
        int32_t ret = sceContentExportCancel(exportID);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        SUCCESS_RESULT(result);
    }

    void ContentExport::ExportFromFile(int exportID, const char* title, int contentExportFormat, const char* srcPathName, APIResult* result)
    {
        char contentpath[SCE_CONTENT_EXPORT_LENGTH_FILEPATH + 1];

        int32_t ret;
        SceContentExportParam param;
        memset(&param, 0, sizeof(SceContentExportParam));
        strncpy(param.title, title, SCE_CONTENT_EXPORT_LENGTH_TITLE);

        const char* contentTypeString = sm_ExportTypeStrings[contentExportFormat];
        strncpy(param.contenttype, contentTypeString, SCE_CONTENT_EXPORT_LENGTH_CONTENTTYPE);

        ret = sceContentExportFromFile(exportID, &param, srcPathName, contentpath, SCE_CONTENT_EXPORT_LENGTH_FILEPATH);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        UNITY_TRACE("Exported to path: %s\n", contentpath);

        SUCCESS_RESULT(result);
    }

    void ContentExport::ExportFromFileWithThumbnail(int exportID, const char* title, int contentExportFormat, const char* srcPathName, const char* thumbPathName, APIResult* result)
    {
        char contentpath[SCE_CONTENT_EXPORT_LENGTH_FILEPATH + 1];

        int32_t ret;
        SceContentExportParam param;
        memset(&param, 0, sizeof(SceContentExportParam));
        strncpy(param.title, title, SCE_CONTENT_EXPORT_LENGTH_TITLE);

        const char* contentTypeString = sm_ExportTypeStrings[contentExportFormat];
        strncpy(param.contenttype, contentTypeString, SCE_CONTENT_EXPORT_LENGTH_CONTENTTYPE);

        ret = sceContentExportFromFileWithThumbnail(exportID, &param, srcPathName, thumbPathName, contentpath, SCE_CONTENT_EXPORT_LENGTH_FILEPATH);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        UNITY_TRACE("Exported to path: %s\n", contentpath);
        SUCCESS_RESULT(result);
    }

    void ContentExport::ExportFromData(int exportID, const char* title, int contentExportFormat, const uint8_t* contentData, size_t contentDataLength, APIResult* result)
    {
        if (contentExportFormat < 0 || contentExportFormat > 4)
        {
            SCE_ERROR_RESULT(result, SCE_CONTENT_EXPORT_ERROR_NOT_SUPPORTED_FORMAT);
            return;
        }

        char contentpath[SCE_CONTENT_EXPORT_LENGTH_FILEPATH + 1];

        SceContentExportParam param;
        memset(&param, 0, sizeof(SceContentExportParam));
        strncpy(param.title, title, SCE_CONTENT_EXPORT_LENGTH_TITLE);
        const char* contentTypeString = sm_ExportTypeStrings[contentExportFormat];
        strncpy(param.contenttype, contentTypeString, SCE_CONTENT_EXPORT_LENGTH_CONTENTTYPE);

        ContentDataProvider prv(contentData, contentDataLength);

        int32_t ret = sceContentExportFromData(exportID, &param, contentDataLength, ContentDataProvider::cbProvide, &prv, contentpath, SCE_CONTENT_EXPORT_LENGTH_FILEPATH);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        UNITY_TRACE("Exported to path: %s\n", contentpath);

        SUCCESS_RESULT(result);
    }

    void ContentExport::ExportFromDataWithThumbnail(int exportID, const char* title, int contentExportFormat, const uint8_t* contentData, size_t contentDataLength, int thumbnailExportFormat, const uint8_t* thumbnailData, size_t thumbnailDataLength, APIResult* result)
    {
        if (contentExportFormat < 0 || contentExportFormat > 4)
        {
            SCE_ERROR_RESULT(result, SCE_CONTENT_EXPORT_ERROR_NOT_SUPPORTED_FORMAT);
            return;
        }

        if (thumbnailExportFormat < 0 || thumbnailExportFormat > 4)
        {
            SCE_ERROR_RESULT(result, SCE_CONTENT_EXPORT_ERROR_NOT_SUPPORTED_FORMAT);
            return;
        }

        char contentpath[SCE_CONTENT_EXPORT_LENGTH_FILEPATH + 1];

        SceContentExportParam param;
        memset(&param, 0, sizeof(SceContentExportParam));
        strncpy(param.title, title, SCE_CONTENT_EXPORT_LENGTH_TITLE);
        const char* contentTypeString = sm_ExportTypeStrings[contentExportFormat];
        strncpy(param.contenttype, contentTypeString, SCE_CONTENT_EXPORT_LENGTH_CONTENTTYPE);

        ContentDataProvider contentDataProvider(contentData, contentDataLength);
        ContentDataProvider thumbnailDataProvider(thumbnailData, thumbnailDataLength);

        SceContentExportCallbackParam contentCbParam;
        contentCbParam.contentlength = contentDataLength;
        contentCbParam.func = ContentDataProvider::cbProvide;
        contentCbParam.userdata = &contentDataProvider;

        SceContentExportCallbackParam thumbnailCbParam;
        thumbnailCbParam.contentlength = thumbnailDataLength;
        thumbnailCbParam.func = ContentDataProvider::cbProvide;
        thumbnailCbParam.userdata = &thumbnailDataProvider;

        const char* thumbnailTypeString = sm_ExportTypeStrings[thumbnailExportFormat];

        int32_t ret = sceContentExportFromDataWithThumbnail(
            exportID,
            &param,
            &contentCbParam,
            thumbnailTypeString,
            &thumbnailCbParam,
            contentpath,
            SCE_CONTENT_EXPORT_LENGTH_FILEPATH);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        UNITY_TRACE("Exported to path: %s\n", contentpath);

        SUCCESS_RESULT(result);
    }

}
