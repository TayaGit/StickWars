#include "ContentSearch.h"
#include "BinaryBuffers.h"

#include <sdk_version.h>
#include <libsysmodule.h>

namespace ContentMan
{
    // https://game.develop.playstation.net/resources/documents/SDK/latest/ContentSearch-Overview/__toc.html

    #define SEARCH_VIDEO_CONTENTS_LIMIT (10)

    bool ContentSearch::s_Initialized = false;

    PRX_EXPORT int64_t PrxContentSearchGetLastUpdateId(APIResult* result)
    {
        return ContentSearch::GetLastUpdateId(result);
    }

    void ContentSearch::LoadModule(InitResult& initResult, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        int32_t ret = sceSysmoduleLoadModule(SCE_SYSMODULE_CONTENT_SEARCH);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        initResult.initialized = true;
        initResult.sceSDKVersion = SCE_PROSPERO_SDK_VERSION;

        SUCCESS_RESULT(result);
    }

    void ContentSearch::UnloadModule(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        int32_t ret = sceSysmoduleUnloadModule(SCE_SYSMODULE_CONTENT_SEARCH);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        SUCCESS_RESULT(result);
    }

    void ContentSearch::Initialize(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        if (s_Initialized)
        {
            ERROR_RESULT(result, "Content Search Plugin already initialized");
            return;
        }

        SceContentSearchInitParam initSearchParam;
        initSearchParam.memorySize = 3 * 1024 * 1024;
        int32_t ret = sceContentSearchInit(&initSearchParam);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialized = true;
        SUCCESS_RESULT(result);
    }

    void ContentSearch::Terminate(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        if (!s_Initialized)
        {
            ERROR_RESULT(result, "Content Search Plugin not initialized");
            return;
        }

        int32_t ret = sceContentSearchTerm();
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialized = false;
        SUCCESS_RESULT(result);
    }

    int64_t ContentSearch::GetLastUpdateId(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        SceContentSearchUpdateId updateID = 0;
        int32_t ret = sceContentSearchGetContentLastUpdateId(&updateID);
        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return -1;
        }

        SUCCESS_RESULT(result);
        return updateID;
    }

    void ContentSearch::WriteSearchContentInfo(SceContentSearchContentInfo* info, BinaryWriter& writer)
    {
        writer.WriteInt64(info->contentId);
        writer.WriteInt32(info->duration);
        writer.WriteInt32(info->mimeType);
        writer.WriteInt32(info->contentType);
        writer.WriteInt32(info->generatorId);
        writer.WriteString(info->contentPath);
        writer.WriteString(info->title);
        writer.WriteString(info->iconPath);
        writer.WriteInt32(info->favoriteStatus);
        writer.WriteInt32(info->uploadStatus);
        writer.WriteUInt64(info->createdTime.tick);
        writer.WriteInt64(info->size);
        writer.WriteInt32(info->status);
        writer.WriteInt32(4);   // Size of the accounts array (always 4).
        writer.WriteInt32(info->accounts[0]);
        writer.WriteInt32(info->accounts[1]);
        writer.WriteInt32(info->accounts[2]);
        writer.WriteInt32(info->accounts[3]);
    }

    void ContentSearch::WriteMetadataValue(BinaryWriter& writer, const SceContentSearchMetadataValue& value)
    {
        if (value.size > 0)
        {
            writer.WriteBool(true);  // Value is set.
            switch (value.type)
            {
                case SCE_CONTENT_SEARCH_METADATA_INT:
                    writer.WriteInt32(ContentSearch::intVal);
                    writer.WriteInt64(value.vInt);
                    break;

                case SCE_CONTENT_SEARCH_METADATA_FLOAT:
                    writer.WriteInt32(ContentSearch::floatVal);
                    writer.WriteFloat(value.vFloat);
                    break;

                case SCE_CONTENT_SEARCH_METADATA_TEXT:
                    writer.WriteInt32(ContentSearch::stringVal);
                    writer.WriteString(value.vText);
                    break;

                case SCE_CONTENT_SEARCH_METADATA_TICK:
                    writer.WriteInt32(ContentSearch::tickVal);
                    writer.WriteUInt64(value.vTick.tick);
                    break;
            }
        }
        else
        {
            writer.WriteBool(false);    // Value is not set.
            writer.WriteInt32(ContentSearch::intVal);
            writer.WriteInt64(0);
        }
    }

    void ContentSearch::ReleaseContentColumnValueMemory(SceContentSearchContentColumnType columnType, SceContentSearchColumnValue* value)
    {
        switch (columnType)
        {
            case SCE_CONTENT_SEARCH_CONTENT_COLUMN_TYPE_CONTENT_PATH:
                UNITY_TRACE("Called \"%s\" for text value\n", __PRETTY_FUNCTION__);
                free((void*)(value->vText));
                break;

            default:
                // Value type did'nt allocate any memory so do nothing.
                break;
        }
    }

    void ContentSearch::ReleaseMetadataValueMemory(SceContentSearchMetadataValue* values, int valueCount)
    {
        for (int i = 0; i < valueCount; i++)
        {
            if (values[i].type == SCE_CONTENT_SEARCH_METADATA_TEXT)
            {
                free(values[i].vText);
            }
        }
    }

    SceContentSearchContentColumnSet* ContentSearch::ReadContentSearchColumnSets(BinaryReader& reader, int* columnSetCount)
    {
        SceContentSearchContentColumnSet* columnSets = nullptr;
        int count = reader.ReadInt32();
        if (count)
        {
            columnSets = new SceContentSearchContentColumnSet[count];
            for (int i = 0; i < count; i++)
            {
                columnSets[0].logicalConnector = (SceContentSearchLogicalConnector)reader.ReadInt32();

                SceContentSearchContentColumn* columns = nullptr;
                SceContentSearchColumnValue* values = nullptr;
                int columnCount = reader.ReadInt32();
                columnSets[i].columnsLength = columnCount;
                if (columnCount)
                {
                    columns = new SceContentSearchContentColumn[columnCount];
                    values = new SceContentSearchColumnValue[columnCount];

                    ReadContentSearchColumns(reader, columns, columnCount, values);
                }
                columnSets[i].columns = columns;
            }
        }

        *columnSetCount = count;
        return columnSets;
    }

    void ContentSearch::ReleaseContentSearchColumnSets(SceContentSearchContentColumnSet* columnSets, int columnSetCount)
    {
        for (int i = 0; i < columnSetCount; i++)
        {
            for (int j = 0; j < columnSets[i].columnsLength; j++)
            {
                ReleaseContentColumnValueMemory(columnSets[i].columns[j].columnType, columnSets[i].columns[j].value);
            }

            SceContentSearchContentColumn* columns = columnSets[i].columns;
            SceContentSearchColumnValue* values = columnSets[i].columns[0].value;
            delete[] values;
            delete[] columns;
        }
        delete[] columnSets;
    }

    void ContentSearch::ReadContentSearchColumns(BinaryReader& reader, SceContentSearchContentColumn* columns, int columnCount, SceContentSearchColumnValue* values)
    {
        for (int i = 0; i < columnCount; i++)
        {
            columns[i].columnType = (SceContentSearchContentColumnType)reader.ReadInt32();
            columns[i].columnOperator = (SceContentSearchColumnValueOperator)reader.ReadInt32();
            columns[i].logicalConnector = (SceContentSearchLogicalConnector)reader.ReadInt32();
            columns[i].value = &values[i];

            UNITY_TRACE("%d - columnType: %d\n", i, columns[i].columnType);
            UNITY_TRACE("%d - columnOperator: %d\n", i, columns[i].columnOperator);
            UNITY_TRACE("%d - logicalConnector: %d\n", i, columns[i].logicalConnector);

            reader.ReadBool();    // Read "isValueSet", which we don't use in this function.
            ValueType valueType = (ValueType)reader.ReadInt32();
            switch (valueType)
            {
                case intVal:
                    columns[i].value->size = sizeof(int32_t);
                    columns[i].value->vInt = reader.ReadInt64();
                    UNITY_TRACE("%d - value.vInt: %ld\n", i, columns[i].value->vInt);
                    break;

                case floatVal:
                    columns[i].value->size = sizeof(float);
                    columns[i].value->vFloat = reader.ReadFloat();
                    UNITY_TRACE("%d - value.vFloat: %f\n", i, columns[i].value->vFloat);
                    break;

                case stringVal:
                    columns[i].value->vText = reader.ReadStringMalloc(SCE_CONTENT_SEARCH_MAX_VALUE_TEXT_SIZE);
                    columns[i].value->size = strlen(columns[i].value->vText);
                    UNITY_TRACE("%d - value.vText: \"%s\"\n", i, columns[i].value->vText);
                    break;

                case tickVal:
                    columns[i].value->size = sizeof(uint64_t);
                    columns[i].value->vTick.tick = reader.ReadUInt64();
                    UNITY_TRACE("%d - value.vTick: %ld\n", i, columns[i].value->vTick.tick);
                    break;
            }
        }
    }

    uint32_t ContentSearch::SearchFor(SceContentSearchContentColumnSet* columnSets, int columnSetCount, SceContentSearchContentOrderByCondition* orderByConditions, int orderByConditionsCount, uint32_t searchOffset, uint32_t searchLimit, SceContentSearchContentInfo* searchInfo, int64_t* searchInfoCount, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        SceContentSearchUpdateId lastUpdateId = 0;
        memset(searchInfo, 0, sizeof(SceContentSearchContentInfo) * searchLimit);
        int32_t ret = sceContentSearchSearchContent(columnSets, columnSetCount, orderByConditions, orderByConditionsCount, searchOffset, searchLimit, searchInfoCount, searchInfo, &lastUpdateId);

        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return searchOffset;
        }

        SUCCESS_RESULT(result);
        return searchOffset;
    }

    int64_t ContentSearch::GetNumOfContent(SceContentSearchContentColumnSet* columnSets, int columnSetCount, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        int64_t numOfContent = 0;
        SceContentSearchUpdateId lastUpdateId = 0;

        int32_t ret = sceContentSearchGetNumOfContent(columnSets, columnSetCount, &numOfContent, &lastUpdateId);

        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return 0;
        }

        UNITY_TRACE("numOfContent: %ld\n", numOfContent);
        UNITY_TRACE("lastUpdateId: %ld\n", lastUpdateId);

        return numOfContent;
    }

    int64_t ContentSearch::GetTotalContentSize(SceContentSearchContentColumnSet* columnSets, int columnSetCount, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        int64_t size;
        SceContentSearchUpdateId lastUpdateId = 0;

        int32_t ret = sceContentSearchGetTotalContentSize(columnSets, columnSetCount, &size, &lastUpdateId);

        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return 0;
        }

        UNITY_TRACE("size: %ld\n", size);
        UNITY_TRACE("lastUpdateId: %ld\n", lastUpdateId);

        return size;
    }

    const char* s_MetadataFieldNames[] =
    {
        "title",                 // SCE_CONTENT_SEARCH_METADATA_FIELD_TITLE
        "mime_type",             // SCE_CONTENT_SEARCH_METADATA_FIELD_MIME
        "created_time",          // SCE_CONTENT_SEARCH_METADATA_FIELD_CREATED_TIME
        "last_updated_time",     // SCE_CONTENT_SEARCH_METADATA_FIELD_LASTUPDATED_TIME
        "size",                  // SCE_CONTENT_SEARCH_METADATA_FIELD_SIZE
        "width",                 // SCE_CONTENT_SEARCH_METADATA_FIELD_WIDTH
        "height",                // SCE_CONTENT_SEARCH_METADATA_FIELD_HEIGHT
        "video_bitrate",         // SCE_CONTENT_SEARCH_METADATA_FIELD_VIDEO_BITRATE
        "audio_mime_type",       // SCE_CONTENT_SEARCH_METADATA_FIELD_AUDIO_MIME_TYPE
        "audio_bitrate",         // SCE_CONTENT_SEARCH_METADATA_FIELD_AUDIO_BITRATE
        "audio_channel_type",    // SCE_CONTENT_SEARCH_METADATA_FIELD_AUDIO_CHANNEL_TYPE
        "orientation_type",      // SCE_CONTENT_SEARCH_METADATA_FIELD_ORIENTATION
        "imported_time",         // SCE_CONTENT_SEARCH_METADATA_FIELD_IMPORTED_TIME
        "duration",              // SCE_CONTENT_SEARCH_METADATA_FIELD_DURATION
        "media_timescale",       // SCE_CONTENT_SEARCH_METADATA_FIELD_MEDIA_TIMESCALE
    };

    void ContentSearch::GetMetadata(SceContentSearchMetadataId metadataId, MetadaDataFieldNameIndex* fieldIndices, int fieldIndexCount, SceContentSearchMetadataValue* metadataValues, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        for (int i = 0; i < fieldIndexCount; i++)
        {
            SceContentSearchMetadataType metadataType;
            int32_t size;

            const char* fieldName = s_MetadataFieldNames[fieldIndices[i]];
            UNITY_TRACE("Getting metadata field info \"%s\"\n", fieldName);

            int32_t ret = sceContentSearchGetMetadataFieldInfo(metadataId, fieldName, &metadataType, &size);
            if (ret == SCE_CONTENT_SEARCH_ERROR_NOT_EXIST_FIELD)
            {
                UNITY_TRACE("Metadata field \"%s\" not found in content\n", fieldName);
                continue;
            }
            else if (ret < SCE_OK)
            {
                SCE_ERROR_RESULT(result, ret);
                return;
            }

            SceContentSearchMetadataValue value;
            if (metadataType == SCE_CONTENT_SEARCH_METADATA_TEXT)
            {
                value.vText = (char*)malloc(size);
                value.size = size;
            }
            ret = sceContentSearchGetMetadataValue(metadataId, fieldName, &value);
            metadataValues[i] = value;

            UNITY_TRACE("metadataType: %d, size: %d\n", metadataType, size);
        }
    }

    void ContentSearch::GetMetadata(const char* filePath, MetadaDataFieldNameIndex* fieldIndices, int fieldIndexCount, SceContentSearchMetadataValue* metadataValues, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        SceContentSearchMetadataId metadataId;

        UNITY_TRACE("filePath: %s\n", filePath);
        UNITY_TRACE("fieldIndexCount: %d\n", fieldIndexCount);
        for (int i = 0; i < fieldIndexCount; i++)
        {
            UNITY_TRACE("fieldIndices[%d]: %d\n", i, fieldIndices[i]);
        }

        int32_t ret = sceContentSearchOpenMetadata(filePath, &metadataId);
        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        UNITY_TRACE("metadataId: %d\n", metadataId);

        GetMetadata(metadataId, fieldIndices, fieldIndexCount, metadataValues, result);

        ret = sceContentSearchCloseMetadata(metadataId);
        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
    }

    void ContentSearch::GetMetadataByContentId(SceContentSearchContentId contentId, MetadaDataFieldNameIndex* fieldIndices, int fieldIndexCount, SceContentSearchMetadataValue* metadataValues, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        UNITY_TRACE("contentId: %ld\n", contentId);
        UNITY_TRACE("fieldIndexCount: %d\n", fieldIndexCount);
        for (int i = 0; i < fieldIndexCount; i++)
        {
            UNITY_TRACE("fieldIndices[%d]: %d\n", i, fieldIndices[i]);
        }

        SceContentSearchMetadataId metadataId;

        int32_t ret = sceContentSearchOpenMetadataByContentId(contentId, &metadataId);
        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        UNITY_TRACE("metadataId: %d\n", metadataId);

        GetMetadata(metadataId, fieldIndices, fieldIndexCount, metadataValues, result);

        ret = sceContentSearchCloseMetadata(metadataId);
        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
    }
}
