#pragma once

#include "Plugin.h"
#include <content_delete.h>

namespace ContentMan
{
    class ContentDelete
    {
    public:

    private:
        static bool s_Initialized;

    public:
        static bool IsInitialiszd() { return s_Initialized;  }
        static void LoadModule(InitResult& initResult, APIResult* result);
        static void UnloadModule(APIResult* result);
        static void Initialize(APIResult* result);
        static void Terminate(APIResult* result);

        static void DeleteByPath(const char *contentPath, APIResult* result);
        static void DeleteByContentID(SceContentDeleteContentId contentId, APIResult* result);
    private:
    };
}
