#pragma once

#include "Plugin.h"
#include "BinaryBuffers.h"
#include <content_search.h>

namespace ContentMan
{
    class ContentSearch
    {
    public:
        enum ValueType
        {
            intVal,
            floatVal,
            stringVal,
            tickVal,
        };

        enum MetadaDataFieldNameIndex    // Index into the s_MetadataFieldNames array.
        {
            MetadataFieldTitle,
            MetadataFieldMime,
            MetadataFieldCreatedtime,
            MetadataFieldLastupdatedtime,
            MetadataFieldSize,
            MetadataFieldWidth,
            MetadataFieldHeight,
            MetadataFieldVideoBitrate,
            MetadataFieldAudioMimeType,
            MetadataFieldAudioBitrate,
            MetadataFieldAudioChannelType,
            MetadataFieldOrientation,
            MetadataFieldImportedTime,
            MetadataFieldDuration,
            MetadataFieldMediaTimescale
        };

    private:
        static bool s_Initialized;

    public:
        static bool IsInitialiszd() { return s_Initialized;  }
        static void LoadModule(InitResult& initResult, APIResult* result);
        static void UnloadModule(APIResult* result);
        static void Initialize(APIResult* result);
        static void Terminate(APIResult* result);

        static int64_t GetLastUpdateId(APIResult* result);
        static int64_t GetNumOfContent(SceContentSearchContentColumnSet* columnSets, int columnSetCount, APIResult* result);
        static int64_t GetTotalContentSize(SceContentSearchContentColumnSet* columnSets, int columnSetCount, APIResult* result);
        static uint32_t SearchFor(SceContentSearchContentColumnSet* columnSets, int columnSetCount, SceContentSearchContentOrderByCondition* orderByConditions, int orderByConditionsCount, uint32_t searchOffset, uint32_t searchLimit, SceContentSearchContentInfo* searchInfo, int64_t* searchInfoCount, APIResult* result);

        static void WriteSearchContentInfo(SceContentSearchContentInfo* info, BinaryWriter& writer);
        static void WriteMetadataValue(BinaryWriter& writer, const SceContentSearchMetadataValue& value);

        static SceContentSearchContentColumnSet* ReadContentSearchColumnSets(BinaryReader& reader, int* columnSetCount);

        static void ReleaseContentSearchColumnSets(SceContentSearchContentColumnSet* columnSets, int columnSetCount);
        static void ReleaseMetadataValueMemory(SceContentSearchMetadataValue* values, int valueCount);

        static void GetMetadata(const char* filePath, MetadaDataFieldNameIndex* fieldIndices, int fieldIndexCount, SceContentSearchMetadataValue* metadataValues, APIResult* result);
        static void GetMetadataByContentId(SceContentSearchContentId contentId, MetadaDataFieldNameIndex* fieldIndices, int fieldIndexCount, SceContentSearchMetadataValue* metadataValues, APIResult* result);

    private:
        static void ReadContentSearchColumns(BinaryReader& reader, SceContentSearchContentColumn* columns, int columnCount, SceContentSearchColumnValue* values);

        static void ReleaseContentColumnValueMemory(SceContentSearchContentColumnType columnType, SceContentSearchColumnValue* value);

        static void GetMetadata(SceContentSearchMetadataId metadataId, MetadaDataFieldNameIndex* fieldIndices, int fieldIndexCount, SceContentSearchMetadataValue* metadataValues, APIResult* result);
    };
}
