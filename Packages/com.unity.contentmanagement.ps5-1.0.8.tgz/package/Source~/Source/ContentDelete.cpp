#include "ContentDelete.h"

#include <sdk_version.h>
#include <libsysmodule.h>

namespace ContentMan
{
    // https://game.develop.playstation.net/resources/documents/SDK/latest/ContentDelete-Overview/__toc.html

    bool ContentDelete::s_Initialized = false;

    void ContentDelete::LoadModule(InitResult& initResult, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        int32_t ret = sceSysmoduleLoadModule(SCE_SYSMODULE_CONTENT_DELETE);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        initResult.initialized = true;
        initResult.sceSDKVersion = SCE_PROSPERO_SDK_VERSION;

        SUCCESS_RESULT(result);
    }

    void ContentDelete::UnloadModule(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        int32_t ret = sceSysmoduleUnloadModule(SCE_SYSMODULE_CONTENT_DELETE);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        SUCCESS_RESULT(result);
    }

    void ContentDelete::Initialize(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        if (s_Initialized)
        {
            ERROR_RESULT(result, "Content Delete library already initialized");
            return;
        }

        SceContentDeleteInitParam initParam;
        initParam.heapSize = SCE_CONTENT_DELETE_HEAP_SIZE;
        int32_t ret = sceContentDeleteInitialize(&initParam);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialized = true;
        SUCCESS_RESULT(result);
    }

    void ContentDelete::Terminate(APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);
        if (!s_Initialized)
        {
            ERROR_RESULT(result, "Content Delete Plugin not initialized");
            return;
        }

        int32_t ret = sceContentDeleteTerminate();
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialized = false;
        SUCCESS_RESULT(result);
    }

    void ContentDelete::DeleteByPath(const char *contentPath, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        int32_t ret = sceContentDeleteByPath(contentPath);

        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void ContentDelete::DeleteByContentID(SceContentDeleteContentId contentId, APIResult* result)
    {
        UNITY_TRACE("Called %s\n", __PRETTY_FUNCTION__);

        int32_t ret = sceContentDeleteById(contentId);

        if (ret < SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }
}
