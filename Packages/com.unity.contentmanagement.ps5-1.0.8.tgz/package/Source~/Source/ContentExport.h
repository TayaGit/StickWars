#pragma once

#include "Plugin.h"
#include <content_export.h>

namespace ContentMan
{
    class ContentExport
    {
    public:

    private:
        static bool s_Initialized;
        static const char* sm_ExportTypeStrings[];

    public:
        static bool IsInitialiszd() { return s_Initialized;  }
        static void LoadModule(InitResult& initResult, APIResult* result);
        static void UnloadModule(APIResult* result);
        static void Initialize(APIResult* result);
        static void Terminate(APIResult* result);
        static bool CheckInitialized(APIResult* result);

        static int Start(APIResult* result);
        static void Finish(int exportID, APIResult* result);
        static int GetProgress(int exportID, APIResult* result);
        static void Cancel(int exportID, APIResult* result);

        static void ExportFromFile(int exportID, const char* title, int contentExportFormat, const char* srcPathName, APIResult* result);
        static void ExportFromFileWithThumbnail(int exportID, const char* title, int contentExportFormat, const char* srcPathName, const char* thumbPathName, APIResult* result);

        static void ExportFromData(int exportID, const char* title, int contentExportFormat, const uint8_t* contentData, size_t contentDataLength, APIResult* result);
        static void ExportFromDataWithThumbnail(int exportID, const char* title, int contentExportFormat, const uint8_t* contentData, size_t contentDataLength, int thumbnailExportFormat, const uint8_t* thumbnailData, size_t thumbnailDataLength, APIResult* result);
    private:
    };
}
