using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.PlayGo.PS5.Editor")]
[assembly: InternalsVisibleTo("Unity.PlayGo.PS5.Tests.Editor")]
