using System;
using System.Runtime.InteropServices;

namespace Unity.PlayGo.PS5
{
    /// <summary>
    /// API Results types returned from PRX calls contain details if the API call was successful,
    /// or if a warning or error was generated.
    /// </summary>
    public enum APIResultTypes
    {
        /// <summary>Result was successful</summary>
        Success = 0,
        /// <summary>A warning has occured.</summary>
        Warning = 1,
        /// <summary>An error had occured.</summary>
        Error = 2,
    };

    /// <summary>
    /// The structure even containing a successful API call or if it was a warning/error the details
    /// about the error.
    /// 
    /// This is also used to fill out the PlayGoException class when throwing an exception
    /// </summary>
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct APIResult
    {
        /// <summary>
        /// The result of the API call
        /// </summary>
        public APIResultTypes apiResult;

        IntPtr _message;

        /// <summary>
        /// Any message returned from the API call
        /// </summary>
        public string message { get { return Marshal.PtrToStringAnsi(_message); } }

        IntPtr _filename;
        /// <summary>
        /// The native C++ filename if an error or warning occured
        /// </summary>
        public string filename { get { return Marshal.PtrToStringAnsi(_filename); } }

        /// <summary>
        /// The C++ line number of any error or warning
        /// </summary>
        public Int32 lineNumber;

        /// <summary>
        /// The SCE error code returned from any native SDK methods called
        /// </summary>
        public Int32 sceErrorCode;

        /// <summary>
        /// Should the result raise an expection. Return true if an error or warning has occured.
        /// </summary>
        public bool RaiseException
        {
            get { return apiResult != APIResultTypes.Success; }
        }
    };

    /// <summary>
    /// Creates an exception to throw back to the Unity project.
    /// This can be created in the normal way or via a APIResult structure that has
    /// been returned from the Native plug-in
    /// </summary>
    public class PlayGoException : Exception
    {
        internal APIResultTypes resultType = APIResultTypes.Error;
        internal string filename;
        internal Int32 lineNumber;
        internal Int32 sceErrorCode;

        /// <summary>
        /// The type of results, either success, warning or error
        /// </summary>
        public APIResultTypes ResultType { get { return resultType; } }

        /// <summary>
        /// If from a native plug-in error the .cpp filename
        /// </summary>
        public string Filename { get { return filename; } }

        /// <summary>
        /// If from a native plug-in error the .cpp linenumber
        /// </summary>
        public Int32 LineNumber { get { return lineNumber; } }

        /// <summary>
        /// If from a native plug-in error the Sce error code
        /// </summary>
        public Int32 SceErrorCode { get { return sceErrorCode; } }

        /// <summary>
        /// Empty Exception
        /// </summary>
        public PlayGoException()
        {
        }

        /// <summary>
        /// Message only exception
        /// </summary>
        /// <param name="message">Message string</param>
        public PlayGoException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Message plus inner exception
        /// </summary>
        /// <param name="message">Message string</param>
        /// <param name="inner">Inner exception</param>
        public PlayGoException(string message, Exception inner)
            : base(message, inner)
        {
        }

        /// <summary>
        /// API result exception
        /// </summary>
        /// <param name="apiResult">The api result for the exception</param>
        public PlayGoException(APIResult apiResult)
            : base(apiResult.message)
        {
            resultType = apiResult.apiResult;
            filename = apiResult.filename;
            lineNumber = apiResult.lineNumber;
            sceErrorCode = apiResult.sceErrorCode;
        }

        /// <summary>
        /// Get the extended message for this exception.
        /// If the exception came from an error in the native plug-in it will include any Sce error code and the .cpp filename and line number.
        /// The Sce error code will be returned as a Hex character representation
        /// </summary>
        public string ExtendedMessage
        {
            get
            {
                string output = Message;

                if (sceErrorCode != 0)
                {
                    output += " (Sce : 0x" + sceErrorCode.ToString("X") + " ) ";
                }

                if (filename != null && filename.Length > 0)
                {
                    output += " ( " + filename + " : Line = " + lineNumber + " ) ";
                }

                return output;
            }
        }
    }
}

