#include <stdio.h>
#include <sdk_version.h>
#include "PluginPlayGo.h"
#include <libsysmodule.h>
#include "HandleMsg.h"
#include "BinaryBuffers.h"

#pragma comment(lib, "libScePlayGo_stub_weak.a")

namespace playgo
{
    static ScePlayGoHandle m_handle = 0;

    DO_EXPORT(void, Playgo_PrxInitialize) (SceApi::InitResult* initResult, SceApi::APIResult* result)
    {
        Main::Initialize(*initResult, result);
    }

    DO_EXPORT(void, Playgo_PrxUpdate) ()
    {
        Main::Update();
    }

    DO_EXPORT(void, Playgo_PrxShutDown) ()
    {
        Main::Shutdown();
    }

    DO_EXPORT(void, Playgo_PrxProcessMsg) (UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        MsgHandler::ProcessMsg(sourceData, sourceSize, resultsData, resultsMaxSize, resultsSize, result);
    }

    DO_EXPORT(uint64_t, Playgo_PrxConvertScenario) (uint32_t scenarioID)
    {
        return scePlayGoConvertScenario(scenarioID);
    }

    DO_EXPORT(uint64_t, Playgo_PrxConvertLanguage) (int32_t systemLanguage)
    {
        return scePlayGoConvertLanguage(systemLanguage);
    }

    DO_EXPORT(int32_t, Playgo_PrxGetPlayGoHandle) ()
    {
        return m_handle;
    }

    void InitialiseImpl(SceApi::APIResult* result)
    {
        uint32_t playGoBufSize = SCE_PLAYGO_HEAP_SIZE;

        ScePlayGoInitParams initParam;
        memset(&initParam, 0, sizeof(ScePlayGoInitParams));
        initParam.bufSize = playGoBufSize;
        initParam.bufAddr = malloc(initParam.bufSize);
        int ret = scePlayGoInitialize(&initParam);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void TerminateImpl(SceApi::APIResult* result)
    {
        int ret = scePlayGoTerminate();
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void OpenImpl(SceApi::APIResult* result)
    {
        void* param = NULL;

        int ret = scePlayGoOpen(&m_handle, param);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void CloseImpl(SceApi::APIResult* result)
    {
        int ret = scePlayGoClose(m_handle);;
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void GetLocusImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        UInt32 numberChunks = reader.ReadUInt32();

        ScePlayGoChunkId* chunkIdList = (ScePlayGoChunkId*)malloc(sizeof(ScePlayGoChunkId)*numberChunks);
        for (int i = 0; i < numberChunks; i++)
        {
            chunkIdList[i] = reader.ReadUInt16();
        }

        ScePlayGoLocus* outLoci = (ScePlayGoLocus*)malloc(sizeof(ScePlayGoLocus)*numberChunks);
        int ret = scePlayGoGetLocus(m_handle, chunkIdList, numberChunks, outLoci);

        if (ret < 0)
        {
            free(chunkIdList);
            free(outLoci);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteUInt32(numberChunks);
        for (int chunk = 0; chunk < numberChunks; chunk++)
            writer.WriteUInt8(outLoci[chunk]);

        *resultsSize = writer.GetWrittenLength();
        free(chunkIdList);
        free(outLoci);

        SUCCESS_RESULT(result);
    }

    void PrefetchImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        UInt32 numberChunks = reader.ReadUInt32();

        ScePlayGoChunkId* chunkIdList = (ScePlayGoChunkId*)malloc(sizeof(ScePlayGoChunkId)*numberChunks);
        for (int i = 0; i < numberChunks; i++)
        {
            chunkIdList[i] = reader.ReadUInt16();
        }
        ScePlayGoLocus minimumLocus = (ScePlayGoLocus)reader.ReadUInt32();

        int ret = scePlayGoPrefetch(m_handle, chunkIdList, numberChunks, minimumLocus);

        if (ret < 0)
        {
            free(chunkIdList);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        free(chunkIdList);
        SUCCESS_RESULT(result);
    }

    void GetEtaImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        UInt32 numberChunks = reader.ReadUInt32();

        ScePlayGoChunkId* chunkIdList = (ScePlayGoChunkId*)malloc(sizeof(ScePlayGoChunkId)*numberChunks);
        for (int i = 0; i < numberChunks; i++)
        {
            chunkIdList[i] = reader.ReadUInt16();
        }

        ScePlayGoEta* outEta = (ScePlayGoEta*)malloc(sizeof(ScePlayGoEta)*numberChunks);
        memset(outEta, 0, sizeof(ScePlayGoEta)*numberChunks);

        int ret = scePlayGoGetEta(m_handle, chunkIdList, numberChunks, outEta);
        if (ret < 0)
        {
            free(chunkIdList);
            free(outEta);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteUInt32(numberChunks);
        for (int chunk = 0; chunk < numberChunks; chunk++)
        {
            //UNITY_TRACE("%d eta: %ld, 0x%16lx\n", chunk, outEta[chunk], outEta[chunk]);
            writer.WriteUInt64(outEta[chunk]);
        }

        *resultsSize = writer.GetWrittenLength();
        free(chunkIdList);
        free(outEta);

        SUCCESS_RESULT(result);
    }

    void GetToDoListImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        uint32_t numberOfEntries = SCE_PLAYGO_CHUNK_INDEX_MAX;
        ScePlayGoToDo* outTodoList = (ScePlayGoToDo*)malloc(sizeof(ScePlayGoToDo)*numberOfEntries);
        uint32_t actualEntries = 0;
        int ret = scePlayGoGetToDoList(m_handle, outTodoList, numberOfEntries, &actualEntries);
        if (ret < 0)
        {
            free(outTodoList);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteUInt32(actualEntries);
        for (int chunk = 0; chunk < actualEntries; chunk++)
        {
            writer.WriteUInt16(outTodoList[chunk].chunkId);
            writer.WriteUInt8(outTodoList[chunk].locus);
        }

        *resultsSize = writer.GetWrittenLength();
        free(outTodoList);

        SUCCESS_RESULT(result);
    }

    void SetToDoListImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        int numberOfToDo = reader.ReadUInt32();
        ScePlayGoToDo* todoList = (ScePlayGoToDo*)malloc(sizeof(ScePlayGoToDo)*numberOfToDo);

        for (int i = 0; i < numberOfToDo; i++)
        {
            ScePlayGoChunkId chunkid = reader.ReadUInt16();
            ScePlayGoLocus locus = reader.ReadUInt8();
            todoList[i].chunkId = chunkid;
            todoList[i].locus = locus;
            todoList[i].reserved = 0;
        }

        int ret = scePlayGoSetToDoList(m_handle, todoList, numberOfToDo);
        if (ret < 0)
        {
            free(todoList);
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        free(todoList);

        SUCCESS_RESULT(result);
    }

    void GetChunkIdImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;
        uint32_t actualEntries = 0;

        int ret = scePlayGoGetChunkId(m_handle, NULL, 0, &actualEntries);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        ScePlayGoChunkId* chunkIdList;
        chunkIdList = (ScePlayGoChunkId*)malloc(sizeof(ScePlayGoChunkId)*actualEntries);
        ret = scePlayGoGetChunkId(m_handle, chunkIdList, actualEntries, &actualEntries);

        if (ret < 0)
        {
            free(chunkIdList);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteUInt16(actualEntries);
        for (int chunk = 0; chunk < actualEntries; chunk++)
            writer.WriteUInt16(chunkIdList[chunk]);
        free(chunkIdList);

        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }

    void GetInstallChunkIdImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;
        uint32_t actualEntries = 0;

        int ret = scePlayGoGetInstallChunkId(m_handle, NULL, 0, &actualEntries);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }
        ScePlayGoChunkId* chunkIdList;
        chunkIdList = (ScePlayGoChunkId*)malloc(sizeof(ScePlayGoChunkId)*actualEntries);
        ret = scePlayGoGetInstallChunkId(m_handle, chunkIdList, actualEntries, &actualEntries);
        if (ret < 0)
        {
            free(chunkIdList);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteUInt16(actualEntries);
        for (int chunk = 0; chunk < actualEntries; chunk++)
            writer.WriteUInt16(chunkIdList[chunk]);

        *resultsSize = writer.GetWrittenLength();
        free(chunkIdList);

        SUCCESS_RESULT(result);
    }

    void GetInstallSpeedImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        ScePlayGoInstallSpeed installSpeed = 0;
        int32_t ret = scePlayGoGetInstallSpeed(m_handle, &installSpeed);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt32(installSpeed);

        SUCCESS_RESULT(result);
    }

    void SetInstallSpeedImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        ScePlayGoInstallSpeed installSpeed = reader.ReadInt32();

        int32_t ret = scePlayGoSetInstallSpeed(m_handle, installSpeed);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void GetProgressImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        UInt32 numberChunks = reader.ReadUInt32();

        ScePlayGoChunkId* chunkIdList = (ScePlayGoChunkId*)malloc(sizeof(ScePlayGoChunkId)*numberChunks);
        for (int i = 0; i < numberChunks; i++)
        {
            chunkIdList[i] = reader.ReadUInt16();
        }

        ScePlayGoProgress outProgress;
        int ret = scePlayGoGetProgress(m_handle, chunkIdList, numberChunks, &outProgress);
        if (ret < 0)
        {
            free(chunkIdList);
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);

        writer.WriteInt64(outProgress.progressSize);
        writer.WriteInt64(outProgress.totalSize);

        *resultsSize = writer.GetWrittenLength();
        free(chunkIdList);

        SUCCESS_RESULT(result);
    }

    void GetOptionalChunkImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        UInt32 type = reader.ReadUInt32();

        ScePlayGoOptionalChunk optChunk;
        int32_t ret = scePlayGoGetOptionalChunk(m_handle, type, &optChunk);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt64(optChunk.languages);
        writer.WriteInt64(optChunk.scenarios);
        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }

    void GetSupportedOptionalChunkImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        UInt32 type = reader.ReadUInt32();

        ScePlayGoOptionalChunk optChunk;
        int32_t ret = scePlayGoGetSupportedOptionalChunk(m_handle, type, &optChunk);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        BinaryWriter writer(resultsData, resultsMaxSize);
        writer.WriteInt64(optChunk.languages);
        writer.WriteInt64(optChunk.scenarios);
        *resultsSize = writer.GetWrittenLength();

        SUCCESS_RESULT(result);
    }

    void PrefetchOptionalChunkImpl(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result)
    {
        *resultsSize = 0;

        BinaryReader reader(sourceData, sourceSize);
        ScePlayGoOptionalChunkType type = (ScePlayGoOptionalChunkType)reader.ReadUInt32();
        uint64_t languages = reader.ReadUInt64();
        uint64_t scenarios = reader.ReadUInt64();

        ScePlayGoOptionalChunk option;
        option.bitmask = 0;
        if (type == SCE_PLAYGO_OPTIONAL_CHUNK_TYPE_LANGUAGE)
            option.languages = languages;
        if (type == SCE_PLAYGO_OPTIONAL_CHUNK_TYPE_SCENARIO)
            option.scenarios = scenarios;

        int ret = scePlayGoPrefetchOptionalChunk(m_handle, type, &option);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    void RegisterMethods()
    {
        MsgHandler::AddMethod(Methods::Initialise, playgo::InitialiseImpl);
        MsgHandler::AddMethod(Methods::Terminate, playgo::TerminateImpl);
        MsgHandler::AddMethod(Methods::Open, playgo::OpenImpl);
        MsgHandler::AddMethod(Methods::Close, playgo::CloseImpl);
        MsgHandler::AddMethod(Methods::GetLocus, playgo::GetLocusImpl);
        MsgHandler::AddMethod(Methods::Prefetch, playgo::PrefetchImpl);
        MsgHandler::AddMethod(Methods::GetEta, playgo::GetEtaImpl);
        MsgHandler::AddMethod(Methods::GetToDoList, playgo::GetToDoListImpl);
        MsgHandler::AddMethod(Methods::GetChunkId, playgo::GetChunkIdImpl);
        MsgHandler::AddMethod(Methods::PrefetchOptionalChunk, playgo::PrefetchOptionalChunkImpl);
        MsgHandler::AddMethod(Methods::SetToDoList, playgo::SetToDoListImpl);

        MsgHandler::AddMethod(Methods::GetInstallChunkId, playgo::GetInstallChunkIdImpl);
        MsgHandler::AddMethod(Methods::GetInstallSpeed, playgo::GetInstallSpeedImpl);
        MsgHandler::AddMethod(Methods::SetInstallSpeed, playgo::SetInstallSpeedImpl);
        MsgHandler::AddMethod(Methods::GetProgress, playgo::GetProgressImpl);
        MsgHandler::AddMethod(Methods::GetOptionalChunk, playgo::GetOptionalChunkImpl);
        MsgHandler::AddMethod(Methods::GetSupportedOptionalChunk, playgo::GetSupportedOptionalChunkImpl);
    }

    // Main Class

    // Static Initialisation

    bool Main::s_Initialised = false;

    void Main::Initialize(SceApi::InitResult& initResult, SceApi::APIResult* result)
    {
        if (s_Initialised)
        {
            ERROR_RESULT(result, "PlayGo Plugin already initialised"); // Already initialised
            return;
        }

        LoadModules();

        s_Initialised = true;

        initResult.initialized = true;
        initResult.sceSDKVersion = SCE_PROSPERO_SDK_VERSION;

        RegisterMethods();

        SUCCESS_RESULT(result);
    }

    void Main::Update()
    {
        if (s_Initialised == false)
        {
            return;
        }
    }

    void Main::Shutdown()
    {
        UnloadModules();

        s_Initialised = false;
    }

    void Main::LoadModules()
    {
        int res;

        res = sceSysmoduleLoadModule(SCE_SYSMODULE_PLAYGO);

        if (res != 0)
        {
            printf("Error loading SCE_SYSMODULE_PLAYGO, 0x%x\n", res);
        }

        res = sceSysmoduleLoadModule(SCE_SYSMODULE_PLAYGO_DIALOG);

        if (res != 0)
        {
            printf("Error loading SCE_SYSMODULE_PLAYGO_DIALOG, 0x%x\n", res);
        }
    }

    void Main::UnloadModules()
    {
        int res;

        res = sceSysmoduleUnloadModule(SCE_SYSMODULE_PLAYGO);
        if (res != 0)
        {
            printf("Error loading SCE_SYSMODULE_PLAYGO, 0x%x\n", res);
        }

        res = sceSysmoduleUnloadModule(SCE_SYSMODULE_PLAYGO_DIALOG);
        if (res != 0)
        {
            printf("Error loading SCE_SYSMODULE_PLAYGO_DIALOG, 0x%x\n", res);
        }
    }

    extern "C" int module_start(size_t sz, const void* arg)
    {
        return 0;
    }
}
