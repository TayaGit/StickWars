#include "Plugin.h"

#include <playgo\playgo_error.h>
#include <common_dialog\error.h>

namespace SceApi
{

#define SCE_ERROR_ITEM(errCode) { errCode, #errCode }
    ErrorItem sm_Errors[] =
    {
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_UNKNOWN),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_FATAL),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_NO_MEMORY),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_INVALID_ARGUMENT),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_NOT_INITIALIZED),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_ALREADY_INITIALIZED),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_ALREADY_STARTED),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_NOT_STARTED),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_HANDLE),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_POINTER),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_SIZE),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_CHUNK_ID),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_SPEED),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_NOT_SUPPORT_PLAYGO),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_EPERM),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_LOCUS),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_NEED_DATA_DISC),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_LANG_CONFIGURATION),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_CHUNK_CONFIGURATION),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_PROHIBIT_CHUNK_ID),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_OPTIONAL_TYPE),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_MISSING_OPTIONAL_CHUNK),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_BAD_SCENARIO_CONFIGURATION),
        SCE_ERROR_ITEM(SCE_PLAYGO_ERROR_DEVICE_NOSPC),

        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_NOT_SYSTEM_INITIALIZED),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_ALREADY_SYSTEM_INITIALIZED),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_NOT_INITIALIZED),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_ALREADY_INITIALIZED),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_NOT_FINISHED),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_INVALID_STATE),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_RESULT_NONE),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_BUSY),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_OUT_OF_MEMORY),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_PARAM_INVALID),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_NOT_RUNNING),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_ALREADY_CLOSE),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_ARG_NULL),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_UNEXPECTED_FATAL),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_NOT_SUPPORTED),
        SCE_ERROR_ITEM(SCE_COMMON_DIALOG_ERROR_INHIBIT_SHAREPLAY_CLIENT),
    };

    const ErrorItem& FindSceErrorItem(int32_t errorCode)
    {
        const size_t items = sizeof(sm_Errors) / sizeof(ErrorItem);
        for (int i = 0; i < items; ++i)
        {
            if (sm_Errors[i].errorCode == errorCode)
            {
                return sm_Errors[i];
            }
        }

        static ErrorItem unknownError = {-1, "Unknown Error"};
        return unknownError;
    }

    void APIResult::SetResult(APIResult* result, APIResultTypes type)
    {
        SetResult(result, type, "", "", 0);
    }

    void APIResult::SetResult(APIResult* result, APIResultTypes type, char const* message, char const* filename, int lineNumber)
    {
        result->apiResult = type;
        result->message = message ? message : "";
        result->filename = filename ? filename : "";
        result->lineNumber = lineNumber;
        result->sceErrorCode = 0;
    }

    void APIResult::SetSceResult(APIResult* result, APIResultTypes type, int sceErrorCode, char const* filename, int lineNumber)
    {
        char const* message = FindSceErrorItem(sceErrorCode).errorName;

        SetResult(result, type, message, filename, lineNumber);

        result->sceErrorCode = sceErrorCode;
    }
}   // of namespace SceApi
