#ifndef _PLUGINPLAYGO_H
#define _PLUGINPLAYGO_H

#include "Plugin.h"
#include <playgo.h>
#include <playgo_dialog.h>

namespace playgo
{
    // must match PlayGo.NativeMethods in main.cs
    enum Methods
    {
        Initialise = 0x0200001u,
        Terminate = 0x0200002u,
        Open = 0x0200003u,
        Close = 0x0200004u,
        GetLocus = 0x0200005u,
        Prefetch = 0x0200006u,
        GetEta = 0x0200007u,
        GetToDoList = 0x0200008u,
        GetChunkId = 0x0200009u,
        PrefetchOptionalChunk = 0x020000Au,
        SetToDoList = 0x020000Bu,

        GetInstallChunkId = 0x020000Cu,
        GetInstallSpeed = 0x020000Du,
        SetInstallSpeed = 0x020000Eu,
        GetProgress = 0x020000Fu,
        GetOptionalChunk = 0x0200010u,
        GetSupportedOptionalChunk = 0x0200011u,
    };

    class Main
    {
    public:

    private:

        static bool s_Initialised;

    public:

        static void Initialize(SceApi::InitResult& initResult, SceApi::APIResult* result);
        static void Update();
        static void Shutdown();

        static void LoadModules();
        static void UnloadModules();

        //		static PrxPluginInterface s_PrxInterface;


    private:


    };



}

#endif	//_MAIN_H




