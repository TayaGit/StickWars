#include <stdio.h>
#include "PluginPlayGo.h"
#include <playgo_dialog.h>
#include "BinaryBuffers.h"
#include <string>

#pragma comment(lib, "libScePlayGoDialog_stub_weak.a")

namespace playgo
{
    enum Mode
    {
        Invalid = 0,
        ProgressBar = 1,    // Display progress bar.
        //DiscChange = 2,     // Display disc change guide.
        RequestInstall = 3, // Display additional installation.
    };

    enum ProgressBarType
    {
        SingleChunkList = 0,        // Display progress bar for a single chunk list.
        EnumeratedChunkList = 1,    // Display progress bar for multiple chunk lists.
    };

    //enum DiscChangeType
    //{
    //    LanguageMask = 0,           // Disc change by specifying language mask.
    //};

    enum Result
    {
        Ok = 0,                         // Closed by user operation or closed by scePlayGoDialogClose()
        AutoClosed = 3,                 // Dialog was closed automatically given the preparation completion of the specified chunks
        OpenParamInvalid = -2135425014, // SCE_COMMON_DIALOG_ERROR_PARAM_INVALID - Parameter content specified to scePlayGoDialogOpen() is invalid.
    };

    enum Status
    {
        None = 0,           // Dialog is not running
        Initialized = 1,    // Dialog is initialized
        Running = 2,        // Dialog is being displayed
        Finished = 3,       // Dialog is closed
    };

    struct DialogResult
    {
        Mode mode;          // The mode the dialog was in.
        int32_t result;     // The dialog result.
    };

    //struct ProgressDialogItem
    //{
    //    ScriptingArrayPtr chunkIDs;
    //    ScriptingStringPtr label;
    //};

    void OpenProgressDialog(int32_t handle, UInt8* sourceData, int sourceSize, SceApi::APIResult* apiResult);
    void OpenRequestInstallDialog(int32_t handle, ScePlayGoOptionalChunkType optionalChunkType, uint64_t bitmask, SceApi::APIResult* apiResult);
    Status UpdateStatus();
    DialogResult GetResult(SceApi::APIResult* apiResult);
    void CloseDialog(SceApi::APIResult* apiResult);

    DO_EXPORT(void, PrxOpenProgressDialog) (int32_t handle, UInt8* sourceData, int sourceSize, SceApi::APIResult* apiResult)
    {
        OpenProgressDialog(handle, sourceData, sourceSize, apiResult);
    }

    DO_EXPORT(void, PrxOpenRequestInstallDialog) (int32_t handle, ScePlayGoOptionalChunkType optionalChunkType, uint64_t bitmask, SceApi::APIResult* apiResult)
    {
        OpenRequestInstallDialog(handle, optionalChunkType, bitmask, apiResult);
    }

    DO_EXPORT(Status, PrxUpdateStatus) ()
    {
        return UpdateStatus();
    }

    DO_EXPORT(DialogResult, PrxGetResult) (SceApi::APIResult* apiResult)
    {
        return GetResult(apiResult);
    }

    DO_EXPORT(void, PrxCloseDialog) (SceApi::APIResult* apiResult)
    {
        CloseDialog(apiResult);
    }

    int32_t InitializePlayGoDialog()
    {
        int32_t ret = scePlayGoDialogInitialize();
        if (ret == SCE_COMMON_DIALOG_ERROR_ALREADY_INITIALIZED)
        {
            return 0;
        }

        return ret;
    }

    int32_t TerminatePlayGoDialog()
    {
        int32_t ret = scePlayGoDialogTerminate();
        if (ret == SCE_COMMON_DIALOG_ERROR_NOT_INITIALIZED)
        {
            return 0;
        }

        return ret;
    }

    void OpenProgressDialog(int32_t handle, UInt8* sourceData, int sourceSize, SceApi::APIResult* apiResult)
    {
        CompileTimeAssert(ProgressBarType::SingleChunkList == SCE_PLAYGO_DIALOG_PROGRESSBAR_TYPE_SINGLE_CHUNKLIST, "Unexpected enum value");
        CompileTimeAssert(ProgressBarType::EnumeratedChunkList == SCE_PLAYGO_DIALOG_PROGRESSBAR_TYPE_ENUMERATED_CHUNKLIST, "Unexpected enum value");
        CompileTimeAssert(sizeof(ScePlayGoChunkId) == sizeof(uint16_t), "Unexpected type size");

        int32_t ret = InitializePlayGoDialog();
        if (ret < 0)
        {
            SCE_ERROR_RESULT(apiResult, ret);
            return;
        }

        BinaryReader reader(sourceData, sourceSize);

        uint32_t numChunkArrays = reader.ReadInt32();
        if (numChunkArrays == 0 || numChunkArrays > SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_MAX)
        {
            UNITY_TRACE("numArrays out or range error, was %d, min allowed is %d, max allowed is %d\n", numChunkArrays, 0, SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_MAX);
            SCE_ERROR_RESULT(apiResult, SCE_PLAYGO_ERROR_INVALID_ARGUMENT);
            return;
        }

        ScePlayGoDialogChunkListItem chunkList[SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_MAX];
        memset(chunkList, 0, sizeof(chunkList));
        UNITY_TRACE("sizeof(chunkList): %ld\n", sizeof(chunkList));

        std::string labels[SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_MAX];

        ScePlayGoChunkId chunkIDs[SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_MAX][SCE_PLAYGO_CHUNK_INDEX_MAX];
        for (int li = 0; li < numChunkArrays; li++)
        {
            // Chunk ID array.
            chunkList[li].numberOfEntries = reader.ReadUInt32();
            UNITY_TRACE(" listItems[%d].numberOfEntries = %d\n", li, chunkList[li].numberOfEntries);
            if (chunkList[li].numberOfEntries >= SCE_PLAYGO_CHUNK_INDEX_MAX)
            {
                UNITY_TRACE("A progress dialog was passed too many chunk IDs, max allowed is %d.\n", SCE_PLAYGO_CHUNK_INDEX_MAX);
                SCE_ERROR_RESULT(apiResult, SCE_PLAYGO_ERROR_INVALID_ARGUMENT);
                return;
            }

            for (int ci = 0; ci < chunkList[li].numberOfEntries; ci++)
            {
                chunkIDs[li][ci] = reader.ReadUInt16();
                UNITY_TRACE(" chunkIDs[%d][%d] = %d\n", li, ci, chunkIDs[li][ci]);
            }
            chunkList[li].chunkIds = &chunkIDs[li][0];

            // Label string.
            uint32_t labelLen = reader.ReadUInt32();
            char labelBytes[SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_LABEL_SIZE];
            if (labelLen + 1 > SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_LABEL_SIZE)
            {
                UNITY_TRACE("A progress dialog label length exceeds the maximum allowed, max allowed length is %d including the string terminator.\n", SCE_PLAYGO_DIALOG_CHUNKLIST_ITEM_LABEL_SIZE);
                SCE_ERROR_RESULT(apiResult, SCE_PLAYGO_ERROR_INVALID_ARGUMENT);
                return;
            }
            memset(labelBytes, 0, sizeof(labelBytes));
            reader.ReadData(labelBytes, labelLen);
            labels[li] = labelBytes;
            UNITY_TRACE(" labels[%d] (len:%d) = \"%s\"\n", li, labelLen, labels[li].c_str());

            chunkList[li].label = (labels[li].length() > 0) ? labels[li].c_str() : nullptr;

            if (!chunkList[li].label && numChunkArrays > 1)
            {
                UNITY_TRACE("If more than 1 chunk list is specified for the progress dialog then a descriptive label must be specified for all chunk lists.\n");
                SCE_ERROR_RESULT(apiResult, SCE_PLAYGO_ERROR_INVALID_ARGUMENT);
                return;
            }
        }

        ScePlayGoDialogProgressBarParam progBarParam;
        memset(&progBarParam, 0, sizeof(progBarParam));
        progBarParam.barType = (numChunkArrays == 1) ? SCE_PLAYGO_DIALOG_PROGRESSBAR_TYPE_SINGLE_CHUNKLIST : SCE_PLAYGO_DIALOG_PROGRESSBAR_TYPE_ENUMERATED_CHUNKLIST;
        progBarParam.chunkList = chunkList;
        progBarParam.numberOfEntries = numChunkArrays;

        ScePlayGoDialogParam param;
        scePlayGoDialogParamInitialize(&param);
        param.mode = SCE_PLAYGO_DIALOG_MODE_PROGRESS_BAR;
        param.handle = handle;
        param.progBarParam = &progBarParam;
        ret = scePlayGoDialogOpen(&param);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(apiResult, ret);
            return;
        }

        SUCCESS_RESULT(apiResult);
    }

    void OpenRequestInstallDialog(int32_t handle, ScePlayGoOptionalChunkType optionalChunkType, uint64_t bitmask, SceApi::APIResult* apiResult)
    {
        CompileTimeAssert(sizeof(ScePlayGoLanguageMask) == sizeof(uint64_t), "Unexpected type size");
        CompileTimeAssert(sizeof(ScePlayGoScenarioMask) == sizeof(uint64_t), "Unexpected type size");

        int32_t ret = InitializePlayGoDialog();
        if (ret < 0)
        {
            SCE_ERROR_RESULT(apiResult, ret);
            return;
        }

        ScePlayGoDialogParam param;
        scePlayGoDialogParamInitialize(&param);
        param.mode = SCE_PLAYGO_DIALOG_MODE_REQUEST_INSTALL;
        param.handle = handle;

        ScePlayGoDialogRequestInstallParam requestInstallParam;
        ScePlayGoOptionalChunk option;
        option.bitmask = bitmask;

        param.requestInstallParam = &requestInstallParam;
        memset(&requestInstallParam, 0x00, sizeof(requestInstallParam));
        requestInstallParam.option = &option;
        requestInstallParam.type = optionalChunkType;

        ret = scePlayGoDialogOpen(&param);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(apiResult, ret);
            return;
        }

        SUCCESS_RESULT(apiResult);
    }

    Status UpdateStatus()
    {
        SceCommonDialogStatus status = scePlayGoDialogUpdateStatus();
        return (Status)status;
    }

    DialogResult GetResult(SceApi::APIResult* apiResult)
    {
        CompileTimeAssert(Result::Ok == (int)SceCommonDialogResult::SCE_COMMON_DIALOG_RESULT_OK, "Unexpected enum value");
        CompileTimeAssert(Result::AutoClosed == SCE_PLAYGO_DIALOG_RESULT_AUTO_CLOSED, "Unexpected enum value");
        CompileTimeAssert(Result::OpenParamInvalid == SCE_COMMON_DIALOG_ERROR_PARAM_INVALID, "Unexpected enum value");

        ScePlayGoDialogResult result;
        memset(&result, 0, sizeof(result));
        int32_t ret = scePlayGoDialogGetResult(&result);
        if (result.result == SCE_COMMON_DIALOG_ERROR_PARAM_INVALID)
        {
            UNITY_TRACE("scePlayGoDialogGetResult failed because params for scePlayGoDialogOpen were invalid, error code 0x%08x - %s\n",
                result.result,
                SceApi::FindSceErrorItem(result.result).errorName);
        }
        else if (ret < 0)
        {
            SCE_ERROR_RESULT(apiResult, ret);
            return {Mode(SCE_PLAYGO_DIALOG_MODE_INVALID), ret};
        }

        SUCCESS_RESULT(apiResult);
        return {Mode(result.mode), result.result};
    }

    void CloseDialog(SceApi::APIResult* apiResult)
    {
        int32_t ret = scePlayGoDialogClose();
        if (ret == SCE_COMMON_DIALOG_ERROR_NOT_INITIALIZED)
        {
            // Dialog is not initialized, but that's OK, it just means there's nothing to do.
            SUCCESS_RESULT(apiResult);
            return;
        }
        if (ret < 0 && ret != SCE_COMMON_DIALOG_ERROR_NOT_RUNNING)
        {
            // Dialog was running and there was an error when closing, so return the error so the dev can act on it if desired.
            SCE_ERROR_RESULT(apiResult, ret);
            return;
        }

        // We terminate the PlayGo dialog library whenever we close the dialog, this ensures it won't block other non-PlayGo uses of the common dialog library.
        ret = TerminatePlayGoDialog();
        if (ret < 0)
        {
            SCE_ERROR_RESULT(apiResult, ret);
            return;
        }
    }
}
