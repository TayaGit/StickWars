#pragma once


#define PRX_INTERFACE __declspec(dllexport)
typedef unsigned int UInt32;
typedef unsigned char UInt8;

typedef int SceUserServiceUserId;
#include <map>
#include <list>
#include <system_service.h>


namespace UnityEventQueue
{
    class IEventQueue;
}

namespace SceApi { struct PRX_INTERFACE APIResult; }

namespace playgo
{
    class PRX_INTERFACE MsgHandler
    {
    public:

        typedef void(*MethodCallbackSimple)(SceApi::APIResult* result);
        typedef void(*MethodCallbackWithData)(UInt8* sourceData, int sourceSize, SceApi::APIResult* result);
        typedef void(*MethodCallbackFull)(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result);

        struct MsgHeader
        {
            UInt32 version;
            UInt32 methodId;
        };

        static std::map<int, MethodCallbackSimple> s_MethodSimpleList;
        static std::map<int, MethodCallbackWithData> s_MethodWithDataList;
        static std::map<int, MethodCallbackFull> s_MethodFullList;

        static void ProcessMsg(UInt8* sourceData, int sourceSize, UInt8* resultsData, int resultsMaxSize, int* resultsSize, SceApi::APIResult* result);

        static bool GetSimpleMethod(UInt32 methodId, MethodCallbackSimple* foundMethod);
        static bool GetWithDataMethod(UInt32 methodId, MethodCallbackWithData* foundMethod);
        static bool GetFullMethod(UInt32 methodId, MethodCallbackFull* foundMethod);

        static void AddMethod(int methodId, MethodCallbackSimple methodCallback);
        static void AddMethod(int methodId, MethodCallbackWithData methodCallback);
        static void AddMethod(int methodId, MethodCallbackFull methodCallback);

        enum UserState
        {
            Added,
            Removed,
        };

        typedef void(*UserStateCallback)(SceUserServiceUserId userId, UserState state, SceApi::APIResult* result);

        static std::list<UserStateCallback> s_UserStateCallbackList;

        static void NotifyAddUser(SceUserServiceUserId userId, SceApi::APIResult* result);
        static void NotifyRemoveUser(SceUserServiceUserId userId, SceApi::APIResult* result);
        static void RegisterUserCallback(UserStateCallback callback);

        typedef void(*SystemEventCallback)(SceSystemServiceEvent& sevent);

        static std::list<SystemEventCallback> s_SystemEventCallbackList;
        static void NotifySystemEvent(SceSystemServiceEvent& sevent);

        static void RegisterSystemEventCallback(SystemEventCallback callback);

        static void InitialiseSystemEventManager(UnityEventQueue::IEventQueue* eventQueue);
    };
}
