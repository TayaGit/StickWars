# PS5 PlayGo Package

The PlayGo package implements an API to provide access to the PS5 PlayGo features.

<!-- This package provides offline HTML documentation. Open `HTML~/index.html` from the package directory to view it locally. -->

To get started, refer to the [Installation](Installation.md) section.

To try out the PlayGo Sample app, refer to the [Sample](Sample.md) instructions.
