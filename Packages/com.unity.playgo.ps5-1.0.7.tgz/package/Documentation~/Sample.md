
# PlayGo Sample

## Installation

1) Create a new Unity project and install the package, see [Installation](Installation.md)) for details.

2) Install the __PlayGo Sample__ from the package manager window by clicking the __Import into project__ button.

   ![Package Manager](Images/packman.png)

3) Switch build settings to PS5

4) To setup the project settings select the menu option in (menu: __SCE Publishing Utils__)

   ![Package Manager](Images/samplesetup.png)

   * __Prepare Project Assets And Settings__ will update the publishing settings section (in the __Player Settings__), and copy some assets into the StreamingAssets folder.

5) Open the __PlayGo Sample__ Unity scene located in __Assets/Samples/PS5 PlayGo/*version*/PlayGo Sample/__}

   The *version* number will depend on the package version.

6) Add the scene to the __Scenes In Build__ list, as scene 0, and build the project.
