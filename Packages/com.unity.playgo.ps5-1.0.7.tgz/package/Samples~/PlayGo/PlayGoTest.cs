#if UNITY_PS5
using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.PlayGo.PS5;
using Unity.PlayGo.PS5.Aysnc;

//
// The sample below contains test code for the various methods provided by the Unity.PlayGo.PS5 namespace.
//
// The sample code does not demonstrate any game functionality and is intended purely as a test and to demonstrate
// how to call the PlayGo API. To avoid blocking the main thread most of the PlayGo methods use an asynchrounous
// request system similar to that used by the PSN package (com.unity.psn.ps5), the sample code below uses a simple
// state machine to manage transitioning from one test to another when an asyc request completes.
//
// Sony's PlayGo library documention can be found at https://game.develop.playstation.net/resources/documents/sdk/latest/PlayGo-Overview/__toc.html
//
// Required files in the sce_sys folder...
//
// PlayGo requires some additional files in the sce_sys folder which are used to identify and describe any PlayGo
// content, for details see https://game.develop.playstation.net/resources/documents/sdk/latest/Content_Information-Specifications/0009.html
//
// The sample also demonstrates the following...
//
// PC Hosted PlayGo Emulation.
//
// For Unity 2022 and later the sample uses the UnityEditor.PS5.IPostProcessPS5PrepareStagingArea interface to insert
// a playgo-chunks.xml file into a PC hosted build to enable PlayGo emulation during development. For older versions
// of Unity similar functionality is available in UnityEditor.PS5.IPostProcessPS5, refer to the PlayGoPS5ProjectPostProcess
// class in the sample code for details.
//
// Building PlayGo GP5 Projects and Packages.
//
// For Unity 2022 and later the sample uses the UnityEditor.PS5.IPostProcessPS5CreateGP5Project interface to generate
// a custom GP5 project containing PlayGo scenario and chunk information for creating an installable PS5 package that
// supports PlayGo.
//

namespace PlayGoSample
{
    public class PlayGoTest : MonoBehaviour
    {
        // Array defining the sequence of states to be tested.
        PlayGoState[] m_Steps = new PlayGoState[]
        {
            PlayGoState.Waiting,
            PlayGoState.Initialize,
            PlayGoState.Open,
            PlayGoState.GetInstallSpeed,
            PlayGoState.SetInstallSpeed,
            PlayGoState.GetInstallSpeed,
            PlayGoState.GetChunkIDs,
            PlayGoState.GetInstallChunkIDs,
            PlayGoState.GetProgress,
            PlayGoState.GetLocus,
            PlayGoState.Prefetch,
            PlayGoState.GetEta,
            PlayGoState.GetToDo,
            PlayGoState.GetOptionalChunk_Languages,
            PlayGoState.GetOptionalChunk_Scenarios,
            PlayGoState.GetSupportedOptionalChunk_Languages,
            PlayGoState.GetSupportedOptionalChunk_Scenarios,
            PlayGoState.PrefetchOptionalChunk,
            PlayGoState.SetToDo,
            PlayGoState.GetToDo,
            PlayGoState.OpenProgressDialog,
            PlayGoState.OpenProgressDialogWithLabel,
            PlayGoState.OpenMultiListProgressDialog,
            PlayGoState.OpenRequestInstallScenarioDialog,
            PlayGoState.OpenRequestInstallLanguageDialog,
            //PlayGoState.EmuRequestNextChunk,  // EmuRequestNextChunk requires the PlayGo_nosubmission.prx, see "Note 1" below...
            //PlayGoState.EmuRequestNextChunk,
            //PlayGoState.EmuRequestNextChunk,
            //PlayGoState.GetToDo,              // Get the updated to do list, EmuRequestNextChunk will have changed it.
            PlayGoState.Close,
            PlayGoState.Terminate,
            PlayGoState.AllDone,
        };

        // Note 1 - Testing PlayGoState.EmuRequestNextChunk requires the PlayGo_nosubmission.prx native plugin which links with the "libScePlayGo_nosubmission_stub_weak.a" library.
        // By default PlayGo_nosubmission.prx has been renamed to PlayGo_nosubmission.prx_disabled to ensure that it is not accidentally included in a submission build.

        PlayGoState m_State = PlayGoState.Uninitialized;
        int m_CurrentStep = 0;
        StateTransition m_DefaultStateTransition = new StateTransition(PlayGoState.Next);
        StateTransition m_NullStateTransition = new StateTransition(PlayGoState.NullState, PlayGoState.NullState, PlayGoState.NullState);
        StateTransition m_StateTransitionAfterDialog;
        Dialog.Status m_DialogStatus = Dialog.Status.None;
        float m_DelayTime = 0.0f;
        StateTransition m_StateTransitionAfterDelay;
        string m_LogText = "";

        List<ushort> m_ChunkIDs;
        List<Main.Locus> m_Loci;
        List<Main.Todo> m_ToDoList;
        Main.OptionalChunk m_CurrentScenarioMask;
        Main.OptionalChunk m_CurrentLanguageMask;
        Main.OptionalChunk m_SupportedOptionalScenarioChunk;
        Main.OptionalChunk m_SupportedOptionalLanguageChunk;
        bool m_DialogOpen = false;

        // Start is called before the first frame update.
        //
        void Start()
        {
            PlayGoSample.OnScreenInfo.sm_LogEventHandlers += OnAddLogText;

#if PLATFORM_PS5
            UnityEngine.PS5.Utility.onSystemServiceEvent += OnSystemServiceEvent;
#endif

            m_State = PlayGoState.Next;
        }

        // Update is called once per frame.
        //
        void Update()
        {
            if (!UnityEngine.Rendering.SplashScreen.isFinished)
            {
                return;
            }

            UpdateDialog();
            ExecuteCurrentState();

            m_LogText = GetDiagnosticInfo();
        }

#if PLATFORM_PS5
        // Handle any PlayGo related system service events.
        //
        void OnSystemServiceEvent(UnityEngine.PS5.Utility.SystemServiceEventType type, IntPtr paramData)
	    {
            PlayGoSample.OnScreenLog.Add($"* System Service Event - {type}");

            switch(type)
            {
                case UnityEngine.PS5.Utility.SystemServiceEventType.PlaygoLocusUpdate:  // PlayGo chunk state changed
                    break;

                case UnityEngine.PS5.Utility.SystemServiceEventType.PlaygoChunkAdded:   // Installable chunk added
                    break;
            }
        }
#endif

        // Event handler, called once per frame to add log text to the OnScreenInfo display.
        //
        public void OnAddLogText(PlayGoSample.OnScreenInfo.LogEventArgs eventArgs)
        {
            eventArgs.logText += m_LogText;
        }

        // Format an APIResult with SCE error code into a string.
        //
        string SceErrorToString(APIResult result)
        {
            if (result.message.Length > 0)
                return $"sceErrorCode: {result.message} (0x{result.sceErrorCode:X8})";
            return $"sceErrorCode: 0x{result.sceErrorCode:X8}";
        }

        // Initialize the PlayGo system.
        //
        void Initialize(StateTransition states)
        {
            // First try and verify that the sample has been correctly setup and built.
            string testFilePath = System.IO.Path.Combine(Application.streamingAssetsPath, "testfile0.txt");
            if (!System.IO.File.Exists(testFilePath))
            {
                PlayGoSample.OnScreenLog.Add($"Failed to find file \"{testFilePath}\"");
                PlayGoSample.OnScreenLog.Add("The sample may need setting up.");
                PlayGoSample.OnScreenLog.Add("In the Unity Editor select the menu option \"Prepare Project Assets And Settings\" which can be found in the \"SCE Publishing Utils / Play Go Sample\" menu.", true);
                m_State = states.SetStateFailed(m_State);
                return;
            }
            PlayGoSample.OnScreenLog.Add($"Found find file \"{testFilePath}\"");

            m_State = states.SetStateWaiting(m_State);

            // Initialize PlayGo.
#if PLATFORM_PS5 && !UNITY_EDITOR
            Unity.PlayGo.PS5.Initialization.InitResult initResult = Unity.PlayGo.PS5.Main.Initialize();
            PlayGoSample.OnScreenLog.Add($"Initialized PlayGo Plugin - SDK Version {initResult.SceSDKVersion}");

            Main.InitialiseRequest request = new Main.InitialiseRequest();
            Main.Schedule(new AsyncRequest<Main.InitialiseRequest>(request).ContinueWith((antecedent) =>
            {
                PlayGoSample.OnScreenLog.Add("Main.InitialiseRequest succeeded");
                m_State = states.SetStateSucceeded(m_State);

                CloseDialogWhenFinished();
            }));
#endif
        }

        // Shutdown the PlayGo system.
        //
        void Terminate(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5 && !UNITY_EDITOR
            Main.TerminateRequest request = new Main.TerminateRequest();
            Main.Schedule(new AsyncRequest<Main.TerminateRequest>(request).ContinueWith((antecedent) =>
            {
                PlayGoSample.OnScreenLog.Add("Main.TerminateRequest succeeded");
                m_State = states.SetStateSucceeded(m_State);
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        // Test Unity.PlayGo.PS5.Main.OpenRequest
        //
        void Open(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);

#if PLATFORM_PS5 && !UNITY_EDITOR
            Main.Schedule(new AsyncRequest<Main.OpenRequest>(new Main.OpenRequest()).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    int handle = Main.GetPlayGoHandle();
                    PlayGoSample.OnScreenLog.Add($"Main.OpenRequest succeeded, handle = {handle}");

                    m_State = states.SetStateSucceeded(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"PlayGo open failed. {SceErrorToString(antecedent.Request.Result)}");
                    if ((System.UInt32)(antecedent.Request.Result.sceErrorCode) == 0x80B20008)
                    {
                        PlayGoSample.OnScreenLog.Add($"Not started because package could not be opened.");
                        PlayGoSample.OnScreenLog.Add($"For development, perhaps you are missing the \"PlayGo Emulation Feature\" file playgo-chunks.xml, or if it exists it may have a problem with it's contents.");
                    }
                    else
                    {
                    }
                    m_State = states.SetStateFailed(m_State);
                }
            }));
#else
            m_State = states.SetStateSucceeded(m_State);
#endif
        }

        // Test Unity.PlayGo.PS5.Main.CloseRequest
        //
        void Close(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);

            Main.Schedule(new AsyncRequest<Main.CloseRequest>(new Main.CloseRequest()).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult == APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add("Main.CloseRequest succeeded");
                    m_State = states.SetStateSucceeded(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"PlayGo close failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.EmuRequestNextChunk
        //
        void EmuRequestNextChunk(StateTransition states)
        {
            // Main.EmuRequestNextChunk is only available when the PlayGo_nosubmission.prx native plugin is included in the build, this plugin must
            // not be included for submission builds as it links with Sony's library "libScePlayGo_nosubmission_stub_weak.a" which is only valid for
            // non-submission builds, i.e. for development use only.
            try
            {
                APIResult result;
                Main.EmuRequestNextChunk(Main.GetPlayGoHandle(), out result);
                if (result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Dialog.EmuRequestNextChunk failed. {SceErrorToString(result)}");
                    m_State = states.SetStateFailed(m_State);
                    return;
                }
                PlayGoSample.OnScreenLog.Add("Main.EmuRequestNextChunk succeeded");
                m_State = states.SetStateSucceeded(m_State);
            }
            catch(DllNotFoundException e)
            {
                // Main.EmuRequestNextChunk is only available when using the non-submittable PlayGo native plugin which contains code
                // that calls into Sony's debug PlayGo library, this libarary must not be included in packages that are intended for submission
                // so by default the PlayGo_nosubmission.prx plugin has been renamed to avoid including it in the build. To enable this feature
                // you need to rename the plugin, removing the word "_disabled" from it's file extension.
                PlayGoSample.OnScreenLog.Add("Main.EmuRequestNextChunk not called, requires the PlayGo_nosubmission.prx plugin.");
                m_State = states.SetStateSucceeded(m_State);
                Debug.LogError("EmuRequestNextChunk Exception : " + e.Message);
            }
        }

        // Test Unity.PlayGo.PS5.Main.GetInstallSpeedRequest
        //
        void GetInstallSpeed(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            Main.Schedule(new AsyncRequest<Main.GetInstallSpeedRequest>(new Main.GetInstallSpeedRequest()).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetInstallSpeedRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetInstallSpeedRequest succeeded");
                    PlayGoSample.OnScreenLog.Add($"    InstallSpeed {antecedent.Request.installSpeed}");
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.SetInstallSpeedRequest
        //
        void SetInstallSpeed(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.SetInstallSpeedRequest();
            request.installSpeed = Main.InstallSpeed.Full;
            Main.Schedule(new AsyncRequest<Main.SetInstallSpeedRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.SetInstallSpeedRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.SetInstallSpeedRequest succeeded");
                    PlayGoSample.OnScreenLog.Add($"    InstallSpeed {antecedent.Request.installSpeed}");
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.GetChunkIdRequest
        //
        void GetChunkIDs(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            Main.Schedule(new AsyncRequest<Main.GetChunkIdRequest>(new Main.GetChunkIdRequest()).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetChunkIdRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetChunkIdRequest succeeded");
                    string IDs = "    Chunk IDs ";
                    foreach (ushort chunkId in antecedent.Request.ChunkIds)
                    {
                        IDs += $" {chunkId}";
                    }
                    PlayGoSample.OnScreenLog.Add(IDs);

                    // Store the chunk ID list for use later.
                    m_ChunkIDs = antecedent.Request.ChunkIds;

                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.GetInstallChunkIdRequest
        //
        void GetInstallChunkIDs(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            Main.Schedule(new AsyncRequest<Main.GetInstallChunkIdRequest>(new Main.GetInstallChunkIdRequest()).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetInstallChunkIdRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetInstallChunkIdRequest succeeded");
                    string IDs = "    Install chunk IDs ";
                    foreach (ushort chunkId in antecedent.Request.ChunkIds)
                    {
                        IDs += $" {chunkId}";
                    }
                    PlayGoSample.OnScreenLog.Add(IDs);
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.GetProgressRequest
        //
        void GetProgress(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);

            var request = new Main.GetProgressRequest();
            request.ChunkIds = m_ChunkIDs;    // use result from GetChunkIdRequest

            Main.Schedule(new AsyncRequest<Main.GetProgressRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetProgressRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetProgressRequest succeeded");
                    PlayGoSample.OnScreenLog.Add($"    Progress {antecedent.Request.TotalProgress.progressSize} / {antecedent.Request.TotalProgress.totalSize}");
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.GetLocusRequest
        //
        void GetLocus(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.GetLocusRequest();
            request.ChunkIds = m_ChunkIDs;    // use result from GetChunkIdRequest

            Main.Schedule(new AsyncRequest<Main.GetLocusRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetLocusRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetLocusRequest succeeded");
                    for (int index = 0; index < antecedent.Request.Loci.Count; index++)
                    {
                        PlayGoSample.OnScreenLog.Add($"    ChunkId {request.ChunkIds[index]}, {antecedent.Request.Loci[index]}");
                    }

                    // Store the chunk loci for later use.
                    m_Loci = antecedent.Request.Loci;

                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        List<ushort> FilterChunksIDsForLocus(List<ushort> chunks, List<Main.Locus> loci, Main.Locus[] locusFilter)
        {
            List<ushort> result = new List<ushort>();

            for (int ci = 0; ci < chunks.Count; ci++)
            {
                for (int fi = 0; fi < locusFilter.Length; fi++)
                {
                    if (loci[ci] == locusFilter[fi])
                    {
                        result.Add(chunks[ci]);
                        break;
                    }
                }
            }

            return result;
        }

        // Test Unity.PlayGo.PS5.Main.PrefetchRequest
        //
        void Prefetch(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.PrefetchRequest();

            request.ChunkIds = FilterChunksIDsForLocus(m_ChunkIDs, m_Loci, new Main.Locus[] { Main.Locus.LocalSlow, Main.Locus.LocalFast });
            if (request.ChunkIds.Count > 0)
            {
                request.minimumLocus = Main.Locus.LocalFast;
                Main.Schedule(new AsyncRequest<Main.PrefetchRequest>(request).ContinueWith((antecedent) =>
                {
                    if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                    {
                        PlayGoSample.OnScreenLog.Add($"Main.PrefetchRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                        m_State = states.SetStateFailed(m_State);
                    }
                    else
                    {
                        PlayGoSample.OnScreenLog.Add("Main.PrefetchRequest succeeded");
                        m_State = states.SetStateSucceeded(m_State);
                    }
                }));
            }
            else
            {
                PlayGoSample.OnScreenLog.Add($"Main.PrefetchRequest, no chunks available");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        // Test Unity.PlayGo.PS5.Main.GetEtaRequest
        //
        void GetEta(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.GetEtaRequest();
            request.ChunkIds = m_ChunkIDs;
            if (request.ChunkIds.Count > 0)
            {
                Main.Schedule(new AsyncRequest<Main.GetEtaRequest>(request).ContinueWith((antecedent) =>
                {
                    if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                    {
                        PlayGoSample.OnScreenLog.Add($"Main.GetEtaRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                        m_State = states.SetStateFailed(m_State);
                    }
                    else
                    {
                        PlayGoSample.OnScreenLog.Add($"Main.GetEtaRequest succeeded");
                        for (int index = 0; index < antecedent.Request.Eta.Count; index++)
                        {
                            ulong eta = antecedent.Request.Eta[index];
                            if (eta == Main.kEtaMax)
                            {
                                PlayGoSample.OnScreenLog.Add($"    ChunkId {request.ChunkIds[index]} ETA MAX");
                            }
                            else
                            {
                                PlayGoSample.OnScreenLog.Add($"    ChunkId {request.ChunkIds[index]} ETA {eta}");
                            }
                        }
                        m_State = states.SetStateSucceeded(m_State);
                    }
                }));
            }
            else
            {
                PlayGoSample.OnScreenLog.Add($"Main.GetEtaRequest, no chunks available");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        // Test Unity.PlayGo.PS5.Main.GetToDoListRequest
        //
        void GetToDo(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.GetToDoListRequest();

            Main.Schedule(new AsyncRequest<Main.GetToDoListRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetToDoListRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetToDoListRequest succeeded");
                    m_ToDoList = antecedent.Request.TodoList;
                    if (m_ToDoList.Count == 0)
                    {
                        PlayGoSample.OnScreenLog.Add($"    No chunks");
                    }
                    else
                    {
                        for (int index = 0; index < m_ToDoList.Count; index++)
                        {
                            PlayGoSample.OnScreenLog.Add($"    ChunkId {m_ToDoList[index].chunkId} Locus {m_ToDoList[index].locus}");
                        }
                    }
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.PrefetchOptionalChunkRequest
        //
        void PrefetchOptionalChunk(StateTransition states)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.PrefetchOptionalChunkRequest();
            request.type = Main.OptionalChunkType.Scenario; // 0=language, 1=sceneario
            request.languages = 0;  // ScePlayGoLanguageMask or ScePlayGoScenarioMask
            int scenarioId = 0;
            request.scenarios = ((ulong)1) << scenarioId;

            Main.Schedule(new AsyncRequest<Main.PrefetchOptionalChunkRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.PrefetchOptionalChunkRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add("Main.PrefetchOptionalChunkRequest succeeded");
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.GetOptionalChunkRequest
        //
        void GetOptionalChunk(StateTransition states, Main.OptionalChunkType type)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.GetOptionalChunkRequest();
            request.type = type;

            Main.Schedule(new AsyncRequest<Main.GetOptionalChunkRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetOptionalChunkRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add("Main.GetOptionalChunkRequest succeeded");
                    if (type == Main.OptionalChunkType.Language)
                    {
                        PlayGoSample.OnScreenLog.Add($"    language Mask: 0x{antecedent.Request.languages:X16}");
                        PlayGoSample.OnScreenLog.Add($"    {Main.LanguageMaskToString(antecedent.Request.languages)}");
                        m_CurrentLanguageMask = new Main.OptionalChunk(antecedent.Request.languages);
                    }
                    else
                    {
                        PlayGoSample.OnScreenLog.Add($"    scenario Mask: 0x{antecedent.Request.scenarios:X16}");
                        PlayGoSample.OnScreenLog.Add($"    {Main.ScenarioMaskToString(antecedent.Request.scenarios)}");
                        m_CurrentScenarioMask = new Main.OptionalChunk(antecedent.Request.scenarios);
                    }
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.GetSupportedOptionalChunkRequest
        //
        void GetSupportedOptionalChunk(StateTransition states, Main.OptionalChunkType type)
        {
            m_State = states.SetStateWaiting(m_State);
            var request = new Main.GetSupportedOptionalChunkRequest();
            request.type = type;

            Main.Schedule(new AsyncRequest<Main.GetSupportedOptionalChunkRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.GetSupportedOptionalChunkRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add("Main.GetSupportedOptionalChunkRequest succeeded");
                    if (type == Main.OptionalChunkType.Language)
                    {
                        PlayGoSample.OnScreenLog.Add($"    language Mask: 0x{antecedent.Request.languages:X16}");
                        PlayGoSample.OnScreenLog.Add($"    {Main.LanguageMaskToString(antecedent.Request.languages)}");
                        m_SupportedOptionalLanguageChunk = new Main.OptionalChunk(antecedent.Request.languages);
                    }
                    else
                    {
                        PlayGoSample.OnScreenLog.Add($"    scenario Mask: 0x{antecedent.Request.scenarios:X16}");
                        PlayGoSample.OnScreenLog.Add($"    {Main.ScenarioMaskToString(antecedent.Request.scenarios)}");
                        m_SupportedOptionalScenarioChunk = new Main.OptionalChunk(antecedent.Request.scenarios);
                    }
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Main.SetToDoListRequest
        //
        void SetToDo(StateTransition states)
        {
            if (m_ToDoList.Count == 0)
            {
                PlayGoSample.OnScreenLog.Add("Main.SetToDoListRequest succeeded, nothing to do!");
                m_State = states.SetStateSucceeded(m_State);
                return;
            }

            m_State = states.SetStateWaiting(m_State);

            // As a test, reverse the order of the current todo list and set it.
            List<Main.Todo> newTodo = new List<Main.Todo>();
            for (int i = 0; i < m_ToDoList.Count; i++)
            {
                newTodo.Add(m_ToDoList[m_ToDoList.Count - 1 - i]);
            }

            var request = new Main.SetToDoListRequest();
            request.TodoList = newTodo;

            Main.Schedule(new AsyncRequest<Main.SetToDoListRequest>(request).ContinueWith((antecedent) =>
            {
                if (antecedent.Request.Result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Main.SetToDoListRequest failed. {SceErrorToString(antecedent.Request.Result)}");
                    m_State = states.SetStateFailed(m_State);
                }
                else
                {
                    PlayGoSample.OnScreenLog.Add("Main.SetToDoListRequest succeeded");
                    m_State = states.SetStateSucceeded(m_State);
                }
            }));
        }

        // Test Unity.PlayGo.PS5.Dialog.OpenProgressDialog with 1 progress bar for all pending chunks.
        //
        void OpenProgressDialog(string label, StateTransition states)
        {
            if (m_ToDoList.Count > 0)
            {
                // Open PlayGo progress dialog a single progress bar for all chunks in the to-do list.
                Dialog.ProgressDialogItem[] dialogItems = new Dialog.ProgressDialogItem[1];
                dialogItems[0].chunkIDs = new ushort[m_ToDoList.Count];
                dialogItems[0].label = label;
                for (int i = 0; i < m_ToDoList.Count; ++i)
                {
                    dialogItems[0].chunkIDs[i] = m_ToDoList[i].chunkId;
                }

                APIResult result;
                Dialog.OpenProgressDialog(Main.GetPlayGoHandle(), dialogItems, out result);
                if (result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Dialog.OpenProgressDialog failed. {SceErrorToString(result)}");
                    m_State = states.SetStateFailed(m_State);
                    return;
                }
                m_DialogOpen = true;
                m_StateTransitionAfterDialog = states;
                m_State = states.SetStateWaiting(m_State);
                PlayGoSample.OnScreenLog.Add("Dialog.OpenProgressDialog succeeded");
            }
            else
            {
                PlayGoSample.OnScreenLog.Add("Not showing progress dialog as the to-do list is empty!");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        // Test Unity.PlayGo.PS5.Dialog.OpenProgressDialog with mulitple progress bars (1 per pending chunk).
        //
        void OpenMultiListProgressDialog(StateTransition states)
        {
            if (m_ToDoList.Count > 0)
            {
                // Open PlayGo progress dialog with a progress bar for each chunk currently in the to-do lists, in this mode a label must be specified for each item.
                Dialog.ProgressDialogItem[] dialogItems = new Dialog.ProgressDialogItem[m_ToDoList.Count];
                for (int i = 0; i < m_ToDoList.Count; ++i)
                {
                    dialogItems[i].label = "Downloading data ...";
                    dialogItems[i].chunkIDs = new ushort[] { m_ToDoList[i].chunkId };
                }
                APIResult result;
                Dialog.OpenProgressDialog(Main.GetPlayGoHandle(), dialogItems, out result);
                if (result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Dialog.OpenProgressDialog (multi list) failed. {SceErrorToString(result)}");
                    m_State = states.SetStateFailed(m_State);
                    return;
                }
                m_DialogOpen = true;
                m_StateTransitionAfterDialog = states;
                m_State = states.SetStateWaiting(m_State);
                PlayGoSample.OnScreenLog.Add("Dialog.OpenProgressDialog (multi list) succeeded");
            }
            else
            {
                PlayGoSample.OnScreenLog.Add("Not showing progress dialog as the to-do list is empty!");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        // Test Unity.PlayGo.PS5.Dialog.OpenRequestInstallDialog for installing optional scenarios.
        //
        void RequestInstallScenario(uint scenarioID, StateTransition states)
        {
            ulong scenarioMask = Main.ConvertScenario(scenarioID);

            if ((m_CurrentScenarioMask.scenarios & scenarioMask) != scenarioMask)
            {
                Main.OptionalChunkType optionalChunkType = Main.OptionalChunkType.Scenario;
                Main.OptionalChunk optionalChunk;
                optionalChunk.languages = 0;
                optionalChunk.scenarios = scenarioMask;
                PlayGoSample.OnScreenLog.Add($"Opening PlayGo dialog with scenario mask {scenarioMask.ToString("X")}");
                APIResult result;
                Dialog.OpenRequestInstallDialog(Main.GetPlayGoHandle(), optionalChunkType, optionalChunk, out result);
                if (result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Dialog.OpenRequestInstallDialog for scenario {scenarioID} failed. {SceErrorToString(result)}");
                    m_State = states.SetStateFailed(m_State);
                    return;
                }
                m_DialogOpen = true;
                m_StateTransitionAfterDialog = states;
                m_State = states.SetStateWaiting(m_State);
                PlayGoSample.OnScreenLog.Add($"Dialog.OpenRequestInstallDialog for scenario {scenarioID} succeeded");
            }
            else
            {
                PlayGoSample.OnScreenLog.Add($"Skipping install dialog as scenario {scenarioID} is already installed");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        // Test Unity.PlayGo.PS5.Dialog.OpenRequestInstallDialog for installing optional languages.
        //
        void RequestInstallLanguage(int languageID, StateTransition states)
        {
            ulong languageMask = Main.ConvertLanguage(languageID);

            if ((m_CurrentLanguageMask.languages & languageMask) != languageMask)
            {
                Main.OptionalChunkType optionalChunkType = Main.OptionalChunkType.Language;
                Main.OptionalChunk optionalChunk;
                optionalChunk.scenarios = 0;
                optionalChunk.languages = languageMask;
                PlayGoSample.OnScreenLog.Add($"Opening PlayGo dialog with language mask {languageMask.ToString("X")}");
                APIResult result;
                Dialog.OpenRequestInstallDialog(Main.GetPlayGoHandle(), optionalChunkType, optionalChunk, out result);
                if (result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Dialog.OpenRequestInstallDialog for language {languageID} failed. {SceErrorToString(result)}");
                    m_State = states.SetStateFailed(m_State);
                    return;
                }
                m_DialogOpen = true;
                m_StateTransitionAfterDialog = states;
                m_State = states.SetStateWaiting(m_State);
                PlayGoSample.OnScreenLog.Add($"Dialog.OpenRequestInstallDialog for language {languageID} succeeded");
            }
            else
            {
                PlayGoSample.OnScreenLog.Add($"Skipping install dialog as language {languageID} is already installed");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        // Test Unity.PlayGo.PS5.Dialog.CloseDialog for forcably closing the PlayGo dialog.
        //
        void CloseDialog(StateTransition states)
        {
            if (m_DialogOpen)
            {
                APIResult result;
                Dialog.CloseDialog(out result);
                if (result.apiResult != APIResultTypes.Success)
                {
                    PlayGoSample.OnScreenLog.Add($"Dialog.CloseDialog failed. {SceErrorToString(result)}");
                    m_State = states.SetStateFailed(m_State);
                    return;
                }
                m_State = states.SetStateSucceeded(m_State);
                PlayGoSample.OnScreenLog.Add($"Dialog.CloseDialog succeeded");
            }
            else
            {
                PlayGoSample.OnScreenLog.Add($"Skipping CloseDialog, the dialog was not open");
                m_State = states.SetStateSucceeded(m_State);
            }
        }

        void CloseDialogWhenFinished()
        {
            APIResult result;
            Dialog.CloseDialog(out result);
            if (result.apiResult != APIResultTypes.Success)
            {
                PlayGoSample.OnScreenLog.Add($"Dialog Finished - Dialog.CloseDialog failed. {SceErrorToString(result)}");
                return;
            }
            PlayGoSample.OnScreenLog.Add($"Dialog Finished - Dialog.CloseDialog succeeded");
        }

        // Update the PlayGo dialog if it is currently open.
        //
        // Updates and gets the dialog's status and does any required processing when the dialog closes.
        //
        void UpdateDialog()
        {
            if (m_DialogOpen)
            {
                m_DialogStatus = Dialog.UpdateStatus();
                switch (m_DialogStatus)
                {
                    case Dialog.Status.Finished:
                        m_DialogOpen = false;
                        APIResult apiResult;
                        Dialog.DialogResult result = Dialog.GetResult(out apiResult);
                        PlayGoSample.OnScreenLog.Add($"  Dialog finished with result: {result.mode}, {result.result}, 0x{result.resultValue:X8}");

                        // Force-close the dialog, it will already have been closed when its status changed to "Finished" but by calling this here we
                        // ensure that scePlayGoDialogTerminate gets called, if scePlayGoDialogTerminate is not called then other systems which try to
                        // use the PS5 common dialog library may fail to initialize.
                        CloseDialogWhenFinished();

                        if (result.mode == Dialog.Mode.RequestInstall && result.result == Dialog.Result.Ok)
                        {
                            PlayGoSample.OnScreenLog.Add($"  User requested installation..");

                            // Update optional chunks after installation confirmation dialog, see tech-note https://game.develop.playstation.net/technotes/view/181/1
                            PlayGoSample.OnScreenLog.Add("  Updating optional chunks");
                            GetOptionalChunk(m_NullStateTransition, Main.OptionalChunkType.Language);
                            GetOptionalChunk(m_NullStateTransition, Main.OptionalChunkType.Scenario);

                            // Update the to-do list.
                            PlayGoSample.OnScreenLog.Add("  Updating the to-do list");
                            GetToDo(m_NullStateTransition);
                        }

                        m_State = m_StateTransitionAfterDialog.SetCompletionState(m_State, result.resultValue >= 0);
                        break;
                }
            }
        }

        // Update the delay time when in the delay state.
        //
        void UpdateDelay()
        {
            if (m_State == PlayGoState.WaitingForDelay)
            {
                m_DelayTime -= Time.deltaTime;
                if (m_DelayTime <= 0.0f)
                {
                    m_State = m_StateTransitionAfterDelay.SetStateSucceeded(m_State);
                }
            }
        }

        // Setup state to wait for a specified time.
        //
        void WaitSeconds(float delayTime, StateTransition states)
        {
            m_State = PlayGoState.WaitingForDelay;
            m_DelayTime = delayTime;
            m_StateTransitionAfterDelay = states;
        }

        // Execute the current test state.
        //
        void ExecuteCurrentState()
        {
            switch (m_State)
            {
                case PlayGoState.Next:
                    if (m_CurrentStep < m_Steps.Length - 1)
                    {
                        m_CurrentStep++;
                        m_State = m_Steps[m_CurrentStep];
                    }
                    break;

                case PlayGoState.Initialize:
                    Initialize(m_DefaultStateTransition);
                    break;

                case PlayGoState.Terminate:
                    Terminate(m_DefaultStateTransition);
                    break;

                case PlayGoState.Open:
                    Open(m_DefaultStateTransition);
                    break;

                case PlayGoState.Close:
                    Close(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetInstallSpeed:
                    GetInstallSpeed(m_DefaultStateTransition);
                    break;

                case PlayGoState.SetInstallSpeed:
                    SetInstallSpeed(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetInstallSpeedAgain:
                    GetInstallSpeed(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetChunkIDs:
                    GetChunkIDs(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetInstallChunkIDs:
                    GetInstallChunkIDs(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetProgress:
                    GetProgress(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetLocus:
                    GetLocus(m_DefaultStateTransition);
                    break;

                case PlayGoState.Prefetch:
                    Prefetch(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetEta:
                    GetEta(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetToDo:
                    GetToDo(m_DefaultStateTransition);
                    break;

                case PlayGoState.GetOptionalChunk_Languages:
                    GetOptionalChunk(m_DefaultStateTransition, Main.OptionalChunkType.Language);
                    break;

                case PlayGoState.GetOptionalChunk_Scenarios:
                    GetOptionalChunk(m_DefaultStateTransition, Main.OptionalChunkType.Scenario);
                    break;

                case PlayGoState.GetSupportedOptionalChunk_Languages:
                    GetSupportedOptionalChunk(m_DefaultStateTransition, Main.OptionalChunkType.Language);
                    break;

                case PlayGoState.GetSupportedOptionalChunk_Scenarios:
                    GetSupportedOptionalChunk(m_DefaultStateTransition, Main.OptionalChunkType.Scenario);
                    break;

                case PlayGoState.PrefetchOptionalChunk:
                    PrefetchOptionalChunk(m_DefaultStateTransition);
                    break;

                case PlayGoState.SetToDo:
                    SetToDo(m_DefaultStateTransition);
                    break;

                case PlayGoState.EmuRequestNextChunk:
                    EmuRequestNextChunk(m_DefaultStateTransition);
                    break;

                case PlayGoState.OpenProgressDialog:
                    OpenProgressDialog("", new StateTransition(PlayGoState.WaitForProgressDialog, PlayGoState.Next));
                    break;

                case PlayGoState.OpenProgressDialogWithLabel:
                    OpenProgressDialog("Please Wait!\nDownloading additional application data...", new StateTransition(PlayGoState.WaitForProgressDialogWithLabel, PlayGoState.Next));
                    break;

                case PlayGoState.OpenMultiListProgressDialog:
                    OpenMultiListProgressDialog(new StateTransition(PlayGoState.WaitForMultiListProgressDialog, PlayGoState.Next));
                    break;

                case PlayGoState.OpenRequestInstallScenarioDialog:
                    RequestInstallScenario(1, new StateTransition(PlayGoState.WaitForRequestInstallScenarioDialog, PlayGoState.Next));
                    break;

                case PlayGoState.OpenRequestInstallLanguageDialog:
                    RequestInstallLanguage(18, new StateTransition(PlayGoState.WaitForRequestInstallLanguageDialog, PlayGoState.Next));
                    break;

                case PlayGoState.Wait1Second:
                    WaitSeconds(1.0f, new StateTransition(PlayGoState.Next));
                    break;

                case PlayGoState.WaitForProgressDialog:
                case PlayGoState.WaitForProgressDialogWithLabel:
                case PlayGoState.WaitForMultiListProgressDialog:
                    // Wait for a few seconds and then manually close the progress dialog, the dialog would close automatically
                    // when chunks finish downloading but this doesn't happen when using PlayGo in emulation mode.
                    WaitSeconds(3.0f, new StateTransition(PlayGoState.CloseDialog));
                    break;

                case PlayGoState.WaitForRequestInstallScenarioDialog:
                case PlayGoState.WaitForRequestInstallLanguageDialog:
                    // Do nothing, the dialog will close when the user either accepts or cancels the request and the state will
                    // be updated in UpdateDialog().
                    break;

                case PlayGoState.WaitingForDelay:
                    UpdateDelay();
                    break;

                case PlayGoState.Waiting:
                    // Do nothing, waiting for something to complete.
                    break;

                case PlayGoState.CloseDialog:
                    // Close the dialog and wait for a short period of time before transitioning to the next state, if
                    // we try and open another dialog too quickly after closeing the previous one then it may fail with
                    // an SCE_COMMON_DIALOG_ERROR_INVALID_STATE error.
                    CloseDialog(new StateTransition(PlayGoState.Wait1Second));
                    break;

                case PlayGoState.AllDone:
                    PlayGoSample.OnScreenLog.Add($"All Done!");
                    m_State = PlayGoState.Waiting;
                    break;

                case PlayGoState.Failed:
                    PlayGoSample.OnScreenLog.Add($"Execution stopped!");
                    m_State = PlayGoState.Waiting;
                    break;

                default:
                    PlayGoSample.OnScreenLog.Add($"Unhandled state {m_State}");
                    m_State = PlayGoState.Failed;
                    break;
            }
        }

        string GetDiagnosticInfo()
        {
            string text = $"\nCurrent state: {m_State}";

            if (Main.GetPlayGoHandle() != 0)
            {
                text += $"\nCurrent languages: {Main.LanguageMaskToString(m_CurrentLanguageMask.languages)}";
                text += $"\nCurrent scenario ID: {Main.ScenarioMaskToString(m_CurrentScenarioMask.scenarios)}";
                text += $"\nSupported languages: {Main.LanguageMaskToString(m_SupportedOptionalLanguageChunk.scenarios)}";
                text += $"\nSupported scenario IDs: {Main.ScenarioMaskToString(m_SupportedOptionalScenarioChunk.languages)}";
                if (m_DialogOpen)
                    text += $"\nDialog open, status: {m_DialogStatus}";
                else
                    text += $"\nDialog closed, status: {m_DialogStatus}";
            }

            return text;
        }
    }
}
#endif
