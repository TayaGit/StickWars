#if UNITY_PS5
using System.Collections.Generic;
using UnityEngine;
using Unity.PlayGo;
using Unity.PlayGo.PS5.Aysnc;

namespace PlayGoSample
{
    public enum PlayGoState
    {
        // States used for flow control and general house-keeping.
        NullState,
        Uninitialized,
        Next,
        AllDone,
        Failed,
        Waiting,
        Wait1Second,
        WaitingForDelay,

        // States that test some aspect of the PlayGo library.
        Initialize,
        Terminate,
        Open,
        Close,
        GetInstallSpeed,
        SetInstallSpeed,
        GetInstallSpeedAgain,
        GetChunkIDs,
        EmuRequestNextChunk,
        EmuSnapshot,
        GetInstallChunkIDs,
        GetProgress,
        GetLocus,
        Prefetch,
        GetEta,
        GetToDo,
        PrefetchOptionalChunk,
        GetOptionalChunk_Languages,
        GetOptionalChunk_Scenarios,
        GetSupportedOptionalChunk_Languages,
        GetSupportedOptionalChunk_Scenarios,
        SetToDo,
        OpenProgressDialog,
        WaitForProgressDialog,
        OpenProgressDialogWithLabel,
        WaitForProgressDialogWithLabel,
        OpenMultiListProgressDialog,
        WaitForMultiListProgressDialog,
        OpenRequestInstallScenarioDialog,
        WaitForRequestInstallScenarioDialog,
        OpenRequestInstallLanguageDialog,
        WaitForRequestInstallLanguageDialog,
        CloseDialog,
    }

    public class StateTransition
    {
        public StateTransition(PlayGoState _onSuccess)
        {
            whileWaiting = PlayGoState.Waiting;
            onSuccess = _onSuccess;
            onFailure = PlayGoState.Failed;
        }

        public StateTransition(PlayGoState _whileWaiting, PlayGoState _onSuccess)
        {
            whileWaiting = _whileWaiting;
            onSuccess = _onSuccess;
            onFailure = PlayGoState.Failed;
        }

        public StateTransition(PlayGoState _whileWaiting, PlayGoState _onSuccess, PlayGoState _onFailure)
        {
            whileWaiting = _whileWaiting;
            onSuccess = _onSuccess;
            onFailure = _onFailure;
        }

        PlayGoState whileWaiting;       // State to set while waiting for the request to complete.
        PlayGoState onSuccess;          // State to set when the request completes succesfully.
        PlayGoState onFailure;          // State to set when the request completes succesfully.

        public PlayGoState SetStateWaiting(PlayGoState currentState)
        {
            if (whileWaiting != PlayGoState.NullState)
                currentState = whileWaiting;

            return currentState;
        }

        public PlayGoState SetStateSucceeded(PlayGoState currentState)
        {
            if (onSuccess != PlayGoState.NullState)
                currentState = onSuccess;

            return currentState;
        }

        public PlayGoState SetStateFailed(PlayGoState currentState)
        {
            if (onFailure != PlayGoState.NullState)
                currentState = onFailure;

            return currentState;
        }

        public PlayGoState SetCompletionState(PlayGoState currentState, bool succeeded)
        {
            if (onSuccess != PlayGoState.NullState && onFailure != PlayGoState.NullState)
                currentState = succeeded ? onSuccess : onFailure;
            return currentState;
        }
    }
}

#endif
