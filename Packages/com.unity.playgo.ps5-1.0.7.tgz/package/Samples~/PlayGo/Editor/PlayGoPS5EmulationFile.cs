using System;
using System.Xml;

namespace PS5PlayGoSample
{
    // Class for parsing a PlayGo emulation specification file.
    //
    // Provides a method to find the chunk ID that should be assigned to any given file, useful when generating the GP5 project file for package creation.
    //
    public class PlayGoEmuFile
    {
        XmlDocument m_XmlDoc;
        XmlElement m_Chunks;
        XmlElement m_Scenarios;

        public XmlElement ChunkInfo { get; private set; }
        public XmlElement Files { get; private set; }

        // Read the PlayGo emulation file.
        public void Read(string emulationFilePath)
        {
            m_XmlDoc = new XmlDocument();
            m_XmlDoc.Load(emulationFilePath);
            foreach (XmlNode xmlNode in m_XmlDoc.DocumentElement)
                System.Console.WriteLine(xmlNode.Name);

            XmlNodeList nodes = m_XmlDoc.GetElementsByTagName("chunk_info");
            if (nodes.Count != 1)
            {
                throw new System.InvalidOperationException($"PlayGo file syntax error; expected 1 chunk_info element but found {nodes.Count} elements");
            }
            if (nodes[0].NodeType != XmlNodeType.Element)
            {
                throw new System.InvalidOperationException($"PlayGo file syntax error; chunk_info node type is not an element");
            }

            ChunkInfo = (XmlElement)nodes[0];

            // Remove the emulation_size attribute from all chunks.
            nodes = ChunkInfo.GetElementsByTagName("chunks");
            m_Chunks = (XmlElement)nodes[0];
            nodes = m_Chunks.GetElementsByTagName("chunk");
            foreach (XmlElement element in nodes)
            {
                element.RemoveAttribute("emulation_size");
            }

            nodes = ChunkInfo.GetElementsByTagName("scenarios");
            m_Scenarios = (XmlElement)nodes[0];

            nodes = m_XmlDoc.GetElementsByTagName("files");
            if (nodes.Count != 1)
            {
                throw new System.InvalidOperationException($"PlayGo file syntax error; expected 1 files element but found {nodes.Count} elements");
            }
            Files = (XmlElement)nodes[0];
        }

        // Given a file path, attempt to find it in the emulation file.
        //
        // If the file path is found then returns the corresponding chunk ID, or -1 if the file is not found.
        // 
        public int FindChunkIDForFile(string file)
        {
            if (Files == null)
            {
                return -1;
            }

            XmlNodeList nodes = Files.GetElementsByTagName("file");
            foreach (XmlElement element in nodes)
            {
                string targPath = element.GetAttribute("targ_path");
                if (file.CompareTo(targPath) == 0)
                {
                    string chunkID = element.GetAttribute("chunk");
                    if (Int32.TryParse(chunkID, out int id))
                    {
                        return id;
                    }
                    else
                    {
                        throw new System.InvalidOperationException($"PlayGo file syntax error; failed to find chunk attribute for file element \"{targPath}\"");
                    }
                }
            }

            return -1;
        }
    }
}
