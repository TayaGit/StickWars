#if UNITY_PS5
using UnityEngine;
using UnityEditor;
using System.IO;
using System;

namespace PS5PlayGoSample
{
    public class SetPlatformOptionsPS5
    {
        [MenuItem("SCE Publishing Utils/PlayGo Sample/Prepare Project Assets And Settings")]
        static void PreparePlayGoSample()
        {
            PlayerSettings.productName = "Unity PlayGo Example";

            // The directory structure of the sample code embedded in a Unity package has the StreamingAssets folder in a subfolder, e.g. "Assets/Samples/PlayGo/StreamingAssets"
            // so copy the streaming assets into the correct path, i.e. "Assets/StreamingAssets"
            PrepareStreamingAssets();

            // Set the sce_sys folder path containing the param.json file, playgo icon files, etc, in the player settings.
            PrepareSceSysFolder();

            // Misc settings for building packages etc.
            PreparePackageSettings();

            // Refresh the asset database, imports any new or changed assets and updates their associated .meta files.
            AssetDatabase.Refresh();
        }

        static bool CopyAssetFile(string sourceFile, string targetFile)
        {
            bool result = false;

            string sourceDirectory = Path.GetDirectoryName(sourceFile);
            if (sourceDirectory.EndsWith("~"))
            {
                // The source directory ends with `~` so it's not in the asset database, so we can't use AssetDatabase.CopyAsset to copy the asset, so use File.Copy instead.
                try
                {
                    File.Copy(sourceFile, targetFile, true);
                    result = true;
                }
                catch
                {
                    result = false;
                }
            }
            else
            {
                result = AssetDatabase.CopyAsset(sourceFile, targetFile);
            }

            return result;
        }

        static void PrepareStreamingAssets()
        {
            string streamingDir = Path.Combine(Application.dataPath, "StreamingAssets");

            int copied = 0;
            foreach (string fileName in PS5PlayGoBuildParams.StreamingAssetFiles())
            {
                string sourceFile = SearchForFile(Application.dataPath, fileName, true, PS5PlayGoBuildParams.StreamingAssetPaths());
                sourceFile = sourceFile.Replace(Application.dataPath, "Assets");
                if (!FileFound(sourceFile))
                {
                    Debug.LogError($"Failed to find streaming asset file: \"{fileName}\"\n");
                }
                else
                {
                    string targetFile = Path.Combine(streamingDir, fileName);
                    targetFile = targetFile.Replace(Application.dataPath, "Assets");

                    if (Directory.Exists(streamingDir) == false)
                    {
                        Directory.CreateDirectory(streamingDir);
                    }

                    CopyAssetFile(sourceFile, targetFile);
                    copied++;
                }
            }

            Debug.Log($"Copied {copied} streaming assets to \"{streamingDir}\"\n");
        }

        static void PrepareSceSysFolder()
        {
            // Setup the sce_sys folder path for the playgo sample in the PS5 player settings.
            string sourceFile = SearchForFile(Application.dataPath, "param.json", false, PS5PlayGoBuildParams.SceSysPaths());
            sourceFile = sourceFile.Replace(Application.dataPath, "Assets");

            string sourceFolder = "";
            if (!FileFound(sourceFile))
            {
                Debug.LogError($"Failed to find a sce_sys folder with a valid param.json file \"{PS5PlayGoBuildParams.SceSysPaths()}\"\n");
                return;
            }
            else
            {
                sourceFolder = Path.GetDirectoryName(sourceFile);
                Debug.Log($"Set \"{sourceFolder}\" in player settings\n");
            }

#if UNITY_2020_1_OR_NEWER
            UnityEditor.PS5.PlayerSettings.sharedBinaryContentLabels = new string[] { "primary" };
            UnityEditor.PS5.PlayerSettings.sharedBinarySystemFolders = new string[] { sourceFolder };
#else
            UnityEditor.PlayerSettings.PS5.sharedBinaryContentLabels = new string[] { "primary" };
            UnityEditor.PlayerSettings.PS5.sharedBinarySystemFolders = new string[] { sourceFolder };
#endif
        }

        static void PreparePackageSettings()
        {
#if UNITY_2020_1_OR_NEWER
            UnityEditor.PS5.PlayerSettings.passcode = "01234567890123456789012345678901";
#else
            UnityEditor.PlayerSettings.PS5.passcode = "01234567890123456789012345678901";
#endif
        }

        static bool FileFound(string filePath)
        {
            if (String.IsNullOrEmpty(filePath))
                return false;

            return true;
        }

        public static string SearchForFile(string path, string findFilename, bool ignoreExtension, string[] matchingPaths)
        {
            var files = Directory.EnumerateFiles(path, "*.*", SearchOption.AllDirectories);

            foreach (string matchPath in matchingPaths)
            {
                string cleanMatchPath = "";
                if (!String.IsNullOrEmpty(matchPath))
                    cleanMatchPath = matchPath.Replace("\\", "/");

                foreach (var file in files)
                {
                    string cleanFile = file.Replace("\\", "/");
                    if (!String.IsNullOrEmpty(cleanMatchPath))
                    {
                        if (!cleanFile.Contains(cleanMatchPath))
                            continue;
                    }

                    if (ignoreExtension && Path.GetFileNameWithoutExtension(cleanFile) == findFilename)
                        return cleanFile;

                    if (Path.GetFileName(cleanFile) == findFilename)
                        return cleanFile;
                }
            }

            return "";
        }
    }
}
#endif
